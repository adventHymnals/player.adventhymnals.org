import {
  VOICES, ACCOMP_STYLES, INSTRUMENTAL, buildMusicXML, lyricLines, performance, locate, barSpan, passTime, chordIndexAt, prettyChord,
  trackKey, trackName, pianoVoices, barAt, barEnd, keyAfter, transposeChordName, syncopations, syncopate, phraseBounds, countQ,
} from "./core.js";
import { Engine, singers } from "./audio.js";
import { loadSinging, Warble } from "./warble/warble.js";
import { ScoreView } from "./scoreview.js";
import { SolfaView, WordsView } from "./solfa.js";
import { Waterfall } from "./waterfall.js";
import { Presenter } from "./presenter.js";
import { Studio } from "./studio.js";
import { exportPdf } from "./pdfexport.js";
import { canMakeVideo, makeVideos } from "./videomaker.js";
import { Conductor, feel, mysteryTune, meterHint, PitchListener, centsOff, drawLane, noteName } from "./practice.js";
import { TempoFollower } from "./follow.js";
import { MelodyIndex, NoteTracker, decide } from "./melody.js";

const $ = (id) => document.getElementById(id);
const workspace = $("workspace");
const viewport = $("viewport");
const sheet = $("sheet");
const ribbon = $("ribbon");
const headersEl = $("headers");
const reduceMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

// Per-viewer conveniences only; the page works the same without storage.
// ?test keeps a page's settings to itself (automated runs must not touch a person's tabs).
// ?embed is the compact player a hymn page on adventhymnals.org shows inline; it
// leaves the visitor's full-Studio settings alone.
const EMBED = new URLSearchParams(location.search).has("embed");
// ?app: inside the Android app, which draws its own controls and drives this page through window.AHStudio
const APP = new URLSearchParams(location.search).has("app");
singers.on = APP; // the app keeps the singers it has played (and lets them be cleared)
// ?remote=<url>: this copy is bundled in the app; hymn data and recordings come from that site
// (the live list and new hymns when online, the bundled copy when not)
const REMOTE = new URLSearchParams(location.search).get("remote") || "";
// where the recordings are: the published site sets <meta name="ah-audio"> to the audio store (Cloudflare R2);
// otherwise they come from the site itself (or the local copy)
const AUDIO = document.querySelector('meta[name="ah-audio"]')?.content || REMOTE;
// and the hymns themselves (the list and each hymn's file): the published site reads them from the same store,
// so a new hymn goes live by upload, with no rebuild of the site
const DATA = document.querySelector('meta[name="ah-data"]')?.content || REMOTE;
singers.synced = !!DATA; // the app keeps its saved lists of recordings up to date itself (syncHymns)
// search by idea (the site's API; online only). A local copy of the player asks a local backend.
const IDEA_API = document.querySelector('meta[name="ah-idea"]')?.content
  || (/^(localhost|127\.0\.0\.1)$/.test(location.hostname) ? "http://127.0.0.1:8000/api/plugins/adventhymnals/public/search/idea/" : "https://adventhymnals.org/api/search/idea");
// ?make=: the automatic social videos (see "automatic videos" below); the URL's settings are never saved
const MAKE = new URLSearchParams(location.search).get("make") ? new URLSearchParams(location.search) : null;
const NO_STORE = new URLSearchParams(location.search).has("test") || EMBED || !!MAKE;
const store = {
  get(k, d) { if (NO_STORE) return d; try { const v = localStorage.getItem(`hymn2:${k}`); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { if (NO_STORE) return; try { localStorage.setItem(`hymn2:${k}`, JSON.stringify(v)); } catch { /* private mode */ } },
};

const CH = ["S", "A", "T", "B", "acc"];
const DEFAULT_MIX = { S: { level: 0.8, pan: -0.62 }, A: { level: 0.8, pan: -0.24 }, T: { level: 0.8, pan: 0.24 }, B: { level: 0.8, pan: 0.62 }, acc: { level: 0.55, pan: 0 } };
const state = {
  tracks: store.get("tracks", [["S"], ["A"], ["T"], ["B"]]),
  hidden: store.get("hidden", []),
  trackWords: store.get("trackWords", { S: true, A: true, T: true, B: true, SA: true, TB: true }),
  mute: store.get("mute", {}),
  solo: store.get("solo", {}),
  levels: store.get("levels", Object.fromEntries(CH.map((c) => [c, DEFAULT_MIX[c].level]))),
  pans: store.get("pans", Object.fromEntries(CH.map((c) => [c, DEFAULT_MIX[c].pan]))),
  view: store.get("view", "tracks"),
  words: store.get("words", "all"),
  nowbar: store.get("nowbar", true),
  chords: store.get("chords", false),
  piano: store.get("piano", false),
  accomp: store.get("accomp", "off"),
  accStaff: store.get("accStaff", false),
  intro: store.get("intro", "none"),
  interlude: store.get("interlude", "none"),
  countIn: store.get("countIn", true),
  countAt: store.get("countAt", "start"), // the count-in bar: at the very start, or after the introduction
  introVoice: null, // while making a one-voice video: the voice its introduction plays
  watermark: false, // while making a video: its watermark is drawn (always, on every video)
  format: "landscape", // while making an automatic video: "vertical" draws the tall stage of a Short
  // each voice's sound: "sung" (recorded singers), "choir" (synthesised aah) or "piano";
  // unset means singers when a recording exists, else the choir synth
  voiceSounds: store.get("voiceSounds", {}),
  zoom: store.get("zoom", 1),
  loop: { on: false, from: 1, to: 4 },
  tempo: 96,
  verses: [1],
  transpose: 0,       // semitones for the whole hymn (saved per hymn)
  lastVerseUp: store.get("lastVerseUp", 0), // modulate the last verse up 0, 1 or 2 semitones
  verseLayout: store.get("verseLayout", "stack"), // "stack": verses under one another; "unfold": written out, each verse starting where the last ends (a score several times longer: a phone draws it slowly)
  presenterShows: store.get("presenterShows", "score"), // or "words" for projection
  showSync: store.get("showSync", false),
  headsCollapsed: store.get("headsCollapsed", false),
  practice: store.get("practice", false),
  practiceTab: store.get("practiceTab", "meter"),
  metronome: store.get("metronome", false),
  singVoice: store.get("singVoice", "S"),
  muteMine: store.get("muteMine", true),
  anyOctave: store.get("anyOctave", true),
  // ?app, the staff view: "line by line", one line at a time, the next line uncovered behind the
  // playhead (as the presenter does), instead of the whole page scrolling
  sweep: store.get("lineByLine", true), // the staff line by line, the next line peeled in behind the singer
  altZoom: store.get("altZoom", 1), // the sol-fa and words views, pinched larger or smaller
  solfaWordsAt: store.get("solfaWordsAt", "every"), // sol-fa: the words under every voice, or only the top one
  solfaSweep: store.get("solfaLineByLine", true), // sol-fa line by line, as the staff
  solfaZoom: store.get("solfaZoom", 1), // the sol-fa, pinched larger or smaller (the app opens it at the smallest)
  instrumental: store.get("instrumental", false), // every voice played on the piano, no singing
  singSolfa: store.get("singSolfa", false),
  singAsk: store.get("singAsk", true), // ask "Who sings?" at Play for each hymn opened
  singEngine: store.get("singEngine", null), // "stems" (recorded singers) or "warble" (live singing); null: the default in data/singing.json
  staffScroll: store.get("staffScroll", false), // the app's staff as one long line moving under a still playhead
  beforeInstrumental: store.get("beforeInstrumental", null),
};
let hymnWritten = null; // the hymn as transcribed; `hymn` may be a rhythm variant of it
// key changes made while playing: from section k at score position q, move by delta semitones
let liveChanges = [];
let renderedShift = 0;
const save = (...keys) => keys.forEach((k) => store.set(k, state[k]));
// ?app: the hymn the app asked for last. Until it has loaded, the page reports it is not ready,
// so the app can never play (or show) the hymn it had before.
const appWant = { id: null, missing: false, loading: false };
let bootDone;
const bootReady = new Promise((r) => { bootDone = r; });

const engine = new Engine();
const waterfall = new Waterfall();
let tk = null;
/** The notation engine (Verovio), started only when something draws music: the Score view, Presenter,
 *  the projector or a PDF. Started, it takes 70-150 MB, which the words, sol-fa and playback never need. */
let tkLoading = null;
const VEROVIO = "vendor/verovio-toolkit-wasm-6.2.0.js";
const VEROVIO_CDN = "https://cdn.jsdelivr.net/npm/verovio@6.2.0/dist/verovio-toolkit-wasm.js";
/** The app's own Verovio (the same 6.2.0, built natively): draws without the WebAssembly copy's memory. */
class NativeToolkit {
  constructor(n) { this.n = n; }
  setOptions(o) { return this.n.setOptions(JSON.stringify(o)); }
  loadData(d) { return this.n.loadData(d); }
  getPageCount() { return this.n.getPageCount(); }
  renderToSVG(page = 1) { return this.n.renderToSVG(page); }
  renderToTimemap(o = {}) { return JSON.parse(this.n.renderToTimemap(JSON.stringify(o)) || "[]"); }
}
const nativeVerovio = () => { try { return window.AHNative?.verovio?.available?.() ? window.AHNative.verovio : null; } catch { return null; } };
function ensureVerovio() {
  if (tk) return Promise.resolve(tk);
  const n = nativeVerovio();
  if (n) {
    tk = new NativeToolkit(n);
    if (view) view.tk = tk;
    return Promise.resolve(tk);
  }
  tkLoading ??= (async () => {
    if (!window.verovio) await loadScript(VEROVIO).catch(() => loadScript(VEROVIO_CDN));
    // ready when a toolkit can be made (its start-up may finish before any "initialized" hook is set)
    const since = Date.now();
    for (;;) {
      try { tk = new window.verovio.toolkit(); break; } catch (e) {
        if (Date.now() - since > 20000) throw e;
        await new Promise((r) => setTimeout(r, 50));
      }
    }
    if (view) view.tk = tk;
    return tk;
  })().catch((e) => { tkLoading = null; throw e; });
  return tkLoading;
}
const needsNotation = () => isScoreView() || state.view === "presenter" || projectorOpen();
const notationFailed = () => {
  $("score").innerHTML = `<p class="status">The score viewer could not load. Check the internet connection and reload the page.</p>`;
};
let view = null;
let solfa = null;
let words = null;
let presenter = null;
let studio = null;
let hymn = null;
let perf = null;
let renderedVerse = 1;
let lastSystem = null;
let lastFollowEl = null;
let lastLineKey = "";
let recording = null;
let colors = null;
let manifest = null; // sung stems for this hymn, if rendered: the chosen recorded singers' list (below)
// the recorded singers: "stems" (LUNAI's voices, audio/) and "stems-v2" (the same converted to real singers'
// voices, audio-svc/: "Recorded singers v2"); each hymn's lists as loaded, by engine
const RECORDED = [
  { engine: "stems", label: "Recorded singers", dir: "audio", has: (x) => x?.sung },
  { engine: "stems-v2", label: "Recorded singers v2", dir: "audio-svc", has: (x) => x?.svc },
];
const isRecorded = (v) => RECORDED.some((r) => r.engine === v);
let manifests = {};
/** The list the chosen recorded singers sing from (v2 where the hymn has it, else the first). */
const pickManifest = () => { manifest = (singEngine() === "stems-v2" && manifests["stems-v2"]) || manifests.stems || null; };
const recordedChoices = () => RECORDED.filter((r) => r.engine === "stems" || manifests[r.engine]);
let stemInfo = new Map(); // "S:1:0" (voice:verse:transpose) -> { offsetSec, duration } usable at the current tempo
// the two singing engines: recorded singers (stems, per hymn/tempo/key) and live singing (Warble, any hymn);
// data/singing.json says which is the default, the listener may choose per device
let singingCfg = { default: "stems", warble: null, voices: [] };
// live voices: engine "warble" (the first in singing.json) or "warble-<id>" (the others)
const isLive = (v) => typeof v === "string" && (v === "warble" || v.startsWith("warble-"));
const liveVoice = (v) => singingCfg.voices.find((w) => w.engine === v) || null;
const otherLive = (v) => { for (const w of singingCfg.voices) if (w.engine !== v) w.cancelAll(); }; // only the chosen voice works
// which singers there are (data/singing.json): the app's saved copy (kept up to date by its occasional
// check) at once, else the site (at most 8 s each try), else the player's own copy if it has one
const SINGING_SAVED = "https://ah-hymns.invalid/singing.json";
const singingReady = (async () => {
  const urls = [];
  if (DATA) {
    try {
      const r = await (await caches.open("ah-hymns")).match(SINGING_SAVED);
      if (r) urls.push(URL.createObjectURL(await r.blob()));
    } catch { /* nothing saved */ }
  }
  return loadSinging([...new Set([...urls, `${DATA}data/singing.json`, "data/singing.json"])], location.href);
})().then((c) => { singingCfg = c; offerLiveVoices(); if (DATA) refreshSinging(); });
/** The app: the saved list of singers opened the player at once; the site's is fetched straight after, on
 *  every start (not only by the 6-hourly check), and when it differs it takes over at once and is saved.
 *  (A changed list of live voices took up to 6 hours to reach a phone.) */
async function refreshSinging() {
  try {
    const c = await caches.open("ah-hymns");
    const r = await fetchWithin(`${DATA}data/singing.json`, 15000, { cache: "no-cache" });
    if (!r.ok) return;
    const text = await r.text();
    const had = await c.match(SINGING_SAVED).then((x) => x?.text()).catch(() => null);
    if (text === had) return;
    const fresh = await loadSinging([URL.createObjectURL(new Blob([text], { type: "application/json" }))], location.href);
    if (!fresh.voices.length && singingCfg.voices.length) return; // couldn't reach the models just now: keep what works
    // saved only once it works, so a start offline never opens from a list it can't sing
    await c.put(SINGING_SAVED, new Response(text, { headers: { "Content-Type": "application/json" } }));
    // the live voices offered before go; the new list's are offered (the first keeps its place as "warble")
    document.querySelectorAll('#singDialog [data-engine^="warble-"]').forEach((b) => b.remove());
    document.querySelectorAll('#singEngine option[value^="warble-"]').forEach((o) => o.remove());
    for (const w of singingCfg.voices) if (!fresh.voices.some((f) => f.cfg?.sha256 === w.cfg?.sha256)) w.cancelAll?.();
    singingCfg = fresh;
    offerLiveVoices();
    syncSungControls();
    syncSingersBtn();
    if (state.singEngine && isLive(state.singEngine) && !liveVoice(state.singEngine)) prepareStems(); // that voice went: the first sings
  } catch { /* offline: the saved list stays */ }
}
const nativeEngineRaw = () => { try { return window.AHNative?.warble?.engine?.() ?? ""; } catch { return ""; } };
const nativeEngine = () => { const e = nativeEngineRaw(); return isRecorded(e) || isLive(e) ? e : null; };
// ?app where the app asks "Who sings?" at Play: nothing is loaded for either singer until it has answered
// (AHStudio.set("singEngine", …)) for the hymn that is open
// The web page asks at Play too: until then nothing is loaded for either singer, so choosing live
// singing never pays for the recordings (tens of MB) first.
let appAnswered = false;
const asksAtPlay = () => !!singingCfg.warble && !APP && !MAKE && state.singAsk !== false; // the embedded player asks too
const awaitingApp = () => !appAnswered && (APP ? nativeEngineRaw() === "ask" : asksAtPlay());
const whoSings = () => (state.instrumental ? "instrumental" : singEngine());
const singEngine = () => {
  const e = state.singEngine || nativeEngine() || singingCfg.default;
  if (!singingCfg.warble && !isRecorded(e)) return "stems";
  if (e === "stems-v2" && !manifests["stems-v2"]) return "stems"; // this hymn has no converted singers
  return isLive(e) && !liveVoice(e) ? "warble" : e; // a live voice no longer offered: the first
};
const useWarble = () => isLive(singEngine()) && !!singingCfg.warble;
const liveW = () => liveVoice(singEngine()) || singingCfg.warble; // the live voice that sings now

const tracksOfHymn = () => state.tracks.map((t) => t.filter((k) => hymn?.voices[k])).filter((t) => t.length);
const visibleTracks = () => tracksOfHymn().filter((t) => !state.hidden.includes(trackKey(t)));
const visibleVoices = () => visibleTracks().flat();
const singing = () => state.practice && state.practiceTab === "sing" && listener?.on;
const heard = (ch) => !(state.mute[ch] || (CH.some((c) => state.solo[c]) && !state.solo[ch])
  || ((singing() || following()) && state.muteMine && ch === state.singVoice)); // you sing your own part
// following your tempo, the voices are synthesised: recorded and live singers sing at one tempo only
const following = () => swm.on && swm.joined && !!listener?.on; // Sing with me, once it has joined you
const baseSound = (k) => state.voiceSounds[k] || (manifest || useWarble() ? "sung" : "choir");
// Sing with me: the piano plays the hymn for you, or the choir sings it with you (the recorded and live singers
// sing at one tempo, so they can't follow you)
const soundOf = (k) => (swm.on ? (swm.do === "piano" ? "piano" : "choir") : baseSound(k));
const hymnVoices = () => "SATB".split("").filter((k) => hymn?.voices[k]);
const anySung = () => hymnVoices().some((k) => soundOf(k) === "sung");
const anyPiano = () => hymnVoices().some((k) => soundOf(k) === "piano");
const isScoreView = () => state.view === "tracks" || state.view === "page";
const unfolded = () => state.verseLayout === "unfold";

// ---- projection: the presenter full screen, filling the window, or in a window of its own ----

let projector = null; // the separate presenter window, while open
const projectorOpen = () => projector && !projector.closed;
const stageWanted = () => state.view === "presenter" || projectorOpen();

function openProjector() {
  if (projectorOpen()) { projector.focus(); return; }
  projector = window.open("", "hymn-projector", "popup=yes,resizable=yes,width=1280,height=720");
  if (!projector) { toast("The browser blocked the new window. Allow pop-ups for this page and try again."); return; }
  const d = projector.document;
  d.title = `${hymn.number} ${hymn.title}`;
  d.body.style.cssText = "margin:0;background:#000;height:100vh;display:grid;place-items:center;overflow:hidden";
  d.body.innerHTML = `<canvas style="max-width:100vw;max-height:100vh"></canvas>
    <div id="bar" style="position:fixed;top:12px;right:12px;display:flex;gap:8px;transition:opacity .25s">
      <button id="fill" aria-label="Fill the screen" title="Fill the screen" style="width:40px;height:38px;display:grid;place-items:center;padding:0;border-radius:7px;border:1px solid #888;background:#1e2a47;color:#fff;cursor:pointer"><svg viewBox="0 0 24 24" width="21" height="21" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M7 12h10M7 12l2.5-2.5M7 12l2.5 2.5M17 12l-2.5-2.5M17 12l-2.5 2.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>
      <button id="full" aria-label="Full screen" title="Full screen (or double-click)" style="width:40px;height:38px;display:grid;place-items:center;padding:0;border-radius:7px;border:1px solid #888;background:#1e2a47;color:#fff;cursor:pointer"><svg viewBox="0 0 24 24" width="21" height="21" aria-hidden="true"><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>
    </div>
    <p id="hint" style="position:fixed;bottom:12px;left:0;right:0;text-align:center;font:15px sans-serif;color:#aaa;transition:opacity 1s">Drag this window to the projector, then use the buttons at the top right (or double-click for full screen).</p>`;
  const toggleFull = () => (d.fullscreenElement ? d.exitFullscreen() : d.documentElement.requestFullscreen().catch(() => {}));
  d.body.ondblclick = toggleFull;
  d.getElementById("full").onclick = toggleFull;
  // stretch the window over the whole screen it is on (the browser may keep its own frame)
  d.getElementById("fill").onclick = () => {
    const sc = projector.screen;
    projector.moveTo(sc.availLeft ?? 0, sc.availTop ?? 0);
    projector.resizeTo(sc.availWidth, sc.availHeight);
  };
  // the controls show while the mouse moves, then get out of the way
  const bar = d.getElementById("bar");
  let hideTimer;
  const showBar = () => { bar.style.opacity = 1; d.body.style.cursor = "default"; clearTimeout(hideTimer); hideTimer = setTimeout(() => { bar.style.opacity = 0; d.body.style.cursor = "none"; }, 2500); };
  d.addEventListener("mousemove", showBar);
  showBar();
  setTimeout(() => { const hint = d.getElementById("hint"); if (hint) hint.style.opacity = 0; }, 6000);
  projector.addEventListener("beforeunload", () => { projector = null; });
  prepareStage().then(() => paint(true));
}

// copy the stage into the projector window, scaled to fit
function mirrorProjector() {
  if (!projectorOpen()) return;
  const src = $("stage");
  const c = projector.document.querySelector("canvas");
  if (!c) return;
  const w = projector.innerWidth;
  const h = projector.innerHeight;
  const k = Math.min(w / src.width, h / src.height);
  const dpr = projector.devicePixelRatio || 1;
  const cw = Math.round(src.width * k * dpr);
  if (c.width !== cw) { c.width = cw; c.height = Math.round(src.height * k * dpr); c.style.width = `${src.width * k}px`; c.style.height = `${src.height * k}px`; }
  c.getContext("2d").drawImage(src, 0, 0, c.width, c.height);
}

function enterFullPage() {
  if (state.view !== "presenter") { state.view = "presenter"; save("view"); renderAll(); }
  document.body.classList.add("full-page");
  toast("Press Esc to leave full page.", 2500);
}
const leaveFullPage = () => document.body.classList.remove("full-page");

// Written out, the score runs every sung verse one after another, so a position inside verse
// pass k sits at (that verse's place among the sung verses) * totalQ + q in the score.
function verseOrdinal(loc) {
  if (!loc) return 0;
  const p = perf.passes[loc.pass];
  if (p.kind === "verse") return perf.passes.slice(0, loc.pass).filter((x) => x.kind === "verse").length;
  return null; // introductions and interludes have no copy of their own
}
function scoreQ(loc) {
  if (!loc) return null;
  if (!unfolded()) return loc.q;
  // an introduction or interlude lights up in the copy of the verse that comes next
  const j = verseOrdinal(loc) ?? Math.min(state.verses.length - 1, perf.passes.slice(0, loc.pass).filter((x) => x.kind === "verse").length);
  return j * hymn.totalQ + loc.q;
}
/** From a position in the score back to a performance time. */
function timeOfScoreQ(sq) {
  if (!unfolded()) {
    const loc = locate(perf, engine.now());
    const k = loc && loc.kind === "verse" ? loc.pass : perf.passes.findIndex((p) => p.kind === "verse");
    return passTime(perf, k, sq);
  }
  const j = Math.floor(sq / hymn.totalQ + 1e-9);
  const ks = perf.passes.map((p, i) => (p.kind === "verse" ? i : -1)).filter((i) => i >= 0);
  return passTime(perf, ks[Math.min(j, ks.length - 1)], sq - j * hymn.totalQ);
}

// ---- key ------------------------------------------------------------------

function shiftAt(k, pass, q) {
  let s = state.transpose;
  // the classic last-verse lift: only the final sung verse moves up
  if (state.lastVerseUp && state.verses.length > 1 && pass.kind === "verse" && pass.verse === state.verses[state.verses.length - 1]) s += state.lastVerseUp;
  for (const c of liveChanges) if (c.k < k || (c.k === k && c.q <= q + 1e-6)) s += c.delta;
  return s;
}
const currentShift = (loc) => (perf && loc ? shiftAt(loc.pass, perf.passes[loc.pass], loc.q) : perf ? shiftAt(0, perf.passes[0], 0) : state.transpose);
const keyFor = (shift) => keyAfter(hymn, shift);
// Verovio takes a key name for major hymns (so its spelling matches ours), semitones otherwise
const verovioTranspose = (shift) => (!shift ? "" : hymn.key.mode === "minor" ? String(shift) : keyFor(shift).name);
const chordLabel = (name, shift = renderedShift) => prettyChord(transposeChordName(name, keyFor(shift)));

function syncKeyLabel(shift = renderedShift) {
  const k = keyFor(shift);
  $("keyLabel").textContent = prettyChord(k.name) + (hymn.key.mode === "minor" ? "m" : "");
  $("keyLabel").title = shift ? `Transposed ${shift > 0 ? "up" : "down"} ${Math.abs(shift)} semitone${Math.abs(shift) === 1 ? "" : "s"} from ${prettyChord(keyFor(0).name)}. Click to go back to the written key.` : "The written key";
  $("keyLabel").classList.toggle("moved", !!shift);
}

/** Up or down a semitone: from the next bar while playing, for the whole hymn when stopped. */
function changeKey(delta) {
  if (!perf) return;
  const loc = engine.playing ? locate(perf, engine.now()) : null;
  if (loc) {
    let k = loc.pass;
    let q = barEnd(hymn, barAt(hymn, loc.q));
    if (q >= perf.passes[k].qTo - 1e-6 && perf.passes[k + 1]) { k += 1; q = perf.passes[k].qFrom; }
    liveChanges.push({ k, q, delta });
    const live = useWarble() && anySung() && !awaitingApp();
    const to = prettyChord(keyFor(shiftAt(k, perf.passes[k], q)).name);
    toast(`Moving to ${to} at bar ${barAt(hymn, q)}.`, 3000);
    if (live) { rebuild(true, true); paint(true); prepareWarble(true); } // the live singers follow into the new key
    else rebuild();
  } else {
    state.transpose = Math.max(-11, Math.min(11, state.transpose + delta));
    store.set(`transpose:${hymn.id}`, state.transpose);
    if (anySung()) prepareStems(); else rebuild();
    renderAll();
  }
  noteStemsTransposed();
}

function resetKey() {
  liveChanges = [];
  state.transpose = 0;
  store.set(`transpose:${hymn.id}`, 0);
  if (anySung()) prepareStems(); else rebuild();
  renderAll();
}

function noteStemsTransposed() {
  if (useWarble()) return; // live singing sings any key
  if (anySung() && stemInfo.size && perf.events.some((e) => !e.silent && !e.inst && "SATB".includes(e.ch) && e.pass >= 0)) {
    if (!noteStemsTransposed.shown) toast("The recorded singers sing in the key they were recorded in, so after a key change the synth sings. Live singing follows the key.", 6000);
    noteStemsTransposed.shown = true;
  }
}

// ---- icons ----------------------------------------------------------------

const ICON = {
  mute: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h4l5-4v14l-5-4H4z" fill="currentColor"/><path d="M16.5 9.5l5 5m0-5l-5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>',
  solo: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 15v-3a8 8 0 0 1 16 0v3" stroke="currentColor" stroke-width="2" fill="none"/><rect x="3" y="14" width="5" height="7" rx="1.5" fill="currentColor"/><rect x="16" y="14" width="5" height="7" rx="1.5" fill="currentColor"/></svg>',
  words: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h11M4 17h14" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  hide: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" stroke="currentColor" stroke-width="2" fill="none"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>',
  show: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z" stroke="currentColor" stroke-width="2" fill="none"/><path d="M4 20L20 4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  grip: '<svg viewBox="0 0 24 8" aria-hidden="true"><g fill="currentColor"><circle cx="6" cy="2" r="1.4"/><circle cx="12" cy="2" r="1.4"/><circle cx="18" cy="2" r="1.4"/><circle cx="6" cy="6" r="1.4"/><circle cx="12" cy="6" r="1.4"/><circle cx="18" cy="6" r="1.4"/></g></svg>',
};

function toast(text, ms = 4200, action = null) {
  const el = $("toast");
  el.innerHTML = "";
  el.append(document.createTextNode(text));
  if (action) {
    const b = document.createElement("button");
    b.className = "toast-act";
    b.textContent = action.label;
    b.onclick = () => { el.hidden = true; action.fn(); };
    el.append(b);
  }
  el.hidden = false;
  clearTimeout(toast.timer);
  if (ms) toast.timer = setTimeout(() => { el.hidden = true; }, ms);
}

function readColors() {
  const cs = getComputedStyle(document.documentElement);
  const v = (n) => cs.getPropertyValue(`--${n}`).trim();
  colors = {
    paper: v("paper"), paperClear: "rgba(252,251,247,0)", cloth: v("cloth"), ink: v("ink"), muted: v("muted"),
    rule: v("rule"), gilt: v("gilt"), loop: v("loop"), S: v("S"), A: v("A"), T: v("T"), B: v("B"), acc: v("acc"),
  };
  colors.lyric = colors.S;
  colors.stage = "#f4ecd9"; // the presenter and its videos: cream, softer than white
}

// ---- boot -----------------------------------------------------------------


let hymnList = [];
/** A download that gives up after [ms] (a weak connection never holds the player up for good). */
function fetchWithin(url, ms, opts = {}) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  return fetch(url, { ...opts, signal: ctl.signal }).finally(() => clearTimeout(t));
}
/** The app: hymns changed on the site since this copy of the player, saved on the phone by [syncHymns]. */
const HYMNS = "ah-hymns";
const hymnStore = async () => { try { return await caches.open(HYMNS); } catch { return null; } };
const SITE_INDEX = "https://ah-hymns.invalid/site-index.json"; // the site's list, as last fetched
const SAVED_V = "ah-hymn-saved"; // { id: the version of the copy saved in HYMNS }
const savedV = () => { try { return JSON.parse(localStorage.getItem(SAVED_V) || "{}"); } catch { return {}; } };
/** Hymns new on the site come at the next check (never while one opens). */
let listFresh = Promise.resolve();
/** Lay the site's list over the player's own: where each hymn's newest copy is, which have singers, new hymns. */
function overlaySite(site) {
  // a number the site no longer has, in a hymnal the site lists, goes (hymnals it doesn't publish stay)
  const onSite = new Set(site.map((x) => x.id));
  const siteBooks = new Set(site.map((x) => x.book));
  const kept = hymnList.filter((x) => !siteBooks.has(x.book) || onSite.has(x.id));
  let added = kept.length !== hymnList.length;
  if (added) hymnList = kept;
  const have = new Map(hymnList.map((x) => [x.id, x]));
  for (const x of site) {
    const remote = new URL(x.path, DATA).href;
    const mine = have.get(x.id);
    if (mine) Object.assign(mine, { remote, siteV: x.v, sung: x.sung, sv: x.sv, svc: x.svc, title: x.title });
    else { hymnList.push({ ...x, path: null, remote, siteV: x.v }); added = true; }
  }
  return added;
}
/** The site's hymn list now (a hymn asked for that this copy doesn't know yet): saved and laid over the list,
 *  then the full check runs in the background. At most once a minute; false when the site can't be reached. */
let siteAskedAt = 0;
async function siteListNow() {
  if (!DATA || Date.now() - siteAskedAt < 60e3) return false;
  siteAskedAt = Date.now();
  try {
    const r = await fetchWithin(`${DATA}data/index.json`, 10000, { cache: "no-cache" });
    if (!r.ok) return false;
    const site = await r.json();
    const c = await hymnStore();
    if (c) await c.put(SITE_INDEX, new Response(JSON.stringify(site), { headers: { "Content-Type": "application/json" } }));
    if (overlaySite(site)) fillPicker();
    syncHymns(true).catch(() => {});
    return true;
  } catch { return false; }
}
async function loadList() {
  // only what is on the phone: opening the player never waits for the internet
  const local = () => fetch("data/index.json", { cache: "no-cache" }).catch(() => fetch("data/index.json", { cache: "force-cache" }));
  hymnList = await (await local()).json();
  if (DATA) {
    const c = await hymnStore();
    const site = c && (await c.match(SITE_INDEX).then((r) => r?.json()).catch(() => null));
    if (site) overlaySite(site);
  }
  fillPicker();
  if (DATA) setTimeout(() => syncHymns().catch(() => {}), 15000); // once the first hymn is up
}

/** Now and then (at most every 6 hours): what changed on the site, saved on the phone in the background.
 *  Every version is the SHA-256 of the content (hymnversion.py), so nothing changed goes unnoticed:
 *  - data/versions.json first (a few hundred bytes; nothing at all when unchanged, the store answers 304):
 *    its "root" unchanged, the check stops there;
 *  - else the list of hymns, looking only at the hymnals whose version changed;
 *  - a hymn whose version differs is checked against the copy already here (the player's own, or saved)
 *    before anything is downloaded; recordings lists likewise.
 *  A weak connection only delays it: what didn't arrive is looked at again next time. */
async function syncHymns(force = false) {
  const AT = "ah-hymn-sync-at";
  try { if (!force && Date.now() - Number(localStorage.getItem(AT) || 0) < 6 * 3600e3) return; } catch { /* no storage: check */ }
  const c = await hymnStore();
  if (!c) return;
  const done = () => { try { localStorage.setItem(AT, String(Date.now())); } catch { /* full */ } };
  const singingSaved = async () => {
    try {
      const g = await fetchWithin(`${DATA}data/singing.json`, 15000, { cache: "no-cache" });
      if (g.ok) await c.put(SINGING_SAVED, g);
    } catch { /* next time */ }
  };
  const VERSIONS = "ah-hymn-versions"; // the site's versions.json as last brought fully up to date here
  let ver = null;
  try { const v = await fetchWithin(`${DATA}data/versions.json`, 15000, { cache: "no-cache" }); if (v.ok) ver = await v.json(); } catch { /* the whole list */ }
  let known = {}; try { known = JSON.parse(localStorage.getItem(VERSIONS) || "{}"); } catch { /* none */ }
  if (ver?.root && ver.root === known.root) { await singingSaved(); done(); return; }
  const same = (x) => !!ver?.books && !!known.books?.[x.book] && known.books[x.book] === ver.books[x.book];
  const r = await fetchWithin(`${DATA}data/index.json`, 15000, { cache: "no-cache" });
  if (!r.ok) return;
  const site = await r.json();
  const saved = savedV();
  const own = ownMatches();
  const mine = new Map(hymnList.map((x) => [x.id, x]));
  let missed = false; // something didn't arrive: this check doesn't count as complete
  const keep = () => { try { localStorage.setItem(SAVED_V, JSON.stringify(saved)); localStorage.setItem(OWN_V, JSON.stringify(own)); } catch { /* full */ } };
  await inParallel(site.filter((x) => !same(x)), 6, async (x) => {
    const mineX = mine.get(x.id);
    if (!x.v || x.v === saved[x.id] || x.v === mineX?.v || x.v === own[x.id]) return;
    const url = new URL(x.path, DATA).href;
    try {
      // the copy already here may be this very version (the same content, only versioned differently before)
      if (mineX?.path && (await sha256(await (await fetch(mineX.path)).arrayBuffer())) === x.v) { own[x.id] = x.v; return; }
      const here = await c.match(url).catch(() => null);
      if (here && (await sha256(await here.arrayBuffer())) === x.v) { saved[x.id] = x.v; return; }
      const h = await fetchWithin(url, 15000, { cache: "no-cache" });
      if (!h.ok) { missed = true; return; }
      const body = await h.arrayBuffer();
      const got = await sha256(body);
      if (got && got !== x.v) { missed = true; return; } // not the version the list names (caught mid-publish): next time
      await c.put(url, new Response(body, { headers: { "Content-Type": "application/json" } }));
      saved[x.id] = x.v;
    } catch { missed = true; }
  });
  keep();
  // the recorded singers' lists that changed, and the converted singers' ("Recorded singers v2"), so opening
  // a hymn never asks the site
  for (const [KEY, dir, field] of [["ah-singers-saved", "audio", "sv"], ["ah-svc-saved", "audio-svc", "svc"]]) {
    let have = {}; try { have = JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { /* none */ }
    await inParallel(site.filter((x) => !same(x) && x[field] && have[x.id] !== x[field] && (field !== "sv" || x.sung)), 6, async (x) => {
      const url = `${AUDIO}${dir}/${x.id}/manifest.json`;
      try {
        const here = await singers.saved(url) || await (await singers.lists())?.match(url);
        if (here?.ok && (await sha256(await here.clone().arrayBuffer())) === x[field]) { have[x.id] = x[field]; return; }
        if (await singers.refreshManifest(url)) have[x.id] = x[field]; else missed = true;
      } catch { missed = true; }
    });
    try { localStorage.setItem(KEY, JSON.stringify(have)); } catch { /* full */ }
  }
  await singingSaved();
  await c.put(SITE_INDEX, new Response(JSON.stringify(site), { headers: { "Content-Type": "application/json" } }));
  // every hymnal up to date now, unless something didn't arrive (then all of it is looked at next time)
  if (ver?.root && !missed) try { localStorage.setItem(VERSIONS, JSON.stringify({ root: ver.root, books: ver.books, published: ver.published })); } catch { /* full */ }
  const before = hymn && hymnList.find((x) => x.id === hymn.id);
  const had = before && `${!!before.sung}${!!before.svc}`;
  if (overlaySite(site)) fillPicker();
  // the hymn open now gained singers (recorded, or v2) in the site's newer list: they join it
  if (before && had !== `${!!before.sung}${!!before.svc}`) loadManifest().then(() => prepareStems()).catch(() => {});
  done();
}

/** The SHA-256 of some bytes, in hex (as hymnversion.py writes the versions); null where the browser can't
 *  (a page not served securely): then nothing is taken as matching, and downloads aren't checked. */
async function sha256(buf) {
  if (!globalThis.crypto?.subtle) return null;
  const d = await crypto.subtle.digest("SHA-256", buf);
  return [...new Uint8Array(d)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
/** [fn] over [items], [n] at a time. */
async function inParallel(items, n, fn) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) await fn(items[i++]); }));
}
/** Hymns whose copy in the player itself is the site's version (checked by its SHA-256): { id: version }. */
const OWN_V = "ah-hymn-own";
const ownMatches = () => { try { return JSON.parse(localStorage.getItem(OWN_V) || "{}"); } catch { return {}; } };

/** A hymn's score, from the phone: the copy saved from the site when it is the site's newest (or the
 *  player's own is older), else the player's own. Only a hymn new on the site and not yet saved waits
 *  for the internet, at most 10 s. */
async function hymnJson(entry) {
  const own = entry.path;
  if (!entry.remote) return (await fetch(own)).json();
  // the player's own copy is out of date (unless the check found it is the site's version after all)
  const newest = entry.siteV && entry.v !== entry.siteV && ownMatches()[entry.id] !== entry.siteV;
  if (newest || !own) {
    const c = await hymnStore();
    const saved = c && (await c.match(entry.remote).catch(() => null));
    if (saved) try { return await saved.json(); } catch { /* broken: below */ }
  }
  if (own) return (await fetch(own)).json();
  const r = await fetchWithin(entry.remote, 10000);
  if (!r.ok) throw new Error(String(r.status));
  const keep = r.clone();
  hymnStore().then((c) => c?.put(entry.remote, keep)).catch(() => {});
  return r.json();
}

function fillPicker() {
  $("hymnPicker").innerHTML = hymnList.map((x) => `<option value="${x.id}">${x.book} ${x.number}, ${x.title}</option>`).join("");
  setupFinder();
}

// ---- the hymn finder: search, and the dropdown of every hymn, filtered by hymnal and sound, sorted ----

// short names for the hymnals; a hymnal not listed here shows its code
const BOOK_NAMES = {
  SDAH: "Seventh-day Adventist Hymnal", NZK: "Nyimbo za Kristo", WN: "Wende Nyasaye", CH1941: "Church Hymnal 1941",
  CS1900: "Christ in Song 1900", CS1908: "Christ in Song 1908", HT1876: "Hymns and Tunes 1876", AHC: "Advent Hymnals Collection",
  RECORDED: "Recorded",
};
const BOOK_ORDER = ["SDAH", "NZK", "WN", "CH1941", "CS1908", "CS1900", "HT1876", "AHC"]; // the hymnals in use first, then the older ones
const bookRank = (b) => (BOOK_ORDER.indexOf(b) + 1) || 99;
const bookCodes = () => [...new Set(hymnList.map((x) => x.book))].sort((a, b) => bookRank(a) - bookRank(b) || a.localeCompare(b));
const bookName = (b) => BOOK_NAMES[b] || b;
const SOUNDS = [["all", "All"], ["sung", "Singers ready"], ["midi", "MIDI only"]];
// "auto": by hymnal and number, or best match first while searching
const SORTS = [["auto", "Hymnal, number"], ["number", "Number 1→9"], ["number-desc", "Number 9→1"],
  ["title", "Title A→Z"], ["title-desc", "Title Z→A"], ["book", "Hymnal A→Z"]];
const finder = {
  q: "", books: store.get("finderBooks", []), sound: store.get("finderSound", "all"), sort: store.get("finderSort", "auto"),
  bookQ: "", shown: [], active: 0, ready: false,
};
const escHtml = (t) => String(t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
const normQ = (t) => String(t).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9 ]+/g, " ").replace(/\s+/g, " ").trim();
const numOf = (x) => parseInt(x.number, 10) || 0;
const byBookNum = (a, b) => bookRank(a.book) - bookRank(b.book) || a.book.localeCompare(b.book) || numOf(a) - numOf(b);
const titleKey = (x) => normQ(x.title).replace(/^(the|a|o) /, "");
const SORTERS = {
  number: (a, b) => numOf(a) - numOf(b) || byBookNum(a, b),
  "number-desc": (a, b) => numOf(b) - numOf(a) || byBookNum(a, b),
  title: (a, b) => titleKey(a).localeCompare(titleKey(b)) || byBookNum(a, b),
  "title-desc": (a, b) => titleKey(b).localeCompare(titleKey(a)) || byBookNum(a, b),
  book: (a, b) => bookName(a.book).localeCompare(bookName(b.book)) || numOf(a) - numOf(b),
};

// ---- full-text search: titles, every verse and the writers, forgiving typos (MiniSearch, in the page: works offline) ----

const search = { ms: null, words: null, loading: null, terms: new Map(), snips: new Map() };
// one term per word: lower case, no accents, apostrophes dropped ("o'er" -> "oer", "'tis" -> "tis")
const termOf = (t) => t.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]+/g, "");
const tokenize = (text) => String(text).split(/[\s\-–—_/,.;:!?"“”‘’()[\]{}…]+/);
// short words that say little on their own, for deciding what a partial match must contain
const WEAK = new Set(["when", "am", "are", "was", "were", "will", "shall", "so", "as", "by", "from", "this", "that", "his", "her", "its", "your", "you", "who", "what", "how", "not", "no", "but", "or", "if", "then", "there", "here", "into", "up", "out", "day", "come", "let", "hymn", "song", "about"]);
const STOP = new Set(["the", "a", "an", "and", "of", "to", "in", "o", "is", "my", "me", "i", "we", "our", "thy", "thee", "thou", "for", "with", "be", "on", "at", "it", "us", "his", "he", "all"]);

function loadScript(src) {
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.charset = "utf-8"; // Verovio carries its program as text: read any other way, it doesn't compile
    s.src = src;
    s.onload = resolve;
    s.onerror = reject;
    document.head.append(s);
  });
}

/** Load the words and build the index, once, the first time someone searches with words. */
function ensureSearch() {
  search.loading ??= (async () => {
    const local = () => fetch("data/words.json", { cache: "no-cache" }).catch(() => fetch("data/words.json", { cache: "force-cache" }));
    let words = null;
    if (DATA) {
      try { const r = await fetch(`${DATA}data/words.json`, { cache: "no-cache" }); if (r.ok) words = await r.json(); } catch { /* offline: the bundled copy */ }
    }
    if (!words) words = await (await local()).json();
    if (!window.MiniSearch) await loadScript("vendor/minisearch-7.1.0.min.js");
    const ms = new window.MiniSearch({
      fields: ["title", "first", "words", "by"],
      tokenize,
      processTerm: (t) => termOf(t) || null,
      searchOptions: {
        boost: { title: 4, first: 2.5, by: 1.5 },
        // the word being typed may be unfinished; longer words may be mistyped
        prefix: (term, i, terms) => i === terms.length - 1 || term.length > 4,
        fuzzy: (term) => (term.length > 7 ? 0.25 : term.length > 3 ? 1 : false),
        weights: { fuzzy: 0.35, prefix: 0.6 },
      },
    });
    ms.addAll(hymnList.map((x) => {
      const w = words[x.id] || { v: [], by: "" };
      const first = (w.v[0] || "").split(/(?<=[,;:.!?])\s+/).slice(0, 2).join(" ");
      return { id: x.id, title: x.title, first, words: w.v.join(" \n "), by: w.by || "" };
    }));
    search.words = words;
    search.ms = ms;
  })().catch((e) => { search.loading = null; throw e; });
  return search.loading;
}

// ---- search by idea: hymns close in meaning, from the server (online only; offline the words still work) ----

const idea = { q: "", books: "", ids: [], lines: new Map(), timer: 0, ctrl: null };
const ideaWanted = (q) => (normQ(q).match(/[a-z]{2,}/g) || []).length >= 2 && !/^\s*[a-z]*\d*\s*\d+\s*$/i.test(q);

function askIdea(q) {
  clearTimeout(idea.timer);
  if (!ideaWanted(q) || !navigator.onLine) { idea.q = ""; idea.ids = []; return; }
  const books = finder.books.join(",");
  if (q === idea.q && books === idea.books) return;
  idea.timer = setTimeout(async () => {
    idea.ctrl?.abort();
    idea.ctrl = new AbortController();
    try {
      const u = new URL(IDEA_API, location.href);
      u.searchParams.set("q", q);
      u.searchParams.set("limit", "50");
      if (books) u.searchParams.set("books", books);
      const r = await fetch(u, { signal: idea.ctrl.signal });
      if (!r.ok) throw new Error(String(r.status));
      const data = await r.json();
      const have = new Set(hymnList.map((x) => x.id));
      const rows = data.results.filter((x) => have.has(x.hymn_id) && x.score >= 0.45); // only hymns this player can play
      Object.assign(idea, { q, books, ids: rows.map((x) => x.hymn_id), lines: new Map(rows.map((x) => [x.hymn_id, x.line])) });
      if (finder.q === q) renderFinder();
    } catch { /* offline or the server is busy: the words search stands alone */ }
  }, 350);
}

/** Hymns matching words: ids with a score, best first, and the terms each matched. */
function wordHits(q) {
  if (!search.ms) return null;
  const qTerms = tokenize(q).map(termOf).filter(Boolean);
  if (!qTerms.length) return [];
  // every word must be there (allowing typos); if nothing has them all, the hymns with most of them
  let res = search.ms.search(q, { combineWith: "AND" });
  let partial = false;
  if (!res.length) {
    // the hymns with at least half the words that carry meaning ("afraid", "alone"; not "when", "I", "am")
    const meaningful = [...new Set(qTerms.filter((t) => !STOP.has(t) && !WEAK.has(t)))];
    const need = Math.max(1, Math.ceil(meaningful.length / 2));
    res = search.ms.search(q, { combineWith: "OR" })
      .filter((r) => r.queryTerms.filter((t) => meaningful.includes(t)).length >= need)
      .slice(0, 20);
    partial = true;
  }
  search.partial = partial && res.length > 0;
  const phrase = qTerms.join(" ");
  const out = res.map((r) => {
    const w = search.words[r.id];
    const all = ` ${tokenize((w?.v || []).join(" ")).map(termOf).filter(Boolean).join(" ")} `;
    const title = ` ${tokenize(hymnList.find((x) => x.id === r.id)?.title || "").map(termOf).join(" ")} `;
    let s = r.score;
    if (qTerms.length > 1 && title.includes(` ${phrase} `)) s *= 4; // the exact words, in order
    else if (qTerms.length > 1 && all.includes(` ${phrase} `)) s *= 3;
    else if (title.startsWith(` ${phrase}`)) s *= 2;
    search.terms.set(r.id, new Set(r.terms));
    return { id: r.id, s, partial };
  });
  return out.sort((a, b) => b.s - a.s);
}

/** The line of the hymn the search matched, when the title doesn't show why it's there. */
function snippetFor(id, q) {
  const w = search.words?.[id];
  const terms = search.terms.get(id);
  if (!w || !terms) return "";
  const x = hymnList.find((h) => h.id === id);
  const titleTerms = new Set(tokenize(x?.title || "").map(termOf));
  const wanted = [...terms].filter((t) => !titleTerms.has(t));
  if (!wanted.length) return "";
  const phrase = tokenize(q).map(termOf).filter(Boolean).join(" ");
  let best = null;
  for (const verse of w.v) {
    const chunks = verse.split(/(?<=[,;:.!?])\s+/);
    for (let i = 0; i < chunks.length; i++) {
      for (const span of [1, 2]) { // a phrase may run over a comma
        const text = chunks.slice(i, i + span).join(" ");
        const ts = tokenize(text).map(termOf);
        const hits = wanted.filter((t) => ts.includes(t)).length + (phrase && ` ${ts.join(" ")} `.includes(` ${phrase} `) ? 10 : 0);
        const score = hits * 10 - span - text.length / 200;
        if (hits && (!best || score > best.score)) best = { score, text };
      }
    }
  }
  if (!best) return "";
  // mark the matched words
  return best.text.split(/(\s+)/).map((tok) => {
    const t = termOf(tok);
    return t && terms.has(t) && !STOP.has(t) ? `<mark>${escHtml(tok)}</mark>` : escHtml(tok);
  }).join("");
}

/** The hymns the finder shows: those in the chosen hymnals and sound, in the chosen order.
 *  A number ("240", "nzk 89") finds by number; words search the titles, verses and writers. */
function finderMatches(q, { books = finder.books, sound = finder.sound, sort = finder.sort } = {}) {
  const nq = normQ(q);
  const keep = (x) => !(books.length && !books.includes(x.book)) && !(sound === "sung" && !x.sung) && !(sound === "midi" && x.sung);
  if (!nq) return hymnList.filter(keep).sort(SORTERS[sort] || byBookNum);
  search.terms = new Map(); // which words each hymn matched, for its line under the title
  search.partial = false;
  const scored = new Map(); // id -> score
  const m = nq.match(/^([a-z]+\d*)?\s*(\d+)$/); // "240", or "nzk 89"
  if (m) {
    for (const x of hymnList) {
      if (m[1] && !x.book.toLowerCase().startsWith(m[1])) continue;
      if (x.number === m[2]) scored.set(x.id, 1e6 + (x.book === "SDAH" ? 1 : 0));
      else if (x.number.startsWith(m[2])) scored.set(x.id, 1e5 - x.number.length);
    }
  }
  const hits = /[a-z]/.test(nq) ? wordHits(q) : [];
  if (hits === null) {
    // the words are still loading: titles for now
    const words = nq.split(" ");
    for (const x of hymnList) {
      const t = normQ(x.title);
      if (t.startsWith(nq)) scored.set(x.id, Math.max(scored.get(x.id) || 0, 80));
      else if (words.every((w) => t.includes(w))) scored.set(x.id, Math.max(scored.get(x.id) || 0, 50));
    }
  } else {
    for (const h of hits) if (!scored.has(h.id)) scored.set(h.id, h.s);
  }
  const byId = new Map(hymnList.map((x) => [x.id, x]));
  const out = [...scored.keys()].map((id) => byId.get(id)).filter((x) => x && keep(x));
  if (SORTERS[sort]) return out.sort(SORTERS[sort]);
  return out.sort((a, b) => scored.get(b.id) - scored.get(a.id) || byBookNum(a, b));
}

function markMatch(title, q) {
  const words = normQ(q).split(" ").filter((w) => w.length > 1 && !/^\d+$/.test(w));
  let html = escHtml(title);
  for (const w of words) html = html.replace(new RegExp(`(${w})`, "i"), "<mark>$1</mark>");
  return html;
}

function setupFinder() {
  if (finder.ready) { renderFinder(); return; }
  finder.ready = true;
  const top = $("finderTop"), query = $("finderQuery"), panel = $("finderPanel"), btn = $("finderBtn"), list = $("finderList");
  const books = bookCodes();
  finder.books = finder.books.filter((b) => books.includes(b));
  if (!SOUNDS.some(([k]) => k === finder.sound)) finder.sound = "all";
  if (!SORTS.some(([k]) => k === finder.sort)) finder.sort = "auto";
  const open = (focusPanel) => {
    if (panel.hidden) {
      panel.hidden = false;
      showBooks(false);
      btn.setAttribute("aria-expanded", "true");
      top.setAttribute("aria-expanded", "true");
      renderFinder(true);
    }
    if (focusPanel && matchMedia("(pointer: fine)").matches) query.focus(); // no keyboard popping up on a phone
  };
  const close = () => {
    panel.hidden = true;
    btn.setAttribute("aria-expanded", "false");
    top.setAttribute("aria-expanded", "false");
  };
  finder.close = close;
  const setQ = (v, from) => {
    finder.q = v;
    askIdea(v.trim());
    if (/[a-z]/i.test(v) && !search.ms) ensureSearch().then(() => { if (finder.q) renderFinder(); }).catch(() => toast("The search could not load the words; titles and numbers still work.", 5000));
    if (from !== top) top.value = v;
    if (from !== query) query.value = v;
    finder.active = 0;
    renderFinder(!v);
  };
  btn.onclick = () => (panel.hidden ? open(true) : close());
  top.oninput = () => { open(false); showBooks(false); setQ(top.value, top); };
  top.onfocus = () => { if (top.value) open(false); };
  query.oninput = () => setQ(query.value, query);
  const keys = (e) => {
    const n = finder.shown.length;
    if (e.key === "ArrowDown") { e.preventDefault(); open(false); finder.active = Math.min(finder.active + 1, n - 1); highlight(); }
    else if (e.key === "ArrowUp") { e.preventDefault(); finder.active = Math.max(finder.active - 1, 0); highlight(); }
    else if (e.key === "PageDown") { e.preventDefault(); finder.active = Math.min(finder.active + 10, n - 1); highlight(); }
    else if (e.key === "PageUp") { e.preventDefault(); finder.active = Math.max(finder.active - 10, 0); highlight(); }
    else if (e.key === "Enter") { e.preventDefault(); if (finder.shown[finder.active]) chooseHymn(finder.shown[finder.active].id); }
    else if (e.key === "Escape") { if (!panel.hidden) { e.stopPropagation(); close(); } else if (top.value) setQ("", null); }
  };
  top.onkeydown = keys;
  query.onkeydown = keys;
  list.onclick = (e) => { const li = e.target.closest("li[data-id]"); if (li) chooseHymn(li.dataset.id); };
  list.onmousemove = (e) => {
    const li = e.target.closest("li[data-id]");
    if (li && Number(li.dataset.i) !== finder.active) { finder.active = Number(li.dataset.i); highlight(false); }
  };
  const refilter = () => { finder.active = 0; renderFinder(!finder.q); };
  const setBooks = (b) => {
    finder.books = b.length === books.length ? [] : b;
    store.set("finderBooks", finder.books);
    askIdea(finder.q.trim());
    refilter();
    renderBookList();
  };
  $("finderSound").onclick = (e) => {
    const b = e.target.closest("button");
    if (!b) return;
    finder.sound = b.dataset.sound;
    store.set("finderSound", finder.sound);
    refilter();
  };
  $("finderSort").innerHTML = SORTS.map(([k, label]) => `<option value="${k}">${label}</option>`).join("");
  $("finderSort").onchange = (e) => { finder.sort = e.target.value; store.set("finderSort", finder.sort); refilter(); };
  // the chosen hymnals, each a chip that takes it off again
  $("finderPicked").onclick = (e) => {
    if (e.target.closest("button[data-more]")) { showBooks(true); return; }
    const b = e.target.closest("button[data-book]");
    if (b) setBooks(finder.books.filter((x) => x !== b.dataset.book));
  };

  // the hymnals: a searchable checklist of its own, so hundreds of hymnals still fit, phone or desktop
  const showBooks = (on) => {
    $("finderMain").hidden = on;
    $("finderBooksView").hidden = !on;
    if (on) {
      const all = bookCodes();
      finder.bookOrder = [...all.filter((b) => finder.books.includes(b)), ...all.filter((b) => !finder.books.includes(b))];
      finder.bookQ = "";
      $("finderBookQuery").value = "";
      renderBookList();
      if (matchMedia("(pointer: fine)").matches) $("finderBookQuery").focus();
    }
  };
  $("finderBooksBtn").onclick = () => showBooks(true);
  $("finderBack").onclick = $("finderBooksDone").onclick = () => { showBooks(false); renderFinder(!finder.q); };
  $("finderBooksAll").onclick = () => setBooks([]);
  $("finderBookQuery").oninput = (e) => { finder.bookQ = e.target.value; renderBookList(); };
  $("finderBookQuery").onkeydown = (e) => { if (e.key === "Escape") { e.stopPropagation(); showBooks(false); } };
  $("finderBookList").onchange = (e) => {
    const code = e.target.value;
    // starting from "all", the first tick narrows to that one hymnal
    setBooks(e.target.checked ? [...finder.books, code] : (finder.books.length ? finder.books : books).filter((x) => x !== code));
  };

  // outside the finder closes it
  document.addEventListener("pointerdown", (e) => { if (!panel.hidden && !e.target.closest("#finder")) close(); });
  // "/" jumps to the search box, as on most sites
  document.addEventListener("keydown", (e) => {
    if (e.key === "/" && !e.target.closest("input, select, textarea, [contenteditable]")) { e.preventDefault(); top.focus(); top.select(); }
  });
  renderFinder();
}

function renderBookList() {
  const nq = normQ(finder.bookQ);
  const inSound = finderMatches("", { books: [], sound: finder.sound, sort: "auto" });
  const codes = (finder.bookOrder || bookCodes()).filter((b) => !nq || normQ(`${b} ${bookName(b)}`).includes(nq));
  $("finderBooksAll").setAttribute("aria-pressed", String(!finder.books.length));
  $("finderBookList").innerHTML = codes.length ? codes.map((b) => `<li><label>
      <input type="checkbox" value="${escHtml(b)}"${finder.books.includes(b) ? " checked" : ""}>
      <span class="b-name">${escHtml(bookName(b))}${bookName(b) !== b ? `<small>${escHtml(b)}</small>` : ""}</span>
      <span class="b-n">${inSound.filter((x) => x.book === b).length}</span>
    </label></li>`).join("") : `<li class="finder-empty">No hymnal matches “${escHtml(finder.bookQ.trim())}”.</li>`;
  $("finderBooksDone").textContent = `Show ${finderMatches(finder.q).length} hymns`;
}

function chooseHymn(id) {
  finder.close?.();
  $("finderTop").blur();
  const picker = $("hymnPicker");
  if (picker.value === id && !document.body.classList.contains("missing")) return;
  picker.value = id;
  picker.dispatchEvent(new Event("change"));
  syncFinderLabel();
}

function syncFinderLabel() {
  const x = hymnList.find((h) => h.id === $("hymnPicker").value);
  $("finderLabel").textContent = x ? `${x.book} ${x.number}` : "Hymns";
}

function renderFinder(scrollToCurrent = false) {
  if (!finder.ready) return;
  const n = finder.books.length;
  $("finderBooksVal").textContent = !n ? "All hymnals" : n === 1 ? bookName(finder.books[0]) : `${n} hymnals`;
  // each chosen hymnal as a chip whose × takes it off; past a few, "+N more" opens the checklist
  const PICKED_MAX = 3;
  $("finderPicked").innerHTML = finder.books.slice(0, PICKED_MAX)
    .map((b) => `<button type="button" data-book="${escHtml(b)}" title="${escHtml(bookName(b))}" aria-label="Stop showing ${escHtml(bookName(b))}">${escHtml(b)}</button>`).join("")
    + (n > PICKED_MAX ? `<button type="button" class="more" data-more aria-label="All ${n} chosen hymnals">+${n - PICKED_MAX} more</button>` : "");
  // the sound counts follow the chosen hymnals, so they say what clicking would show
  const inBooks = finderMatches("", { books: finder.books, sound: "all", sort: "auto" });
  $("finderSound").innerHTML = SOUNDS.map(([k, label]) => {
    const c = k === "all" ? inBooks.length : inBooks.filter((x) => (k === "sung" ? x.sung : !x.sung)).length;
    return `<button type="button" role="radio" data-sound="${k}" aria-checked="${finder.sound === k}">${label}<small>${c}</small></button>`;
  }).join("");
  const sortSel = $("finderSort");
  sortSel.value = finder.sort;
  sortSel.options[0].textContent = finder.q.trim() ? "Best match" : "Hymnal, number";
  let words = finderMatches(finder.q);
  // the hymns about the same idea (only those the filters keep). All the words found: the words
  // first, then the idea. Only some of them: the idea first, it reads the question better
  const keepIdea = new Set(finderMatches("").map((x) => x.id));
  let ideaRows = finder.q.trim() && idea.q === finder.q.trim()
    ? idea.ids.filter((id) => keepIdea.has(id)).map((id) => hymnList.find((x) => x.id === id)) : [];
  const ideaFirst = ideaRows.length && search.ms && search.partial;
  if (ideaFirst) {
    const inIdea = new Set(ideaRows.map((x) => x.id));
    words = words.filter((x) => !inIdea.has(x.id));
  } else {
    const inWords = new Set(words.map((x) => x.id));
    ideaRows = ideaRows.filter((x) => !inWords.has(x.id));
  }
  const shown = ideaFirst ? ideaRows.concat(words) : words.concat(ideaRows);
  const isIdea = new Set(ideaRows.map((x) => x.id));
  finder.shown = shown;
  const cur = $("hymnPicker").value;
  if (scrollToCurrent && !finder.q) { const i = shown.findIndex((x) => x.id === cur); finder.active = Math.max(0, i); }
  finder.active = Math.min(finder.active, Math.max(0, shown.length - 1));
  const filtered = n || finder.sound !== "all";
  const nW = words.length, q0 = finder.q.trim();
  const wordsSay = !q0 ? `${nW} hymn${nW === 1 ? "" : "s"}`
    : search.ms && search.partial && /[a-z]/i.test(q0) ? (nW ? `No hymn has all of “${q0}”; ${nW} have some of the words` : `No hymn has the words “${q0}”`)
    : nW ? `${nW} hymn${nW === 1 ? "" : "s"} ${nW === 1 ? "matches" : "match"} “${q0}”` : `No hymn has the words “${q0}”`;
  $("finderCount").textContent = !shown.length ? "" : `${wordsSay}${ideaRows.length ? `, ${ideaRows.length} more about this idea` : ""}${filtered ? " in the chosen filters" : ""}`;
  $("finderList").innerHTML = shown.length ? shown.map((x, i) => `${ideaFirst ? (i === 0 ? `<li class="finder-sep" role="presentation">About this idea</li>` : i === ideaRows.length && words.length ? `<li class="finder-sep" role="presentation">Some of the words</li>` : "")
      : i === words.length && ideaRows.length ? `<li class="finder-sep" role="presentation">About this idea</li>` : ""}<li role="option" id="fo-${i}" data-i="${i}" data-id="${escHtml(x.id)}" aria-selected="${i === finder.active}"${x.id === cur ? ' class="current"' : ""}>
      <span class="f-num"><small>${escHtml(x.book)}</small>${escHtml(x.number)}</span>
      <span class="f-title">${isIdea.has(x.id) ? `${escHtml(x.title)}<span class="f-snip">${escHtml(idea.lines.get(x.id) || "")}</span>`
        : `${markMatch(x.title, finder.q)}${finder.q && search.ms ? ((sn) => (sn ? `<span class="f-snip">${sn}</span>` : ""))(snippetFor(x.id, finder.q)) : ""}`}</span>
      <span class="f-sound ${x.sung ? "sung" : "midi"}" title="${x.sung ? "Recorded singers" : "Played on the synth (MIDI)"}">${x.sung ? "Singers" : "MIDI"}</span>
    </li>`).join("")
    : `<li class="finder-empty">No hymn matches${finder.q ? ` “${escHtml(finder.q.trim())}”` : ""}${filtered ? " in these filters. Try all hymnals or all sounds." : "."}</li>`;
  highlight(true, scrollToCurrent);
}

function highlight(scroll = true, center = false) {
  const list = $("finderList");
  list.querySelectorAll('li[aria-selected="true"]').forEach((li) => li.setAttribute("aria-selected", "false"));
  const li = list.querySelector(`#fo-${finder.active}`);
  if (!li) return;
  li.setAttribute("aria-selected", "true");
  $("finderTop").setAttribute("aria-activedescendant", li.id);
  $("finderQuery").setAttribute("aria-activedescendant", li.id);
  if (scroll) li.scrollIntoView({ block: center ? "center" : "nearest" });
}

async function boot() {
  readColors();
  try {
    await loadList();
  } catch {
    $("score").innerHTML = `<p class="status">The hymn list is missing. Run <code>python3 build_web.py</code> in the hymn-satb folder, then reload.</p>`;
    return;
  }
  const picker = $("hymnPicker");
  const asked = decodeURIComponent(location.hash.slice(1));
  const wanted = asked || store.get("hymn", hymnList[0].id);
  picker.value = hymnList.some((x) => x.id === wanted) ? wanted : hymnList[0].id;
  if (EMBED) setupEmbed();
  if (APP) {
    document.body.classList.add("app");
    const v = new URLSearchParams(location.search).get("view");
    if (v && ["tracks", "page", "solfa", "words", "presenter"].includes(v)) state.view = v === "page" && state.staffScroll ? "tracks" : v;
  }
  if (APP && asked && !hymnList.some((x) => x.id === asked)) {
    appWant.id = asked; appWant.missing = true;
    picker.value = hymnList.some((x) => x.id === store.get("hymn")) ? store.get("hymn") : hymnList[0].id;
  } else if (asked && !hymnList.some((x) => x.id === asked)) { if (MAKE) makeFailed(asked, "the Studio has no such hymn"); notInStudio(asked); return; }
  picker.onchange = () => { location.hash = picker.value; loadHymn(hymnList.find((x) => x.id === picker.value)); };
  bindControls();
  // the notation engine only when the first view draws music (renderAll starts it otherwise)
  view = new ScoreView(null, $("score"));
  if (needsNotation()) {
    try { await ensureVerovio(); } catch { notationFailed(); return; }
  }
  if (APP) { state.zoom = APP_ZOOM; state.solfaZoom = APP_ZOOM; state.altZoom = 1; setupPinch(); }
  setupPractice();
  setupSingWithMe();
  solfa = new SolfaView($("altView"));
  words = new WordsView($("altView"));
  presenter = new Presenter($("stage"), $("measureHost"));
  studio = new Studio($("studio"));
  await document.fonts.ready;
  await loadHymn(hymnList.find((x) => x.id === picker.value));
  bootDone();
  requestAnimationFrame(frame);
  if (MAKE) runMake();
}

/** A hymn the site linked to that the Studio has no score for yet. */
function notInStudio(id) {
  const [book, num] = id.split("-");
  document.title = `${book} ${num || ""} · not in the Studio yet`;
  $("hymnNumber").textContent = num || "";
  $("hymnTitle").textContent = "Not in the Studio yet";
  $("hymnCredits").textContent = `${book} ${num || ""}`;
  document.body.classList.add("missing");
  const ready = hymnList.filter((x) => x.book !== "RECORDED");
  $("workspace").insertAdjacentHTML("beforebegin", `<div class="missing-note">
    <h2>This hymn's music is still being prepared</h2>
    <p>Each hymn is checked note by note before it goes in the Studio, so they are being added one at a time.
    ${EMBED ? "" : "You can still read all the words on the hymn's page."}</p>
    ${ready.length ? `<p>Ready to play now:</p><ul>${ready.map((x) => `<li><a href="${EMBED ? "?embed=1" : "./"}#${x.id}">${x.book} ${x.number}, ${x.title}</a></li>`).join("")}</ul>` : ""}
  </div>`);
  const picker = $("hymnPicker");
  picker.value = "";
  syncFinderLabel();
  picker.onchange = () => { location.hash = picker.value; };
  window.addEventListener("hashchange", () => location.reload(), { once: true });
}

/** The compact player: the score, play, tempo, key and the voices, plus the way out to the full Studio. */
function setupEmbed() {
  document.body.classList.add("embed");
  // inside a hymn page, whose own bar already names the hymn and links out
  // or inside the Android app (?app), which has its own Words / Play / Studio switch
  if (window.self !== window.top || new URLSearchParams(location.search).has("app")) { document.body.classList.add("framed"); return; }
  const out = document.createElement("a");
  out.className = "embed-out";
  out.target = "_blank";
  out.rel = "noopener";
  out.textContent = "Full Studio ↗";
  const sync = () => { out.href = `./${location.hash}`; };
  sync();
  window.addEventListener("hashchange", sync);
  document.querySelector(".toolbar").append(out);
}

// ---- tunes ---------------------------------------------------------------------------------------
// A hymn's words may be sung to another tune: one the hymnals print them with, or one of the same meter and
// foot. data/tunes.json (tools/build_tunes.py) lists, per hymn, those whose notes the words fit one to one;
// the choice is remembered for each hymn.
let tunesTable = null;
const tunesReady = fetch("data/tunes.json").then((r) => (r.ok ? r.json() : {})).catch(() => ({})).then((t) => (tunesTable = t));
const tuneChoices = (id) => tunesTable?.[id] || null;
const chosenTune = (id) => { const k = store.get(`tune:${id}`, ""); return (k && tuneChoices(id)?.alts.find((a) => a.tune === k)) || null; };
/** The syllables of `words` poured in order into the notes of `pattern` that carry one. */
const fillWords = (pattern, words) => { const syl = (words || []).filter(Boolean); let i = 0; return (pattern || []).map((s) => (s ? syl[i++] ?? null : null)); };
/** Hymn x's words on the music of the tune `alt` (taken from the player hymn that carries it). */
async function withTune(x, alt) {
  const src = hymnList.find((e) => e.id === alt.from);
  if (!src) return x;
  const y = await (await fetch(src.path)).json();
  return {
    ...y, id: x.id, book: x.book, number: x.number, title: x.title, english: x.english, poet: x.poet,
    copyright: [...new Set([x.copyright, y.copyright].filter(Boolean))].join(" "),
    verses: x.verses.map((v) => fillWords(y.verses[0], v)),
    refrain: y.refrain ? fillWords(y.refrain, x.refrain) : y.refrain, refrains: undefined,
    tune: { key: alt.tune, name: alt.name, from: alt.from },
  };
}
/** The tune picker beside the title: shown only for a hymn that has another tune. */
function syncTunePicker() {
  const c = hymn && tuneChoices(hymn.id);
  $("tunePick").hidden = !c;
  if (!c) return;
  const sel = $("tunePicker");
  sel.innerHTML = [`<option value="">${escHtml(c.name || "As printed")} (printed)</option>`, ...c.alts.map((a) => `<option value="${escHtml(a.tune)}">${escHtml(a.name)}</option>`)].join("");
  sel.value = hymn.tune?.key || "";
  sel.onchange = () => setTune(sel.value);
}
/** Sing this hymn to another tune ("" = the printed one); remembered for the hymn. */
async function setTune(key) {
  if (!hymn) return;
  const entry = hymnList.find((e) => e.id === hymn.id);
  if (!entry || (hymn.tune?.key || "") === (key || "")) return;
  store.set(`tune:${hymn.id}`, key || "");
  engine.dropStems(); // the old tune's singers are no use now
  for (const w of singingCfg.voices) w.drop();
  try { if (engine.native) { engine.nativeStop(); engine.native.unload("*"); } } catch { /* the app went away */ }
  await loadHymn(entry);
  toast(hymn.tune ? `Sung to ${hymn.tune.name}. Recorded singers only sing the printed tune, so live singing or the synth sings this one.` : "The printed tune.", 5000);
}

async function loadHymn(entry) {
  stopPlayback();
  if (hymn && hymn.id !== entry.id) appAnswered = false; // the app asks again for this hymn
  if (hymn && hymn.id !== entry.id) { // the last hymn's singers leave memory
    engine.dropStems();
    for (const w of singingCfg.voices) w.drop();
    try { if (engine.native) { engine.nativeStop(); engine.native.unload("*"); } } catch { /* the app went away */ }
  }
  try {
    const next = await hymnJson(entry);
    if (APP && appWant.id && appWant.id !== entry.id) return; // the app has asked for another hymn since: draw that one
    hymn = next;
    await tunesReady;
    const alt = chosenTune(hymn.id);
    if (alt) { try { hymn = await withTune(hymn, alt); } catch { /* the tune's music is missing: the printed tune */ } }
    hymnWritten = hymn;
  } catch {
    $("score").innerHTML = `<p class="status">This hymn's file is missing: ${entry.path}. Run <code>python3 build_web.py</code>, then reload.</p>`;
    return;
  }
  store.set("hymn", hymn.id);
  syncFinderLabel();
  document.title = `${hymn.number} ${hymn.title}`;
  $("hymnNumber").textContent = hymn.number;
  $("hymnTitle").textContent = hymn.title;
  $("hymnEnglish").textContent = hymn.english || entry.english || "";  // NZK/WN: the English hymn it translates
  $("hymnCredits").textContent = [hymn.poet && `Words by ${hymn.poet}`, hymn.tune ? `sung to ${hymn.tune.name}${hymn.composer ? ` (${hymn.composer})` : ""}` : hymn.composer && `music by ${hymn.composer}`].filter(Boolean).join(", ");
  syncTunePicker();
  $("copyright").textContent = hymn.copyright;
  state.tempo = store.get(`tempo:${hymn.id}`, hymn.tempo);
  engine?.setRate?.(1); // a new hymn starts at its own tempo, not the pace the last one was followed at
  state.transpose = store.get(`transpose:${hymn.id}`, 0);
  liveChanges = [];
  $("tempo").value = state.tempo;
  $("tempoLabel").textContent = `${state.tempo} a minute`;
  const saved = store.get(`verses:${hymn.id}`, null);
  state.verses = saved && saved.every((v) => v <= hymn.verses.length) ? saved : hymn.verses.map((_, i) => i + 1);
  state.loop = { on: false, from: 1, to: Math.min(4, hymn.measures) };
  $("loopFrom").max = $("loopTo").max = hymn.measures;
  syncLoopInputs();
  buildVerseChips();
  syncPracticeForHymn();
  await loadManifest();
  rebuild(false);
  await renderAll();
  prepareStems();
}

async function loadManifest() {
  // which singers to use (data/singing.json); never held up for good by a slow download
  await Promise.race([singingReady, new Promise((r) => setTimeout(r, 10000))]);
  manifest = null;
  manifests = {};
  stemInfo = new Map();
  if (hymn.tune) { syncSungControls(); return; } // recorded singers sing the printed tune only
  const id = hymn.id;
  const entry = hymnList.find((x) => x.id === id);
  const take = (r, m) => {
    // recordings live in the audio store, whichever copy of the player this is
    if (m && AUDIO) m.stems.forEach((st) => { st.url = new URL(st.url, AUDIO).href; });
    if (m?.stems?.length) manifests[r.engine] = m;
  };
  await Promise.all(RECORDED.map(async (r) => {
    // the list says which hymns have recorded (and converted) singers: the others never ask the site
    if ((DATA || r.engine !== "stems") && !r.has(entry)) return;
    const url = `${AUDIO}${r.dir}/${id}/manifest.json`;
    try {
      // the list saved on the phone at once; a list never saved comes in the background (the hymn opens
      // without waiting, and its singers join when the list arrives)
      const saved = await singers.saved(url);
      if (saved) { if (saved.ok) take(r, await saved.json()); }
      else {
        singers.manifest(url).then(async (res) => {
          if (!res.ok || hymn?.id !== id) return;
          const m = await res.json();
          if (hymn?.id !== id || manifests[r.engine]) return;
          const had = manifest;
          take(r, m); syncSungControls(); syncSingersBtn();
          if (manifest !== had && had) prepareStems(); // the chosen singers' own list arrived
        }).catch(() => { /* no singers for this hymn */ });
      }
    } catch { /* no sung stems for this hymn */ }
  }));
  syncSungControls();
}

/** Each live voice after the first gets its own choice in "Who sings?" and in the settings' list. */
function offerLiveVoices() {
  const first = document.querySelector('#singDialog [data-engine="warble"]');
  const opt = document.querySelector('#singEngine option[value="warble"]');
  singingCfg.voices.forEach((w, i) => {
    if (i === 0) {
      if (first) first.querySelector("strong").firstChild.textContent = `${w.label} `;
      if (opt) opt.textContent = `${w.label} (beta)`;
      return;
    }
    if (first && !document.querySelector(`#singDialog [data-engine="${w.engine}"]`)) {
      const b = first.cloneNode(true);
      b.dataset.engine = w.engine;
      b.querySelector("strong").firstChild.textContent = `${w.label} `;
      b.querySelector("small").removeAttribute("id");
      [...document.querySelectorAll('#singDialog [data-engine^="warble"]')].pop().after(b);
    }
    if (opt && !document.querySelector(`#singEngine option[value="${w.engine}"]`)) {
      const o = new Option(`${w.label} (beta)`, w.engine);
      [...document.querySelectorAll('#singEngine option[value^="warble"]')].pop().after(o);
    }
  });
}

/** Who sings? Live singers, recorded singers or instruments only, each with what it costs. Asked at Play
 *  once for each hymn opened (unless "Don't ask again"), and whenever the Singers button is clicked.
 *  Nothing is downloaded for either singer before the answer. Resolves false when cancelled. */
function chooseSingers(from, always = false) {
  const d = $("singDialog");
  if (!d || !singingCfg.warble || APP || MAKE) return Promise.resolve(true);
  if (!always && (appAnswered || !asksAtPlay() || following())) return Promise.resolve(true); // following you: the choir sings
  pickManifest();
  const recorded = !!manifests.stems?.stems?.length;
  offerRecordedV2();
  const stemsNote = $("singStemsNote");
  stemsNote.textContent = recorded ? "Real voices · downloads the singers of this hymn" : "Not recorded for this hymn yet";
  d.querySelector('[data-engine="stems"]').classList.toggle("unavailable", !recorded);
  if (recorded) updateStemsCost().then(() => {
    if (stemsCost.bytes) stemsNote.textContent = `Real voices · downloads ${(stemsCost.bytes / 1e6).toFixed(stemsCost.bytes < 1e7 ? 1 : 0)} MB for this hymn`;
  });
  for (const w of singingCfg.voices) {
    const liveNote = d.querySelector(`[data-engine="${w.engine}"] small`);
    if (!liveNote) continue;
    liveNote.textContent = "Sung on this device · nothing to download for each hymn · any tempo or key";
    w.saved().then((has) => { if (!has) liveNote.textContent += " (the first time: the singers, 17 MB, once)"; });
  }
  const now = whoSings();
  for (const b of d.querySelectorAll(".sing-choice")) b.classList.toggle("current", b.dataset.engine === now);
  $("singNoAsk").checked = state.singAsk === false;
  return new Promise((resolve) => {
    const done = (v) => { d.onclose = null; d.close(); resolve(v); };
    for (const b of d.querySelectorAll(".sing-choice")) b.onclick = () => {
      state.singAsk = !$("singNoAsk").checked; save("singAsk");
      chooseWhoSings(b.dataset.engine);
      done(true);
    };
    $("singCancel").onclick = () => done(false);
    d.onclose = () => resolve(false);
    d.showModal();
    d.querySelector(".sing-choice.current")?.focus(); // Enter or Space keeps the same singers
  });
}

/** "Recorded singers v2" in "Who sings?" and the settings, for hymns that have converted singers. */
function offerRecordedV2() {
  const has = !!manifests["stems-v2"];
  const first = document.querySelector('#singDialog [data-engine="stems"]');
  let b = document.querySelector('#singDialog [data-engine="stems-v2"]');
  if (first && !b && has) {
    b = first.cloneNode(true);
    b.dataset.engine = "stems-v2";
    b.querySelector("strong").textContent = "Recorded singers v2";
    const n = b.querySelector("small"); n.removeAttribute("id");
    n.textContent = "The recorded singers in real singers' voices · downloads the singers of this hymn";
    first.after(b);
  }
  if (b) b.hidden = !has;
  const opt = document.querySelector('#singEngine option[value="stems"]');
  if (opt && !document.querySelector('#singEngine option[value="stems-v2"]')) opt.after(new Option("Recorded singers v2 (where there are)", "stems-v2"));
}

/** Live singers ("warble"), recorded singers ("stems", "stems-v2") or instruments only ("instrumental"). */
function chooseWhoSings(v) {
  appAnswered = true;
  if (v === "instrumental") { window.AHStudio.set("instrumental", true); syncSingersBtn(); return; }
  if (state.instrumental) { // the voices come back with the new singers already chosen (no detour via the other)
    state.singEngine = v; save("singEngine");
    otherLive(v);
    window.AHStudio.set("instrumental", false);
    syncSungControls();
  } else if (v !== singEngine() || !state.singEngine) setSingEngine(v);
  else prepareStems();
  syncSingersBtn();
}

const SINGER_ICONS = {}; // filled from the dialog's own icons
function syncSingersBtn() {
  const b = headersEl.querySelector(".singers-btn");
  if (!b) return;
  const v = whoSings();
  const label = isLive(v) ? liveVoice(v)?.label || "Live singers" : RECORDED.find((r) => r.engine === v)?.label || { instrumental: "Instruments only" }[v] || "Singers";
  if (!SINGER_ICONS[v]) SINGER_ICONS[v] = document.querySelector(`#singDialog [data-engine="${v === "stems-v2" ? "stems" : v}"] .sing-ico`)?.innerHTML || "";
  b.innerHTML = `${SINGER_ICONS[v]}<span>${label}</span>`;
  b.title = `${label}: click to choose who sings`;
}

const stemTempos = () => [...new Set((manifest?.stems || []).map((s) => s.tempo))].sort((a, b) => a - b);

function syncSungControls() {
  pickManifest();
  offerRecordedV2();
  const live = useWarble();
  $("sungRow").hidden = !manifest && !anySung() && !singingCfg.warble;
  $("singEngineRow").hidden = !singingCfg.warble && !manifests["stems-v2"];
  $("singEngine").value = APP || state.singAsk !== false ? (APP ? singEngine() : "ask") : whoSings();
  $("renderSingers").hidden = live;
  const tempos = stemTempos();
  $("sungStatus").textContent = live ? "Sung live on this device, at any tempo and key. The first time, it downloads the singers (17 MB)."
    : !manifest ? (singingCfg.warble ? "No recording of this hymn yet. Live singing can sing it." : "No sung recording yet.")
    : tempos.length ? `Recorded at ${tempos.join(", ")} a minute.` : "No sung recording yet.";
}

/** Choosing who sings (recorded or live singers) means the voices sing: one left on the synth's "aah"
 *  goes back to its singer (a stuck "choir" kept live singing silent on every hymn). */
function voicesSing() {
  let changed = false;
  for (const ch of Object.keys(state.voiceSounds)) if (state.voiceSounds[ch] === "choir") { delete state.voiceSounds[ch]; changed = true; }
  if (changed) { save("voiceSounds"); applyMix(); buildHeaders(); }
}

/** Choose the singing engine (remembered on this device). */
function setSingEngine(v) {
  voicesSing();
  state.singEngine = v;
  save("singEngine");
  syncSingersBtn();
  otherLive(v);
  syncSungControls();
  buildHeaders();
  prepareStems();
}

// the key each chosen verse is sung in, before any live changes
const verseShift = (v) => state.transpose + (state.lastVerseUp && state.verses.length > 1 && v === state.verses[state.verses.length - 1] ? state.lastVerseUp : 0);

/** Load the sung stems for the chosen verses at the current tempo and keys; other voices use the synth. */
async function prepareStems() {
  if (APP) updateStemsCost(); // the app shows what the recorded singers would download
  if (APP && nativeEngineRaw() === "instrumental" && !state.instrumental) { window.AHStudio.set("instrumental", true); return; } // the app chose instruments only
  if (awaitingApp()) { warbleGen++; stemInfo = new Map(); engine.setStemBuffers(new Map()); rebuild(); return; }
  if (useWarble()) return prepareWarble();
  pickManifest();
  warbleGen++;
  stemInfo = new Map();
  $("credit").textContent = "";
  if (!anySung() || !manifest) { rebuild(); return; }
  if (hymn.variant) { // the recordings follow the written rhythm
    toast("The singers are recorded in the written rhythm, so the synth sings the changed rhythm.", 6000);
    engine.setStemBuffers(new Map());
    rebuild();
    return;
  }
  // the recording nearest the slider's tempo; it is stretched to the slider's tempo below
  const tempos = stemTempos();
  const recTempo = tempos.reduce((a, b) => (Math.abs(b - state.tempo) < Math.abs(a - state.tempo) ? b : a), tempos[0]);
  // In sol-fa mode each voice has one recording singing its note names, reused for every verse.
  const solfaWords = state.words === "solfa" || state.singSolfa; // the singers sing their note names
  const wanted = [];
  const missing = [];
  for (const v of state.verses) {
    for (const k of hymnVoices()) {
      if (soundOf(k) !== "sung") continue; // this voice is set to the choir synth or piano
      const shift = verseShift(v);
      const st = manifest.stems.find((x) => x.voice === k && x.tempo === recTempo && (x.transpose ?? 0) === shift && x.verse === (solfaWords ? "solfa" : v));
      if (st) wanted.push({ key: `${k}:${v}:${shift}`, url: st.url, offsetSec: st.offsetSec });
      else if (!solfaWords || v === state.verses[0]) missing.push(solfaWords ? VOICES[k].name : `${VOICES[k].name} ${v}`);
    }
  }
  toast("Loading the singers…", 0);
  try {
    const bufs = await engine.loadStems(wanted, (done, total) => {
      if (total) toast(`Loading the singers… ${done} of ${total}. You can press play now; the synth sings until they arrive.`, 0);
    });
    if (bufs.stale) return; // a newer request (another hymn) has taken over
    // recorded at another tempo: stretch to the slider's tempo, keeping the pitch (everything scales by one ratio)
    const ratio = recTempo / state.tempo;
    if (Math.abs(ratio - 1) > 1e-3) {
      const keys = [...bufs.keys()];
      for (let i = 0; i < keys.length; i++) {
        toast(`Fitting the singers to ${state.tempo} a minute… ${i + 1} of ${keys.length}`, 0);
        await new Promise((r) => setTimeout(r, 0));
        bufs.set(keys[i], engine.stretched(bufs.get(keys[i]), ratio));
      }
    }
    engine.setStemBuffers(bufs);
    for (const w of wanted) if (bufs.has(w.key)) stemInfo.set(w.key, { offsetSec: w.offsetSec * ratio, duration: bufs.get(w.key).duration });
    if (bufs.failed.length) toast(`${bufs.failed.length} recording${bufs.failed.length === 1 ? "" : "s"} did not arrive (slow connection?), so the synth sings ${bufs.failed.length === 1 ? "that part" : "those parts"}. Reload to try again.`, 8000);
    const what = solfaWords ? "singing sol-fa" : "in this key and tempo";
    const far = Math.abs(recTempo / state.tempo - 1) > 0.25 ? ` Recorded at ${recTempo}; this far from it the voices can sound smeared.` : "";
    toast((missing.length ? `Singers ready. Synth until recorded ${what}: ${missing.join(", ")}.` : "Singers ready.") + far, far ? 9000 : 7000, missing.length ? { label: "Record them", fn: renderSingers } : null);
    // the singers' voices must be credited (their licence); the code credit stays with the code
    $("credit").textContent = (manifest.credit || "").replace(/;\s*synthesis code.*$/i, "");
  } catch (err) {
    toast(`The singers could not load: ${err.message}`, 7000);
  }
  rebuild();
}

/** Live singing: every chosen verse sung on this device (Warble), the verse sung first made first.
 * Until a verse is ready its voices are sung by the synth, so nothing waits and nothing stutters. */
let warbleGen = 0;
/** The passes live singing sings: each chosen verse in each key it is sung in (a key change while playing
 *  adds the new key from there on), the verse being sung first. */
function warbleList() {
  const solfaWords = state.words === "solfa" || state.singSolfa;
  const out = [];
  const add = (v, transpose) => { if (!out.some((x) => x.v === v && x.transpose === transpose)) out.push({ v, verse: solfaWords ? "solfa" : v, transpose }); };
  if (!liveChanges.length || !perf) { for (const v of state.verses) add(v, verseShift(v)); return out; }
  const at = (engine.playing && locate(perf, engine.now())?.pass) || 0;
  const ks = perf.passes.map((p, k) => (p.kind === "verse" ? k : -1)).filter((k) => k >= 0);
  for (const k of [...ks.filter((k) => k >= at), ...ks.filter((k) => k < at)]) {
    const p = perf.passes[k];
    add(p.verse, shiftAt(k, p, 0));
    for (const c of liveChanges) if (c.k === k) add(p.verse, shiftAt(k, p, c.q));
  }
  return out;
}
/** keep: a key change while playing; what is sung already stays, the new keys are added as they are ready */
async function prepareWarble(keep = false) {
  const w = liveW();
  const gen = ++warbleGen;
  if (!keep) {
    stemInfo = new Map();
    engine.setStemBuffers(new Map());
  }
  if (!anySung() || !hymn) { w.cancelAll(); rebuild(); return; }
  $("credit").textContent = w.credits();
  const native = Warble.native();
  if (native) return prepareNativeWarble(native, w, gen, keep);
  if (!keep) rebuild();
  const list = warbleList();
  const tempo = state.tempo;
  const bufs = keep ? new Map(engine.stemBuffers || []) : new Map();
  let total = 0, shown = 0;
  const sungSoFar = () => { // the verses ready now become singers, without interrupting the music
    engine.setStemBuffers(new Map(bufs));
    rebuild(true, true);
  };
  try {
    engine.ensure();
    await w.start((f, text) => { if (gen === warbleGen) toast(text, 0); });
    if (gen !== warbleGen) return;
    const t0 = Date.now();
    await w.sing(engine.ctx, hymn, tempo, list.map(({ verse, transpose }) => ({ verse, transpose })), {
      onProgress: (done, all) => {
        if (gen !== warbleGen) return;
        total = all;
        const pct = all ? Math.floor((100 * done) / all) : 100;
        if (pct === shown) return;
        shown = pct;
        toast(keep ? `Live singing: learning the new key… ${pct}%. The synth sings until then.` : `Live singing: preparing the singers… ${pct}%. You can press play now; the synth sings each verse until its singers are ready.`, 0);
      },
      onPass: (key, voices) => {
        if (gen !== warbleGen) return;
        for (const { v, verse, transpose } of list) {
          if (w.passKey(hymn, verse, tempo, transpose) !== key) continue;
          for (const k of hymnVoices()) {
            if (!voices[k] || soundOf(k) !== "sung") continue;
            bufs.set(`${k}:${v}:${transpose}`, voices[k]);
            stemInfo.set(`${k}:${v}:${transpose}`, { offsetSec: -0.3, duration: voices[k].duration });
          }
        }
        sungSoFar();
      },
    });
    if (gen !== warbleGen) return;
    const secs = (Date.now() - t0) / 1000;
    const mix = total / Math.max(1, hymnVoices().length); // seconds of music, all voices together
    const speed = total && secs > 0.5 ? ` (${(mix / secs).toFixed(1)}× real time)` : "";
    if (keep) { if (shown) toast("The live singers are in the new key.", 3000); }
    else toast(`Live singers ready${speed}.`, 4000);
    console.info(`warble: ${mix.toFixed(1)} s of ${hymnVoices().length}-voice singing in ${secs.toFixed(1)} s with ${w.workers.length} workers${speed}`);
  } catch (err) {
    if (err?.cancelled || gen !== warbleGen) return;
    toast(`Live singing could not start: ${err.message}. The synth sings instead.`, 8000);
  }
}

/** Inside the Android app: its native engine sings (faster than WASM). The page makes the features
 * and hands each pass over (AHNative.warble.load); the engine plays them on the player's timeline. */
let nativeModel = null;
async function prepareNativeWarble(native, w, gen, keep = false) {
  engine.setNative(native);
  window.AHWarble = { onEvent: onNativeWarble };
  if (nativeModel !== w.modelUrl) { native.model(w.modelUrl, w.cfg.sha256 || ""); nativeModel = w.modelUrl; }
  const failed = [];
  for (const { v, verse, transpose } of warbleList()) {
    if (keep && [...stemInfo.keys()].some((x) => x.endsWith(`:${v}:${transpose}`))) continue; // already loaded
    const key = w.passKey(hymn, verse, state.tempo, transpose);
    let pass;
    try { pass = await w.features(hymn, verse, state.tempo, transpose); } catch (err) { failed.push(`${v}: ${err.message}`); continue; }
    if (gen !== warbleGen) return;
    const bin = Warble.bin(pass);
    let b64 = "";
    for (let i = 0; i < bin.length; i += 0x8000) b64 += String.fromCharCode(...bin.subarray(i, i + 0x8000));
    const r = JSON.parse(native.load(key, btoa(b64), pass.letters) || "{}");
    if (!r.ok) { failed.push(`${v}: ${r.error || "not loaded"}`); continue; }
    for (const k of hymnVoices()) {
      if (!pass.letters.includes(k) || soundOf(k) !== "sung") continue;
      stemInfo.set(`${k}:${v}:${transpose}`, { offsetSec: -0.3, duration: (pass.T * 512) / 44100, native: key });
    }
  }
  if (gen !== warbleGen) return;
  rebuild(true, true);
  if (failed.length) toast(`Live singing could not sing verse ${failed.join("; ")}. The synth sings it.`, 8000);
}

/** Can the app's singer play a stretch of a pass (segs with from/to), for a key change inside a verse? */
function nativeSplits() {
  try { return !!JSON.parse(Warble.native()?.available() || "null")?.windows; } catch { return false; }
}

function onNativeWarble(json) {
  let m;
  try { m = JSON.parse(json); } catch { return; }
  if (m.type === "model" && m.state === "downloading") toast(`Downloading the singing model… ${Math.round((m.progress || 0) * 100)}% (once)`, 0);
  else if (m.type === "model" && m.state === "loading") toast("Starting the singers…", 0);
  else if (m.type === "model" && m.state === "ready") toast("Live singers ready.", 3000);
  else if (m.type === "model" && m.state === "error") toast(`Live singing could not start: ${m.msg || "the model did not load"}.`, 8000);
  else if (m.type === "error") toast(`Live singing: ${m.msg}`, 8000);
  else if (m.type === "underrun") { // it catches up by itself; say so now and then, never stop
    console.warn("warble: the app's singer fell behind");
    if (Date.now() - (onNativeWarble.said || 0) > 20000) { onNativeWarble.said = Date.now(); toast("The singers fell behind for a moment (is the screen locked?). They catch up by themselves.", 4000); }
  }
}

/** What the recorded singers of this hymn cost at the current tempo, key and verses, for the app's
 *  "Who sings?": bytes to download (0 when unknown) and whether they are all saved on the phone. */
let stemsCost = { bytes: 0, saved: false };
let stemsCostGen = 0;
async function updateStemsCost() {
  const gen = ++stemsCostGen;
  stemsCost = { bytes: 0, saved: false };
  pickManifest();
  if (!manifest?.stems?.length || !hymn) return;
  const tempos = stemTempos();
  const recTempo = tempos.reduce((a, b) => (Math.abs(b - state.tempo) < Math.abs(a - state.tempo) ? b : a), tempos[0]);
  const solfaWords = state.words === "solfa" || state.singSolfa;
  const urls = new Set();
  for (const v of state.verses) for (const k of hymnVoices()) {
    const st = manifest.stems.find((x) => x.voice === k && x.tempo === recTempo && (x.transpose ?? 0) === verseShift(v) && x.verse === (solfaWords ? "solfa" : v));
    if (st) urls.add(st.url);
  }
  if (!urls.size) return;
  const c = await singers.cache();
  let bytes = 0, saved = true;
  await Promise.all([...urls].map(async (u) => {
    const hit = c && (await c.match(u).catch(() => null));
    if (!hit) saved = false;
    const len = hit ? Number(hit.headers.get("content-length")) : await fetch(u, { method: "HEAD" }).then((r) => Number(r.headers.get("content-length")) || 0, () => 0);
    bytes += len || 0;
  }));
  if (gen === stemsCostGen) stemsCost = { bytes, saved };
}

function setTempo(t) {
  state.tempo = t;
  $("tempo").value = t;
  $("tempoLabel").textContent = `${t} a minute`;
  store.set(`tempo:${hymn.id}`, t);
  if (anySung()) prepareStems(); else rebuild();
}

async function renderSingers() {
  // one recording run per key the chosen verses are sung in (e.g. a raised last verse)
  const byShift = new Map();
  for (const v of state.verses) byShift.set(verseShift(v), [...(byShift.get(verseShift(v)) || []), v]);
  if ([...byShift.keys()].some((s) => Math.abs(s) > 6)) { toast("The singers can be recorded up to six semitones from the written key."); return; }
  for (const [shift, verses] of byShift) {
    toast("Asking the server to record the singers…", 0);
    let res;
    try {
      const what = state.words === "solfa" || state.singSolfa ? "&words=solfa" : `&verses=${verses.join(",")}`;
      res = await fetch(`api/sing?hymn=${hymn.id}&tempo=${state.tempo}${what}&transpose=${shift}`, { method: "POST" });
    } catch {
      toast("Recording the singers needs the hymn server. Start it with python3 server.py in the hymn-satb folder.");
      return;
    }
    const job = await res.json().catch(() => ({}));
    if (!res.ok) { toast(job.error || "The singers could not start."); return; }
    for (;;) {
      await new Promise((r) => setTimeout(r, 3000));
      const s = await (await fetch(`api/sing/${job.id}`)).json();
      if (s.status === "done") break;
      if (s.status === "error") { toast(`Recording failed: ${s.error}`, 9000); return; }
      toast(`${s.message || "Recording the singers…"}${shift ? ` (in ${prettyChord(keyFor(shift).name)})` : ""}`, 0);
    }
  }
  await loadManifest();
  await prepareStems();
}

// ---- rendering ------------------------------------------------------------

function xmlOptions(extra = {}) {
  const tracks = visibleTracks();
  return {
    tracks,
    trackWords: tracks.map((t) => state.trackWords[trackKey(t)] !== false),
    words: state.words,
    verse: renderedVerse,
    chords: state.chords,
    unfold: unfolded() ? state.verses : null,
    ...extra,
  };
}

// the accompaniment on a grand staff (right hand, left hand) under the voices, to practise it from
const pianoShown = () => state.accStaff && state.accomp !== "off" && state.view !== "presenter";
let pianoCache = null;
function scoreHymn() {
  if (!pianoShown()) return hymn;
  if (pianoCache?.hymn !== hymn || pianoCache.style !== state.accomp) {
    pianoCache = { hymn, style: state.accomp, h: { ...hymn, voices: { ...hymn.voices, ...pianoVoices(hymn, state.accomp) } } };
  }
  return pianoCache.h;
}
function withPiano(opts) {
  if (!pianoShown()) return opts;
  return { ...opts, tracks: [...opts.tracks, ["R"], ["L"]], trackWords: [...opts.trackWords, false, false] };
}

function wordsVerse() {
  const loc = perf && locate(perf, engine.now());
  return loc ? loc.verse : state.verses[0];
}

async function renderAll() {
  if (!hymn) return;
  if (!tk && needsNotation()) {
    try { await ensureVerovio(); } catch { notationFailed(); return; }
  }
  renderedVerse = wordsVerse();
  renderedShift = currentShift(perf && locate(perf, engine.now()));
  syncKeyLabel();
  const transpose = verovioTranspose(renderedShift);
  workspace.dataset.view = state.view;
  document.querySelectorAll(".views .seg").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.view === state.view)));
  $("stageWrap").hidden = state.view !== "presenter";
  $("pianoPanel").hidden = !state.piano || state.view === "presenter";
  $("nowbar").hidden = !state.nowbar || state.view === "presenter";
  // the docked practice panel sits just above the words bar (or at the bottom when it is hidden)
  document.documentElement.style.setProperty("--nowbar-h", `${$("nowbar").hidden ? 0 : $("nowbar").offsetHeight}px`);
  sheet.hidden = !isScoreView();
  clearSweep();
  $("altView").classList.remove("sf-sweeping");
  $("altView").style.height = "";
  $("altView").hidden = isScoreView() || state.view === "presenter";
  $("altView").style.zoom = String(state.view === "solfa" ? state.solfaZoom : state.altZoom);
  buildHeaders();
  lastSystem = null;
  lastFollowEl = null;
  if (projectorOpen() && state.view !== "presenter") prepareStage();
  if (state.view === "presenter") {
    positionHeaders(null);
    await prepareStage();
  } else if (state.view === "solfa") {
    const voices = visibleVoices();
    solfa.render(hymn, { voices, words: state.words, widthScale: appWide(state.solfaZoom), verse: renderedVerse, chords: state.chords, wordsUnder: state.solfaWordsAt === "top" ? voices[0] : state.solfaWordsAt === "bottom" ? voices[voices.length - 1] : "every", chordName: (n) => chordLabel(n) });
    if (state.showSync) {
      const marked = new Set(syncopations(hymn).map((x) => `${x.voice}:${x.q}`));
      for (const c of solfa.cells) if (marked.has(`${c.voice}:${c.on}`)) c.el?.classList.add("sync");
    }
    setupSolfaSweep();
    positionHeaders(null);
  } else if (state.view === "words") {
    // the Words view always shows every verse: "only the verse being sung" (and "no words") is for the
    // staff and sol-fa; sol-fa names, when chosen, still show here (Brian, 4 Nov 2026)
    words.render(hymn, { fit: APP, words: state.words === "solfa" ? "solfa" : "all", verse: renderedVerse, chords: state.chords, chordName: (n) => chordLabel(n) });
    drawWordsLoop();
    positionHeaders(null);
  } else {
    const opts = withPiano(xmlOptions());
    // pinched bigger in the app: the sheet itself is wider than the screen, and scrolls sideways
    sheet.style.width = state.view === "page" && appWide(state.zoom) > 1 ? `${Math.floor((viewport.clientWidth - 8) * appWide(state.zoom))}px` : "";
    view.render(buildMusicXML(scoreHymn(), opts), { mode: state.view, zoom: state.zoom, width: (viewport.clientWidth - 8) * appWide(state.zoom), tracks: opts.tracks, barOffset: hymn.pickup > 0 ? 1 : 0, transpose, ownBase: lyricLines(scoreHymn(), opts) });
    buildLane();
    setupSweep();
    positionHeaders(view.systems[0]);
    drawLoopBoxes();
    drawSyncMarks();
  }
  lastLineKey = "";
  paint(true);
}

async function prepareStage() {
  const opts = xmlOptions();
  const key = JSON.stringify([hymn.id, opts, state.words === "current" ? renderedVerse : 0, renderedShift]);
  try { await ensureVerovio(); } catch { return; }
  await presenter.prepare(tk, buildMusicXML(hymn, opts), key, hymn.pickup > 0 ? 1 : 0, verovioTranspose(renderedShift));
}

// ---- track headers ---------------------------------------------------------

const iconBtn = (act, ch, pressed, label) =>
  `<button class="ib" data-act="${act}" ${ch ? `data-ch="${ch}"` : ""} aria-pressed="${pressed}" aria-label="${label}" title="${label}">${ICON[act]}</button>`;

function voiceRow(k, single) {
  const name = k === "acc" ? "Accompaniment" : VOICES[k].name;
  // on a shared staff each voice is one compact row, led by its coloured letter
  return `<div class="track-voice${single ? "" : " compact"}" style="--vc: var(--${k})">
      ${single ? "" : `<span class="vname" title="${name}">${k === "acc" ? "Acc" : k}</span>`}
      ${iconBtn("mute", k, !!state.mute[k], `Mute ${name}`)}
      ${iconBtn("solo", k, !!state.solo[k], `Hear only soloed voices: ${name}`)}
      <input type="range" min="0" max="1" step="0.01" value="${state.levels[k]}" data-ch="${k}" aria-label="${name} volume">
      ${k === "acc" ? "" : `<select class="vsound" data-sound="${k}" aria-label="${name} sounds like" title="How ${name} sounds">
        <option value="sung" ${soundOf(k) === "sung" ? "selected" : ""}>Singer</option>
        <option value="choir" ${soundOf(k) === "choir" ? "selected" : ""}>Choir aah</option>
        <option value="piano" ${soundOf(k) === "piano" ? "selected" : ""}>Piano</option>
      </select>`}
    </div>`;
}

function buildHeaders() {
  headersEl.innerHTML = "";
  // fold the sidebar into a slim rail of voice colours, or open it again
  workspace.classList.toggle("heads-collapsed", state.headsCollapsed);
  const fold = document.createElement("button");
  fold.className = "heads-toggle";
  fold.setAttribute("aria-label", state.headsCollapsed ? "Show the track controls" : "Hide the track controls");
  fold.title = fold.getAttribute("aria-label");
  fold.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${state.headsCollapsed ? "M9 6l6 6-6 6" : "M15 6l-6 6 6 6"}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  fold.onclick = () => { state.headsCollapsed = !state.headsCollapsed; save("headsCollapsed"); renderAll(); };
  headersEl.append(fold);
  if (singingCfg.warble && !APP && !MAKE) { // who sings now; one click to change (the embedded player too)
    const who = document.createElement("button");
    who.className = "singers-btn";
    who.onclick = () => chooseSingers(0, true);
    headersEl.append(who);
    syncSingersBtn();
  }
  if (state.headsCollapsed) {
    const rail = document.createElement("div");
    rail.className = "heads-rail";
    rail.innerHTML = visibleTracks().flat().map((k) => `<span style="--c: var(--${k})" title="${VOICES[k].name}">${k}</span>`).join("");
    headersEl.append(rail);
    return;
  }
  const tracks = visibleTracks();
  tracks.forEach((t, i) => {
    const key = trackKey(t);
    const el = document.createElement("div");
    el.className = `track${t.length > 1 ? " joined" : ""}`;
    el.dataset.key = key;
    el.style.setProperty("--c", `var(--${t[0]})`);
    if (t.length > 1) el.style.setProperty("--c2", `var(--${t[1]})`);
    const rows = t.map((k) => voiceRow(k, t.length === 1));
    el.innerHTML = `
      <div class="track-title"><span class="name">${trackName(t)}</span>
        ${iconBtn("words", "", state.trackWords[key] !== false, `Words under the ${trackName(t)} staff`)}
        ${iconBtn("hide", "", false, `Hide the ${trackName(t)} staff`)}
      </div>
      ${rows[0]}
      ${rows[1] || ""}`;
    headersEl.append(el);
  });
  // hidden staves stay in the list, so they can be brought back
  for (const t of tracksOfHymn().filter((x) => state.hidden.includes(trackKey(x)))) {
    const el = document.createElement("div");
    el.className = "track is-hidden";
    el.dataset.key = trackKey(t);
    el.style.setProperty("--c", `var(--${t[0]})`);
    el.innerHTML = `<div class="track-title"><span class="name">${trackName(t)}</span>${iconBtn("show", "", false, `Show the ${trackName(t)} staff`)}</div>`;
    headersEl.append(el);
  }
  const acc = document.createElement("div");
  acc.className = "track acc";
  acc.dataset.key = "acc";
  acc.style.setProperty("--c", "var(--acc)");
  acc.innerHTML = `
    <div class="track-title"><span class="name">Accompaniment</span></div>
    <select data-act="style" aria-label="Accompaniment style">${Object.entries(ACCOMP_STYLES).map(([v, l]) => `<option value="${v}" ${v === state.accomp ? "selected" : ""}>${l}</option>`).join("")}</select>
    ${voiceRow("acc", true)}`;
  headersEl.append(acc);

  headersEl.querySelectorAll("button[data-act], select[data-act], input[type=range]").forEach((c) => {
    const key = c.closest(".track")?.dataset.key;
    if (c.type === "range") {
      c.oninput = () => { state.levels[c.dataset.ch] = Number(c.value); save("levels"); applyMix(); };
      return;
    }
    const act = c.dataset.act;
    if (act === "mute" || act === "solo") {
      c.onclick = () => {
        const m = state[act];
        m[c.dataset.ch] = !m[c.dataset.ch];
        c.setAttribute("aria-pressed", String(m[c.dataset.ch]));
        save(act);
        applyMix();
      };
    } else if (act === "words") {
      c.onclick = () => { state.trackWords[key] = state.trackWords[key] === false; save("trackWords"); renderAll(); };
    } else if (act === "hide") {
      c.onclick = () => {
        if (visibleTracks().length === 1) return toast("At least one staff stays on the page.");
        state.hidden.push(key);
        save("hidden");
        renderAll();
      };
    } else if (act === "show") {
      c.onclick = () => { state.hidden = state.hidden.filter((k) => k !== key); save("hidden"); renderAll(); };
    } else if (act === "style") {
      c.onchange = () => { state.accomp = c.value; save("accomp"); if (c.value !== "off") engine.loadPiano(); rebuild(); if (state.accStaff) renderAll(); };
    }
  });
  headersEl.querySelectorAll("select[data-sound]").forEach((sel) => {
    sel.onchange = () => {
      state.voiceSounds[sel.dataset.sound] = sel.value;
      save("voiceSounds");
      if (sel.value === "piano") engine.loadPiano();
      applyMix();
      syncSungControls();
      prepareStems();
    };
  });
  syncStavesMenu();
  // rebuilt rows line up with the staves again (a mute, solo or singer change rebuilds them between renders)
  if (headersPlacedFor !== undefined) positionHeaders(headersPlacedFor);
}

// ---- staves: the layout of the voices, chosen in the toolbar ------------------------------------------
function setStaves(layout) {
  state.tracks = layout.split("|").map((t) => t.split(""));
  for (const t of state.tracks) {
    const k = trackKey(t);
    if (t.length > 1 && state.trackWords[k] === undefined) state.trackWords[k] = state.trackWords[t[0]] !== false;
  }
  // a voice hidden on its own stays hidden; a joined staff starts shown
  state.hidden = state.hidden.filter((k) => state.tracks.some((t) => trackKey(t) === k));
  save("tracks", "trackWords", "hidden");
  renderAll();
  window.scrollTo({ top: 0 });
}

// where the words go: under the top staff only, below the bottom staff only, or under every staff
function wordsAt() {
  const keys = visibleTracks().map(trackKey);
  const on = keys.map((k) => state.trackWords[k] !== false);
  if (on.every(Boolean)) return "every";
  if (on.filter(Boolean).length === 1 && on[0]) return "top";
  if (on.filter(Boolean).length === 1 && on[on.length - 1]) return "bottom";
  return "";
}

function setWordsAt(where) {
  // in the sol-fa view the same menu places its words: under every voice, or the top one only
  if (state.view === "solfa") { state.solfaWordsAt = where; save("solfaWordsAt"); renderAll(); return; }
  const keys = visibleTracks().map(trackKey);
  keys.forEach((k, i) => { state.trackWords[k] = where === "every" || (where === "top" ? i === 0 : i === keys.length - 1); });
  save("trackWords");
  renderAll();
}

function syncStavesMenu() {
  const at = wordsAt();
  document.querySelectorAll("#stavesMenu [data-words-at]").forEach((b) => {
    b.setAttribute("role", "radio");
    b.setAttribute("aria-checked", String(b.dataset.wordsAt === at));
  });
  const cur = state.tracks.map(trackKey).join("|");
  const voices = Object.keys(hymn?.voices || {});
  document.querySelectorAll("#stavesMenu [data-layout]").forEach((b) => {
    b.setAttribute("role", "radio");
    b.setAttribute("aria-checked", String(b.dataset.layout === cur));
    // a melody-only song has nothing to lay out
    b.hidden = voices.length < 4;
  });
  const ps = document.querySelector("#stavesMenu [data-acc-staff]");
  ps.setAttribute("role", "menuitemcheckbox");
  ps.setAttribute("aria-checked", String(pianoShown()));
  $("stavesMenu").hidden = voices.length < 4;
}

/** Line the headers up with the staves of a system (tracks: the only one; page: the one playing). */
let headersPlacedFor; // the system the track rows were last lined up with (null: not lined up)
function positionHeaders(system) {
  headersPlacedFor = system;
  const items = [...headersEl.children].filter((el) => !el.classList.contains("heads-toggle"));
  if (state.headsCollapsed) return;
  const aligned = isScoreView() && system;
  headersEl.classList.toggle("stacked", !aligned);
  if (!aligned) {
    headersEl.style.height = "";
    items.forEach((el) => { el.style.top = ""; el.style.height = ""; });
    return;
  }
  const offset = sheet.offsetTop;
  const staffEls = items.filter((el) => el.classList.contains("track") && !el.classList.contains("acc") && !el.classList.contains("is-hidden"));
  const acc = items.find((el) => el.classList.contains("acc"));
  const rest = items.filter((el) => el.classList.contains("is-hidden") || (el === acc && !pianoShown()));
  const staves = system.staves;
  const sysBottom = system.box.y + system.box.h + offset;
  let bottom = 0;
  staffEls.forEach((el, i) => {
    const st = staves[i];
    if (!st) return;
    const top = (i === 0 ? system.box.y : st.top - 26) + offset;
    const nextTop = staves[i + 1] ? staves[i + 1].top - 26 + offset : sysBottom;
    el.style.top = `${top}px`;
    el.style.height = `${Math.max(58, nextTop - top)}px`;
    bottom = Math.max(bottom, top + Math.max(58, nextTop - top));
  });
  // the accompaniment's controls sit beside its two staves
  const pianoTop = staves[staffEls.length];
  if (acc && pianoShown() && pianoTop) {
    const top = pianoTop.top - 26 + offset;
    acc.style.top = `${top}px`;
    acc.style.height = `${Math.max(58, sysBottom - top)}px`;
    bottom = Math.max(bottom, top + Math.max(58, sysBottom - top));
  }
  // a box too short for its controls (staves close together) puts each voice on one row
  staffEls.forEach((el) => {
    el.classList.remove("tight");
    if (el.scrollHeight > el.clientHeight + 1) el.classList.add("tight");
  });
  let y = Math.max(bottom, state.view === "tracks" ? $("lane").offsetTop : sysBottom);
  for (const el of rest) {
    el.style.top = `${y}px`;
    el.style.height = "auto";
    y += el.offsetHeight;
  }
  headersEl.style.height = `${y + 8}px`;
}

// chord lane under the staves in tracks view
function buildLane() {
  const lane = $("lane");
  lane.innerHTML = "";
  if (state.view !== "tracks") return;
  lane.style.width = `${sheet.offsetWidth}px`;
  const copies = unfolded() ? state.verses.length : 1;
  const all = Array.from({ length: copies }, (_, j) => hymn.chords.map((c) => ({ ...c, q: c.q + j * hymn.totalQ }))).flat();
  all.forEach((c, i) => {
    const x0 = view.xAt(c.q);
    const x1 = all[i + 1] ? view.xAt(all[i + 1].q) : sheet.offsetWidth - 40;
    const b = document.createElement("div");
    b.className = "blk";
    b.style.left = `${x0 - 6}px`;
    b.style.width = `${Math.max(24, x1 - x0)}px`;
    b.textContent = chordLabel(c.name);
    lane.append(b);
  });
}

// ---- playback ------------------------------------------------------------

function applyMix() {
  for (const ch of CH) {
    engine.setLevel(ch, state.levels[ch] ?? 0.8);
    engine.setMuted(ch, !heard(ch));
    engine.setPan(ch, state.pans[ch] ?? 0);
  }
  engine.voiceSounds = Object.fromEntries("SATB".split("").map((k) => [k, soundOf(k) === "piano" ? "piano" : "choir"]));
}

function rebuild(keep = true, seamless = false) {
  if (!hymn) return;
  const wasPlaying = engine.playing;
  const loc = keep && perf ? locate(perf, engine.now()) : null;
  const stems = anySung() ? stemInfo : new Map();
  perf = performance(hymn, { tempo: state.tempo, verses: state.verses, accomp: state.accomp, countIn: state.countIn, countAt: state.countAt, introVoice: state.introVoice, stems, intro: state.intro, interlude: state.interlude, shiftAt, metronome: state.metronome, split: !(useWarble() && Warble.native()) || nativeSplits() });
  if (seamless && wasPlaying) { // only the sounds changed (singers arrived): swap them in without a restart
    engine.swap(perf.events);
    waterfall.setPerformance(perf);
    return;
  }
  engine.load(perf.events);
  waterfall.setPerformance(perf);
  resetFollower();
  applyLoop();
  let t = 0;
  if (loc) {
    const k = perf.passes.findIndex((p) => p.kind === loc.kind && p.verse === loc.verse);
    if (k >= 0) t = passTime(perf, k, loc.q);
  }
  if (wasPlaying) engine.play(t);
  else engine.pausedAt = t;
  paint(true);
}

function seek(t) {
  if (engine.playing) engine.play(t);
  else engine.pausedAt = t;
  paint(true);
}

function setPlaying(on) {
  $("playIcon").setAttribute("d", on ? "M6 4h4v16H6zM14 4h4v16h-4z" : "M7 4.5v15l13-7.5z");
  $("playBtn").setAttribute("aria-label", on ? "Pause" : "Play");
}

async function togglePlay() {
  if (!perf) return;
  if (engine.playing) { engine.pause(); setPlaying(false); return; }
  engine.ensure(); // inside the click, so the browser lets the sound start
  let from = engine.pausedAt ?? 0;
  if (from >= perf.total - 0.05) from = 0;
  if (!(await chooseSingers(from))) return;
  applyMix();
  if (state.accomp !== "off" || anyPiano() || state.intro !== "none" || state.interlude !== "none") engine.loadPiano();
  await engine.play(from);
  setPlaying(true);
}

function stopPlayback() {
  if (swm.on && !swm.joining) { swmStop(); return; }
  engine.stop();
  if (liveChanges.length) { liveChanges = []; if (perf) rebuild(false); } // live key changes last one run
  setPlaying(false);
  if (recording) finishRecording();
  view?.clear();
  solfa?.clear();
  words?.clear();
  lastSystem = null;
  lastFollowEl = null;
  paint(true);
  viewport.scrollLeft = 0;
  window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
}

// ---- syncopation -----------------------------------------------------------

/** Mark each syncopated note in the score (every written-out copy of it). */
function drawSyncMarks() {
  const layer = $("syncLayer");
  layer.innerHTML = "";
  if (!state.showSync || !view) return;
  const copies = unfolded() ? state.verses.length : 1;
  for (const x of syncopations(hymn)) {
    for (let j = 0; j < copies; j++) {
      const n = view.notes.find((v) => v.voice === x.voice && Math.abs(v.on - (x.q + j * hymn.totalQ)) < 1e-6);
      if (!n?.box) continue;
      const m = document.createElement("span");
      m.className = "sync-mark";
      m.style.setProperty("--c", `var(--${x.voice})`);
      m.style.left = `${n.box.x + n.box.w / 2}px`;
      m.style.top = `${n.box.y - 4}px`;
      m.title = `Syncopation: ${VOICES[x.voice].name}, bar ${x.m}. The note starts off the beat and is held through a stronger beat.`;
      layer.append(m);
    }
  }
}

function syncSummary() {
  const found = syncopations(hymn);
  if (!found.length) return "No syncopation here: every note starts on the beat, or ends before the next stronger beat.";
  const bars = [...new Set(found.map((x) => x.m))].sort((a, b) => a - b);
  return `${found.length} syncopated note${found.length === 1 ? "" : "s"}, in bar${bars.length === 1 ? "" : "s"} ${bars.join(", ")}.`;
}

function syncRhythmButtons() {
  $("addSync").textContent = `Add syncopation to bars ${state.loop.from} to ${state.loop.to}`;
  $("restoreRhythm").hidden = !hymn?.variant;
}

function addSyncopation() {
  const before = hymn;
  hymn = syncopate(hymn, state.loop.from, state.loop.to);
  if (!hymn.variant.bars) {
    hymn = before;
    toast(`Bars ${state.loop.from} to ${state.loop.to} have no note on beat 2 that can come half a beat early in every voice. Try other bars.`, 7000);
    return;
  }
  state.showSync = true;
  $("showSync").checked = true;
  save("showSync");
  syncRhythmButtons();
  if (anySung()) prepareStems(); else rebuild();
  renderAll();
  toast(`Syncopation added in ${hymn.variant.bars} bar${hymn.variant.bars === 1 ? "" : "s"}. ${syncSummary()}`, 7000);
}

function restoreRhythm() {
  hymn = hymnWritten;
  syncRhythmButtons();
  if (anySung()) prepareStems(); else rebuild();
  renderAll();
  toast("Back to the written rhythm.", 3000);
}

// ---- loop ------------------------------------------------------------------

function syncLoopInputs() {
  $("loopBtn").setAttribute("aria-pressed", String(state.loop.on));
  $("loopFrom").value = state.loop.from;
  $("loopTo").value = state.loop.to;
  syncRhythmButtons();
}

function applyLoop(pass = null) {
  if (!perf || !hymn) return;
  if (!state.loop.on) { engine.setLoop(null); drawLoopBoxes(); drawWordsLoop(); return; }
  const loc = locate(perf, engine.now());
  const [a, b] = barSpan(hymn, perf, pass ?? (loc ? loc.pass : 0), state.loop.from, state.loop.to);
  engine.setLoop(a, b);
  if (!engine.playing && (engine.pausedAt < a || engine.pausedAt >= b)) engine.pausedAt = a;
  drawLoopBoxes();
  drawWordsLoop();
}

function clearLoop() {
  setLoop(state.loop.from, state.loop.to, false);
  toast("Selection cleared.", 2000);
}

function setLoop(from, to, on = true) {
  const lo = Math.max(1, Math.min(from, to));
  const hi = Math.min(hymn.measures, Math.max(from, to));
  state.loop = { on, from: lo, to: hi };
  syncLoopInputs();
  applyLoop();
}

function drawLoopBoxes(pending) {
  const layer = $("loopLayer");
  layer.innerHTML = "";
  if (!view || !isScoreView()) return;
  const range = pending || (state.loop.on ? state.loop : null);
  if (!range) return;
  const off = unfolded() && !pending ? (verseOrdinal(perf && locate(perf, engine.now())) ?? 0) * hymn.measures : 0;
  const boxes = view.barBoxes(range.from + off, range.to + off);
  boxes.forEach((b, i) => {
    const d = document.createElement("div");
    d.className = `loopbox${pending ? " pending" : ""}${i === 0 ? " first" : ""}${i === boxes.length - 1 ? " last" : ""}`;
    Object.assign(d.style, { left: `${b.x}px`, top: `${b.y - 10}px`, width: `${b.w}px`, height: `${b.h + 20}px` });
    layer.append(d);
    if (pending) return;
    if (i === boxes.length - 1) {
      const x = document.createElement("button");
      x.className = "loop-clear";
      x.textContent = "×";
      x.title = "Clear the selection (Esc)";
      x.setAttribute("aria-label", "Clear the selection");
      x.style.left = `${b.x + b.w - 11}px`;
      x.style.top = `${b.y - 22}px`;
      x.addEventListener("pointerdown", (e) => e.stopPropagation());
      x.onclick = clearLoop;
      layer.append(x);
    }
    // grab either edge to widen or narrow the loop
    for (const edge of [i === 0 ? "from" : null, i === boxes.length - 1 ? "to" : null].filter(Boolean)) {
      const hnd = document.createElement("div");
      hnd.className = `loop-edge ${edge}`;
      hnd.title = edge === "from" ? "Drag to move the start of the loop" : "Drag to move the end of the loop";
      hnd.style.top = `${b.y - 10}px`;
      hnd.style.height = `${b.h + 20}px`;
      hnd.style.left = `${edge === "from" ? b.x - 7 : b.x + b.w - 7}px`;
      hnd.addEventListener("pointerdown", (e) => startEdgeDrag(e, edge));
      layer.append(hnd);
    }
  });
}

function startEdgeDrag(e, edge) {
  e.stopPropagation();
  e.preventDefault();
  const r = () => $("score").getBoundingClientRect();
  const y = e.clientY;
  const onMove = (ev) => {
    const raw = view.barAt(ev.clientX - r().left, y - r().top) ?? view.barAt(ev.clientX - r().left, ev.clientY - r().top);
    if (!raw) return;
    const bar = ((raw - 1) % hymn.measures) + 1; // written out: the same bar in any verse
    const from = edge === "from" ? Math.min(bar, state.loop.to) : state.loop.from;
    const to = edge === "to" ? Math.max(bar, state.loop.from) : state.loop.to;
    if (from !== state.loop.from || to !== state.loop.to) setLoop(from, to, true);
  };
  const onUp = () => { window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp); toast(`Looping bars ${state.loop.from} to ${state.loop.to}`); };
  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerup", onUp);
}

// drag across bars to choose a loop; a plain click on a note jumps there
let drag = null;
sheet.addEventListener("pointerdown", (e) => {
  if (!view || e.button !== 0 || e.target.closest(".loop-edge")) return;
  const r = $("score").getBoundingClientRect();
  // in the app a finger scrolls and pinches; tapping a note still plays from there
  const bar = APP && e.pointerType === "touch" ? null : view.barAt(e.clientX - r.left, e.clientY - r.top);
  drag = { bar, x: e.clientX, moved: false, note: e.target.closest("g.note") };
});
window.addEventListener("pointermove", (e) => {
  if (!drag || drag.bar === null) return;
  if (!drag.moved && Math.abs(e.clientX - drag.x) < 8) return;
  drag.moved = true;
  sheet.classList.add("selecting");
  const r = $("score").getBoundingClientRect();
  const bar = view.barAt(e.clientX - r.left, e.clientY - r.top) ?? drag.last ?? drag.bar;
  drag.last = bar;
  drawLoopBoxes({ from: Math.min(drag.bar, bar), to: Math.max(drag.bar, bar) });
});
window.addEventListener("pointerup", () => {
  if (!drag) return;
  const d = drag;
  drag = null;
  sheet.classList.remove("selecting");
  const inVerse = (b) => ((b - 1) % hymn.measures) + 1;
  if (d.moved && d.bar !== null) { setLoop(inVerse(d.bar), inVerse(d.last ?? d.bar)); toast(`Looping bars ${state.loop.from} to ${state.loop.to}. Drag its edges to change it.`); return; }
  if (d.note && perf) {
    const n = view.notes.find((x) => x.el === d.note);
    if (n) seek(timeOfScoreQ(n.on));
  }
});
// in sol-fa and words views, click a note or word to jump there
// ---- the Words view: choose words to repeat, as dragging across bars does in the score ----
// Drag across words (mouse), or press and hold a line (touch: that line repeats; hold another line of the
// same stanza to stretch the repeat to it). The words repeated are marked, with an x at their end; the x,
// Escape or a tap on a word outside them stops the repeat and the music plays on.
let wordsLoopV = null; // the stanza (data-v) the repeat was chosen in, for marking it
let wordsPress = null;
const wordsOn = () => state.view === "words";
const sylOf = (el) => el?.closest?.(".w-syl[data-q]");
function sylsBetween(a, b) {
  const block = a.closest(".w-block");
  if (!block || block !== b.closest(".w-block")) return [a];
  const all = [...block.querySelectorAll(".w-syl[data-q]")];
  const i = all.indexOf(a), j = all.indexOf(b);
  return all.slice(Math.min(i, j), Math.max(i, j) + 1);
}
function markPending(syls) {
  for (const el of $("altView").querySelectorAll(".w-pending")) el.classList.remove("w-pending");
  for (const el of syls || []) el.classList.add("w-pending");
}
/** Repeat the bars these words are sung in, in their stanza. */
function repeatWords(syls) {
  if (!perf || !syls.length) return;
  const qs = syls.map((el) => Number(el.dataset.q));
  const v = Number(syls[0].dataset.v || 0), want = v >= 1000 ? v - 1000 : v;
  const from = barAt(hymn, Math.min(...qs)), to = barAt(hymn, Math.max(...qs));
  // in that stanza (the refrain shared by all verses stays in the verse playing)
  const loc = locate(perf, engine.now());
  let k = want > 0 ? perf.passes.findIndex((p) => p.kind === "verse" && p.verse === want) : -1;
  if (k < 0) k = loc?.kind === "verse" ? loc.pass : perf.passes.findIndex((p) => p.kind === "verse");
  wordsLoopV = String(syls[0].dataset.v);
  state.loop = { on: true, from, to };
  syncLoopInputs();
  applyLoop(k); // the music goes to the repeat's start unless it is already inside it
  paint(true);
  toast(from === to ? `Repeating bar ${from}. Tap × to stop.` : `Repeating bars ${from} to ${to}. Tap × to stop.`, 3500);
}
/** Mark the words of the repeat in the Words view (and put the way out at their end). */
function drawWordsLoop() {
  const root = $("altView");
  for (const el of root.querySelectorAll(".w-looped")) el.classList.remove("w-looped");
  root.querySelector(".w-loop-clear")?.remove();
  if (!wordsOn() || !state.loop.on || !hymn) return;
  const loc = perf && locate(perf, engine.now());
  const playingV = loc?.kind === "verse" ? String(passVerse(loc.pass)) : null;
  const blocks = [...root.querySelectorAll(".w-block")];
  const block = blocks.find((b) => b.dataset.v === wordsLoopV) || blocks.find((b) => b.dataset.v === playingV) || null;
  if (!block) return;
  const marked = [...block.querySelectorAll(".w-syl[data-q]")].filter((el) => {
    const m = barAt(hymn, Number(el.dataset.q));
    return m >= state.loop.from && m <= state.loop.to;
  });
  marked.forEach((el) => el.classList.add("w-looped"));
  const last = marked[marked.length - 1];
  if (!last) return;
  const x = document.createElement("button");
  x.className = "w-loop-clear";
  x.textContent = "Stop repeating";
  x.title = "Stop repeating; the music plays on (Esc)";
  x.setAttribute("aria-label", "Stop repeating");
  x.addEventListener("pointerdown", (e) => e.stopPropagation());
  x.onclick = (e) => { e.stopPropagation(); stopRepeat(); };
  last.after(x);
}
const passVerse = (k) => perf?.passes[k]?.verse;
/** Out of the repeat: the music plays on from where it is. */
function stopRepeat() {
  if (!state.loop.on) return;
  wordsLoopV = null;
  clearLoop();
}

$("altView").addEventListener("pointerdown", (e) => {
  const s = wordsOn() && sylOf(e.target);
  if (!s || e.button > 0) return;
  wordsPress = { start: s, last: s, x: e.clientX, y: e.clientY, drag: false, done: false, touch: e.pointerType !== "mouse" };
  wordsPress.timer = setTimeout(() => { // press and hold: this line repeats (or the repeat stretches to it)
    const p = wordsPress;
    if (!p || p.drag) return;
    p.done = true;
    const line = [...(s.closest(".w-line")?.querySelectorAll(".w-syl[data-q]") || [s])];
    const looped = [...$("altView").querySelectorAll(".w-looped")];
    const sameBlock = looped.length && looped[0].closest(".w-block") === s.closest(".w-block");
    navigator.vibrate?.(15);
    if (sameBlock && !line.every((el) => looped.includes(el))) { // stretch the repeat to this line: from the first of both to the last
      const all = [...s.closest(".w-block").querySelectorAll(".w-syl[data-q]")];
      const ix = [...looped, ...line].map((el) => all.indexOf(el));
      repeatWords(all.slice(Math.min(...ix), Math.max(...ix) + 1));
    } else repeatWords(line);
  }, 550);
});
window.addEventListener("pointermove", (e) => {
  const p = wordsPress;
  if (!p || p.done) return;
  if (!p.drag && Math.hypot(e.clientX - p.x, e.clientY - p.y) < 8) return;
  clearTimeout(p.timer);
  if (p.touch) { wordsPress = null; return; } // a finger moving scrolls the words
  p.drag = true;
  const s = sylOf(document.elementFromPoint(e.clientX, e.clientY));
  if (s) p.last = s;
  markPending(sylsBetween(p.start, p.last));
});
window.addEventListener("pointerup", () => {
  const p = wordsPress;
  if (!p) return;
  clearTimeout(p.timer);
  markPending(null);
  if (p.drag) { p.done = true; repeatWords(sylsBetween(p.start, p.last)); }
  // the click that follows a hold or a drag is not a tap
  if (p.done) setTimeout(() => { if (wordsPress === p) wordsPress = null; }, 400); else wordsPress = null;
});
$("altView").addEventListener("contextmenu", (e) => { if (sylOf(e.target) || APP) e.preventDefault(); });
$("altView").addEventListener("selectstart", (e) => { if (sylOf(e.target) || APP) e.preventDefault(); });

$("altView").addEventListener("click", (e) => {
  if (wordsPress?.done) { wordsPress = null; return; } // it chose a repeat
  if (e.target.closest(".w-loop-clear")) return;
  const t = e.target.closest("[data-q], [data-c]");
  if (!t || !perf) return;
  // a tap on words outside the repeat leaves it, and goes there
  if (wordsOn() && state.loop.on && t.classList.contains("w-syl") && !t.classList.contains("w-looped")) { wordsLoopV = null; setLoop(state.loop.from, state.loop.to, false); }
  const q = t.dataset.q !== undefined ? Number(t.dataset.q) : solfa.cells[Number(t.dataset.c)]?.on;
  if (q === undefined) return;
  const loc = locate(perf, engine.now());
  let k = loc && loc.kind === "verse" ? loc.pass : perf.passes.findIndex((p) => p.kind === "verse");
  // a word of a stanza (Words view) goes to that stanza when it is sung; the shared refrain stays in the verse playing
  const v = Number(t.dataset.v || 0), want = v >= 1000 ? v - 1000 : v;
  if (want > 0) {
    const kv = perf.passes.findIndex((p) => p.kind === "verse" && p.verse === want);
    if (kv >= 0) k = kv;
  }
  seek(passTime(perf, k, q));
});

// ---- the moving place ----------------------------------------------------

let lastT = -1;
let making = false; // a video is being made: its frames are drawn by the maker, not by the clock
function frame() {
  requestAnimationFrame(frame);
  if (making) return;
  paint(false);
  if (state.practice) drawPractice();
}

// ---- practice: feel the meter, sing in tune -----------------------------------

let conductor = null;
let listener = null;
let quiz = null;          // { tune, engine, answered, t0 }
let quizScore = { right: 0, asked: 0 };
let trace = [];           // your recent pitch: [{t, p, target, off}]
let tuneTally = { inTune: 0, sung: 0, pass: -1 };
let taps = [];

function setupPractice() {
  conductor = new Conductor($("conductor"));
  const panel = $("practicePanel");
  const showTab = (tab) => {
    state.practiceTab = tab;
    save("practiceTab");
    $("tabMeter").setAttribute("aria-selected", String(tab === "meter"));
    $("tabSing").setAttribute("aria-selected", String(tab === "sing"));
    $("prMeter").hidden = tab !== "meter";
    $("prSing").hidden = tab !== "sing";
    applyMix();
  };
  $("tabMeter").onclick = () => showTab("meter");
  $("tabSing").onclick = () => showTab("sing");
  const b = $("practiceBtn");
  const sync = () => { panel.hidden = !state.practice; b.setAttribute("aria-pressed", String(state.practice)); };
  b.onclick = () => { state.practice = !state.practice; save("practice"); sync(); if (!state.practice) stopListening(); applyMix(); };
  $("practiceClose").onclick = () => { state.practice = false; save("practice"); sync(); stopListening(); applyMix(); };
  sync();
  showTab(state.practiceTab);
  $("metronome").checked = state.metronome;
  $("metronome").onchange = (e) => { state.metronome = e.target.checked; save("metronome"); rebuild(); };
  $("tapPad").onclick = () => tap();
  document.addEventListener("keydown", (e) => {
    if ((e.key === "t" || e.key === "T") && state.practice && state.practiceTab === "meter" && !e.target.closest("input, select, textarea")) { e.preventDefault(); tap(); }
  });
  $("quizPlay").onclick = playQuiz;
  $("quizChoices").querySelectorAll("button").forEach((btn) => { btn.onclick = () => answerQuiz(btn); });
  $("micBtn").onclick = () => (listener?.on ? stopListening() : startListening());
  for (const id of ["muteMine", "anyOctave"]) {
    $(id).checked = state[id];
    $(id).onchange = (e) => { state[id] = e.target.checked; save(id); applyMix(); };
  }
  $("singVoice").onchange = (e) => { state.singVoice = e.target.value; save("singVoice"); trace = []; applyMix(); resetFollower(); };
}

function syncPracticeForHymn() {
  const f = feel(hymn.time);
  conductor.setBeats(f.beats);
  $("meterLabel").textContent = f.label;
  const voices = hymnVoices();
  if (!voices.includes(state.singVoice)) state.singVoice = voices[0];
  $("singVoice").innerHTML = voices.map((k) => `<option value="${k}" ${k === state.singVoice ? "selected" : ""}>${VOICES[k].name}</option>`).join("");
}

/** The beat being played now, from the performance's beat grid. */
function beatNow(t) {
  if (!perf?.beats?.length) return null;
  let i = -1;
  for (let k = 0; k < perf.beats.length; k++) { if (perf.beats[k].t <= t + 1e-6) i = k; else break; }
  if (i < 0) return null;
  const b = perf.beats[i];
  const next = perf.beats[i + 1];
  const len = next ? next.t - b.t : 60 / state.tempo;
  return { ...b, f: Math.min(0.999, (t - b.t) / len) };
}

function drawPractice() {
  if (state.practiceTab === "meter") {
    if (quiz && !quiz.answered) { $("beatNum").textContent = "?"; return; } // no clues while guessing
    const b = engine.playing || engine.pausedAt ? beatNow(engine.now()) : null;
    const beat = b ? b.beat : 0;
    conductor.show(beat, b ? b.f : 0);
    $("beatNum").textContent = beat + 1;
    $("beatNum").classList.toggle("one", beat === 0);
    return;
  }
  // sing in tune: your pitch against the note your part has now
  const c = $("pitchLane");
  const w = c.clientWidth;
  const h = c.clientHeight;
  const dpr = window.devicePixelRatio || 1;
  if (c.width !== Math.round(w * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
  const g = c.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  const voice = state.singVoice;
  const notes = (perf?.events || []).filter((e) => e.ch === voice && !e.stem && e.p > 0)
    .map((e) => ({ t: e.t, dur: e.dur, p: e.p, label: hymn.solfa?.[voice]?.[e.i] || "" }));
  // what you sing reaches the microphone a little after the sound left the speakers
  // (engine.now() is already what the speakers are playing)
  const lag = engine.ctx ? 0.03 : 0;
  // while the music plays, your voice is drawn against its clock; stopped, the lane is a tuner
  const tuner = !engine.playing;
  if (tuner !== drawPractice.tuner) { trace = []; drawPractice.tuner = tuner; }
  const now = tuner ? window.performance.now() / 1000 : engine.now(); // window.: core.js exports its own performance()
  if (listener?.on && (frame.tick = (frame.tick || 0) + 1) % 2 === 0) {
    const sung = listener.read();
    const t = tuner ? now : now - lag;
    const target = tuner ? null : notes.find((n) => n.t <= t && t < n.t + n.dur) || null;
    const off = sung !== null && target ? centsOff(sung, target.p, state.anyOctave) : null;
    trace.push({ t, p: sung, target: target ? target.p : null, off });
    while (trace.length && trace[0].t < now - 8) trace.shift();
    const loc = engine.playing ? locate(perf, t) : null;
    if (loc && loc.pass !== tuneTally.pass) tuneTally = { inTune: 0, sung: 0, pass: loc.pass };
    if (engine.playing && target && sung !== null) { tuneTally.sung++; if (Math.abs(off) <= 50) tuneTally.inTune++; }
    $("pitchReadout").textContent = sung === null ? (tuner ? "Sing a note, or press play and sing your part" : "Listening…")
      : tuner ? `You're singing ${noteName(sung)}` : !target ? `Rest (you're singing ${noteName(sung)})` : describeCents(off);
    $("tuneScore").textContent = tuneTally.sung > 20 ? `In tune ${Math.round((100 * tuneTally.inTune) / tuneTally.sung)}% of this verse` : "";
  }
  drawLane(g, w, h, now, tuner ? [] : notes, trace, colors, colors[voice], state.anyOctave);
}

function describeCents(off) {
  const a = Math.abs(off);
  if (a <= 25) return "In tune";
  if (a <= 50) return `${off > 0 ? "A little sharp" : "A little flat"} (${off > 0 ? "+" : "−"}${Math.round(a)} cents)`;
  const semis = Math.round(a / 100);
  return `${off > 0 ? "Too high" : "Too low"} by ${semis === 1 ? "a semitone" : `${semis} semitones`}`;
}

// ---- sing with me --------------------------------------------------------------
// You sing; the music joins you. It listens (melody.js: the hymn, or your place in this one, your key and
// your tempo, from the notes you sing), comes in where you are by then, and keeps your pace (follow.js).
// A singer it loses (a line skipped, a verse begun again) is found again in the hymn.
const SURE = { fit: 1.6, margin: 0.35 }; // when a match is sure enough to join in (see harness qbh_stream)
const HERE = 0.5; // the music moves only when another place fits the singer this much better than where it is
const swm = { on: false, do: "piano", find: false, joined: false, joining: false, status: "", tracker: new NoteTracker(),
  idx: null, hymnIdx: null, searched: 0, saved: null, voice: "S" };
if (new URLSearchParams(location.search).has("debug")) window.__swm = swm; // tests read what it heard
let melodiesP = null;
function allMelodies() {
  // the tunes of every hymn (tools/build_melodies.py): the site's newest copy, else the one shipped with the player
  melodiesP ??= (async () => {
    let data = null;
    try { const r = await fetchWithin(`${DATA}data/melodies.json`, 15000, { cache: "no-cache" }); if (r.ok) data = await r.json(); } catch { /* offline */ }
    if (!data) data = await fetch("data/melodies.json").then((r) => r.json());
    return new MelodyIndex(data);
  })().catch((e) => { melodiesP = null; throw e; });
  return melodiesP;
}
/** This hymn's parts as tunes, for finding where in it someone sings (any part). */
function hymnTunes(h) {
  return { tunes: ["S", "A", "T", "B"].filter((k) => h.voices[k]?.length).map((k) => {
    const n = [];
    let prev = null;
    for (const x of h.voices[k]) {
      if (prev?.tie && prev.p === x.p && n.length) n[n.length - 1][1] += x.d; else n.push([x.p, x.d, x.q]);
      prev = x;
    }
    return { ids: [k], n };
  }) };
}
function swmSay(text) {
  swm.status = text;
  $("swmStatus").textContent = text;
  $("swmBar").hidden = !swm.on;
}

async function swmStart({ do: what = "piano", find = false } = {}) {
  if (!hymn && !find) return;
  swmStop();
  engine.ensure();
  stopPlayback();
  listener = listener || new PitchListener();
  try {
    await engine.ctx.resume();
    if (!listener.on) await listener.start(engine.ctx);
  } catch {
    toast("Sing with me needs the microphone. Allow it for this page and try again.", 6000);
    return;
  }
  Object.assign(swm, { on: true, do: what === "sing" ? "sing" : "piano", find: !!find, joined: false, joining: false, searched: 0, candidates: [], idx: null, hymnIdx: null, reSearched: 0, checkedAt: 0, prev: null, lost: false, away: null });
  swm.tracker.reset();
  // listening runs on its own clock, not the screen's: a locked phone draws about two frames a second
  clearInterval(swm.timer);
  swm.timer = setInterval(() => { if (swm.on) swmTick(); }, 30);
  $("swmBtn").setAttribute("aria-pressed", "true");
  swmSay(find ? "Sing a line or two of any hymn. I'm listening…" : `Start singing ${hymn.title}, anywhere, any part. I'm listening…`);
  if (find) {
    try { swm.idx = await allMelodies(); } catch { swmSay("The hymn tunes could not load. Check the connection and try again."); }
  } else swm.idx = new MelodyIndex(hymnTunes(hymn));
}

function swmStop() {
  if (!swm.on) return;
  swm.on = false;
  swm.joined = false;
  clearInterval(swm.timer);
  stopPlayback();
  engine.setRate(1);
  if (!singing()) listener?.stop();
  if (swm.saved) {
    Object.assign(state, swm.saved);
    swm.saved = null;
    $("tempo").value = state.tempo;
    $("tempoLabel").textContent = `${state.tempo} a minute`;
  }
  if (hymn) { applyMix(); rebuild(false); renderAll(); }
  $("swmBtn").setAttribute("aria-pressed", "false");
  swmSay("");
}

/** Every frame while on: listen; before joining, look for the hymn or the place; after, keep the pace. */
function swmTick() {
  if (!listener?.on || !engine.ctx) return;
  const now = engine.ctx.currentTime;
  const p = listener.read();
  swm.tracker.feed(p, now - 0.035); // the pitch is read from the last ~40 ms of sound
  if (swm.tracker.notes.length > 80) swm.tracker.notes.splice(0, 40);
  if (swm.joined) {
    if (engine.playing) {
      const r = follower.update(p, engine.now(), now, true);
      if (r) engine.setRate(r);
    }
    if (engine.playing || swm.lost) swmRelocate(now);
    return;
  }
  if (!swm.idx || swm.joining) return;
  const notes = swm.tracker.sung();
  if (notes.length === swm.searched) return; // look again at each new note
  swm.searched = notes.length;
  const heard = swmHeard(notes);
  if (notes.length < 6) { swmSay(notes.length ? `Heard ${heard}. I start comparing after 6 notes…` : swm.status); return; }
  const results = swm.idx.search(notes.slice(-24));
  const d = decide(results, SURE, swm.idx);
  // sure twice running, the same tune at the same place: among 1,689 tunes one lucky fit comes too easily
  // (a song that is in no hymnal, or an alto, was joined to a wrong hymn one time in four)
  // (not needed for a place in the open hymn: four parts to choose from, and a wrong place is put right)
  const again = d && (!swm.find || (swm.prev && swm.prev.tune === d.tune && Math.abs(d.end - swm.prev.end) <= 3));
  swm.prev = d;
  if (d && !again) decide.why = "again";
  if (!d || !again) { swmSay(swmSearching(notes, heard, results)); return; }
  swmJoin(d, notes);
}

const PC = ["C", "C♯", "D", "E♭", "E", "F", "F♯", "G", "A♭", "A", "B♭", "B"];
/** The notes heard, as letters (the last few): so the singer sees it hears them. */
function swmHeard(notes) {
  const last = notes.slice(-8).map((n) => PC[((Math.round(n.p) % 12) + 12) % 12]);
  return `${notes.length} note${notes.length === 1 ? "" : "s"}: ${notes.length > 8 ? "… " : ""}${last.join(" ")}`;
}

/** What the search found so far, in words: the closest hymns (or parts) and why it is not sure yet. */
function swmSearching(notes, heard, results) {
  const names = [];
  for (const r of results) {
    const name = swm.find
      ? (() => { const e = hymnList.find((x) => x.id === r.ids[0]); return e ? `${e.title} (${e.book} ${e.number})` : r.ids[0]; })()
      : `${VOICES[r.ids[0]]?.name || r.ids[0]}, bar ${barAt(hymn, r.at ?? 0)}`;
    if (!names.includes(name)) names.push(name);
    if (names.length === 3) break;
  }
  swm.candidates = names;
  const what = swm.find ? `Comparing with ${swm.idx.tunes.length.toLocaleString()} hymn tunes` : `Looking for your place in ${hymn.title}`;
  if (!names.length) return `Heard ${heard}. ${what}: nothing close yet, sing on…`;
  const why = { fit: "not close enough yet", margin: "these are too close to tell apart", place: "those notes come twice in it, waiting to hear which", tunes: "several tunes start alike, waiting until they part", again: "nearly sure, one more note" }[decide.why] || "not sure yet";
  return `Heard ${heard}. ${what}. Closest: ${names.join("; ")}. ${why[0].toUpperCase()}${why.slice(1)}, sing on…`;
}

/** Join in: the hymn (find), the key and tempo you sing in, from where you will be when the sound arrives. */
async function swmJoin(d, notes) {
  swm.joining = true;
  try {
    let match = d, voice;
    if (swm.find) {
      // this hymn when it is one of those with these notes, else the best match
      // (else one in the open hymn's hymnal: the same tune is in several, and the best fit is any of them)
      const has = (r) => r.ids.includes(hymn?.id);
      const mine = (id) => !!hymn && id.startsWith(`${hymn.book}-`);
      match = d.same.find(has) || d.same.find((r) => r.ids.some(mine)) || d;
      const id = has(match) ? hymn.id : match.ids.find(mine) || match.ids[0];
      if (id !== hymn?.id) {
        const entry = hymnList.find((x) => x.id === id);
        if (!entry) { swm.searched = 0; return; }
        $("hymnPicker").value = id;
        history.replaceState(null, "", `#${id}`); // (not location.hash: a hash change reloads the app's page)
        await loadHymn(entry);
        if (!swm.on) return;
      }
      voice = hymn.lyricVoice;
    } else voice = swm.idx.tunes[match.tune].ids[0];
    const ok = (x) => x > 0.15 && x < 2.5;
    const spq = ok(match.spqNow) ? match.spqNow : ok(match.spq) ? match.spq : 60 / state.tempo; // your pace lately
    let shift = Math.round(match.shift);
    shift = ((shift % 12) + 12) % 12;
    if (shift > 6) shift -= 12; // an octave off is the same key
    swm.saved ??= { tempo: state.tempo, transpose: state.transpose, countIn: state.countIn, intro: state.intro, interlude: state.interlude };
    Object.assign(state, { tempo: Math.max(30, Math.min(240, Math.round(60 / spq))), transpose: shift, countIn: false, intro: "none", interlude: "none" });
    $("tempo").value = state.tempo;
    $("tempoLabel").textContent = `${state.tempo} a minute`;
    swm.voice = voice;
    swm.hymnIdx = new MelodyIndex(hymnTunes(hymn));
    swm.joined = true;
    engine.setRate(1);
    applyMix();
    rebuild(false);
    renderAll();
    if (swm.do === "piano") await engine.loadPiano();
    if (!swm.on) return;
    swmGo(match.at, match.sungFrom, spq, null);
    swm.joinedAt = engine.ctx.currentTime;
    const keyName = prettyChord(keyFor(state.transpose).name);
    swmSay(`${hymn.number} ${hymn.title}, in ${keyName}: ${swm.do === "piano" ? "playing" : "singing"} with you`);
  } finally {
    swm.joining = false;
  }
}

/** Play from the place you are singing: q (quarters) is where the note you are on is written, sungAt when you began it. */
function swmGo(q, sungAt, spq, pass) {
  const now = engine.ctx.currentTime;
  const lead = 0.12 + engine.latency(); // the sound reaches you this long after it is scheduled
  const k = pass ?? Math.max(0, perf.passes.findIndex((x) => x.kind === "verse"));
  const qNow = Math.min(q + (now + lead - sungAt) / spq, perf.passes[k].qTo - 1e-3);
  engine.play(passTime(perf, k, qNow)).then(() => setPlaying(true));
  resetFollower();
}

/**
 * Where are you? Every second and a half, your last ten notes are looked for in the whole hymn (any part); when
 * that is sure and the music is somewhere else (a line skipped, a verse begun again), the music goes there.
 * The note-by-note following alone can be fooled: nearby notes of the same pitch keep it busy in the wrong place.
 */
/** How much worse the notes fit where the music is (quarter q) than at their best place in the hymn. */
function swmHereGap(notes, best, q, spq, now) {
  const span = (notes[notes.length - 1].t0 - notes[0].t0) / spq + 4;
  const tunes = swm.hymnIdx.tunes.map((t) => ({ ids: t.ids, n: t.notes.filter((x) => x[2] >= q - span && x[2] <= q + 3) })).filter((t) => t.n.length >= 4);
  const here = tunes.length ? new MelodyIndex({ tunes }).search(notes)[0] : null;
  // "here" is within three quarters of the music, not merely in the stretch searched
  if (!here || Math.abs(here.at + (now - here.sungFrom) / spq - q) >= 3) return Infinity;
  return here.score - best.score;
}

function swmRelocate(now) {
  if (now - (swm.checkedAt || 0) < 1.5 || now - swm.joinedAt < 2) return;
  const all = swm.tracker.sung();
  if (all.length === swm.reSearched) return;
  // only the notes since your last breath: a singer who goes elsewhere breathes first, and notes from
  // before and after a jump fit no one place
  let from = Math.max(0, all.length - 10);
  for (let i = all.length - 1; i > from; i--) if (all[i].t0 - all[i - 1].t1 > 0.6) { from = i; break; }
  const notes = all.slice(from);
  if (notes.length < 5) return; // 5 notes tell that you are elsewhere; 7 where
  swm.checkedAt = now;
  swm.reSearched = all.length;
  const res = swm.hymnIdx.search(notes);
  const d = notes.length >= 7 ? decide(res, SURE, swm.hymnIdx) : null;
  const loc = locate(perf, engine.now());
  if (!loc) return;
  // a line that repeats an earlier one, or a few notes that fit several places: when they fit where the
  // music is about as well, the singer is here (a steady singer was "lost" about once a minute without this)
  const gap = engine.playing && res[0] ? swmHereGap(notes, res[0], loc.q, 60 / (state.tempo * engine.rate), now) : Infinity;
  if (!d) {
    // not sure where you are, but sure it is not where the music is (both places you might be are
    // elsewhere): stop and listen, as a pianist who has lost the singer
    const b = res[0];
    if (!(engine.playing && b && b.score < SURE.fit && gap > HERE)) swm.away = null;
    else {
      const ok = (x) => x > 0.15 && x < 2.5;
      const spq = ok(b.spqNow) ? b.spqNow : 60 / state.tempo;
      const off = (at) => Math.abs(at + (now - b.sungFrom) / spq - loc.q);
      const places = b.placeGap < SURE.margin && b.otherAt !== null ? [b.at, b.otherAt] : [b.at];
      const far = places.every((at) => off(at) > 3);
      // twice running (as for joining): one odd check is not a lost singer
      const again = swm.away && now - swm.away.t < 4;
      swm.away = far ? { t: now } : null;
      if (far && again) {
        swm.away = null;
        engine.pause();
        swm.lost = true;
        swmSay("Finding where you are… sing on");
      }
    }
    return;
  }
  const ok = (x) => x > 0.15 && x < 2.5;
  const spq = ok(d.spqNow) ? d.spqNow : ok(d.spq) ? d.spq : 60 / state.tempo;
  const youNow = d.at + (now - d.sungFrom) / spq; // quarters
  const musicNow = loc.q;
  if (!swm.lost && (Math.abs(youNow - musicNow) < 2 || gap <= HERE)) { swm.away = null; return; } // with you (the following keeps it so), or these notes fit where the music is as well
  if (!swm.lost) {
    // twice running, the same place both times, before the music leaves where it is
    const a = swm.away, again = a && now - a.t < 4 && (a.you === undefined || Math.abs(a.you + (now - a.t) / spq - youNow) < 2);
    swm.away = { t: now, you: youNow };
    if (!again) return;
  }
  swm.away = null;
  // back at the start after the end of a verse: the next verse
  let k = loc.kind === "verse" ? loc.pass : Math.max(0, perf.passes.findIndex((x) => x.kind === "verse"));
  if (youNow < musicNow - hymn.totalQ / 2) {
    const next = perf.passes.findIndex((x, i) => i > k && x.kind === "verse");
    if (next >= 0) k = next;
  }
  swm.voice = swm.hymnIdx.tunes[d.tune].ids[0];
  engine.setRate(1);
  swmGo(d.at, d.sungFrom, spq, k);
  swm.joinedAt = now;
  if (swm.lost) { swm.lost = false; swmSay(`${hymn.number} ${hymn.title}: ${swm.do === "piano" ? "playing" : "singing"} with you`); }
}

function setupSingWithMe() {
  const dlg = $("swmDialog");
  let choice = { do: store.get("swmDo", "piano"), find: store.get("swmFind", false) };
  const show = () => {
    dlg.querySelectorAll("[data-swm-do]").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.swmDo === choice.do)));
    dlg.querySelectorAll("[data-swm-find]").forEach((b) => b.setAttribute("aria-pressed", String((b.dataset.swmFind === "1") === choice.find)));
    $("swmThis").textContent = hymn ? `${hymn.number} ${hymn.title}: start anywhere in it, any part` : "Start anywhere in it, any part";
  };
  dlg.querySelectorAll("[data-swm-do]").forEach((b) => { b.onclick = () => { choice.do = b.dataset.swmDo; show(); }; });
  dlg.querySelectorAll("[data-swm-find]").forEach((b) => { b.onclick = () => { choice.find = b.dataset.swmFind === "1"; show(); }; });
  $("swmBtn").onclick = () => { if (swm.on) { swmStop(); return; } show(); dlg.showModal(); };
  $("swmCancel").onclick = () => dlg.close();
  $("swmStart").onclick = () => {
    store.set("swmDo", choice.do); store.set("swmFind", choice.find);
    dlg.close();
    swmStart(choice);
  };
  $("swmStop").onclick = () => swmStop();
}

// ---- follow my tempo ----------------------------------------------------------
const follower = new TempoFollower();
function resetFollower() {
  const v = swm.on ? swm.voice : state.singVoice;
  follower.reset((perf?.events || []).filter((e) => e.ch === v && !e.stem && e.p > 0).map((e) => ({ t: e.t, dur: e.dur, p: e.p })));
}
async function startListening() {
  engine.ensure();
  listener = listener || new PitchListener();
  try {
    await engine.ctx.resume(); // the audio engine sleeps until something wakes it
    await listener.start(engine.ctx);
  } catch {
    toast("The microphone is not available. Allow it for this page and try again.", 6000);
    return;
  }
  $("micBtn").textContent = "Stop listening";
  trace = [];
  applyMix();

  toast(state.muteMine ? `Listening. Your part (${VOICES[state.singVoice].name}) is muted so you can sing it.` : "Listening.", 4000);
}

function stopListening() {
  if (!listener?.on) return;
  listener.stop();
  $("micBtn").textContent = "Start listening";
  $("pitchReadout").textContent = "Not listening";
  applyMix();

}

function tap() {
  const pad = $("tapPad");
  pad.classList.add("hit");
  setTimeout(() => pad.classList.remove("hit"), 120);
  let grid = null;
  let t = null;
  if (quiz && quiz.engine.playing) {
    t = quiz.engine.now();
    grid = quiz.beats;
  } else if (engine.playing) {
    t = engine.now();
    grid = perf.beats;
  }
  if (!grid) { $("tapFeedback").textContent = "Press play first, then tap on every beat."; return; }
  const near = grid.reduce((a, b) => (Math.abs(b.t - t) < Math.abs(a.t - t) ? b : a));
  const ms = Math.round((t - near.t) * 1000);
  taps = [...taps.slice(-7), Math.abs(ms)];
  const avg = Math.round(taps.reduce((a, b) => a + b, 0) / taps.length);
  const when = Math.abs(ms) <= 40 ? "Right on the beat" : ms > 0 ? `${ms} ms late` : `${-ms} ms early`;
  const which = quiz && quiz.engine.playing && !quiz.answered ? "" : near.beat === 0 ? " That was beat 1, the strong beat." : ` That was beat ${near.beat + 1}.`;
  $("tapFeedback").textContent = `${when}.${which} Average over your last ${taps.length}: ${avg} ms.`;
}

async function playQuiz() {
  if (engine.playing) { engine.pause(); setPlaying(false); }
  // until it is answered, the button plays the same tune again
  if (quiz && !quiz.answered) { quiz.engine.stop(); quiz.engine.play(0); return; }
  quiz?.engine.stop();
  const tune = mysteryTune();
  const qe = new Engine();
  qe.ensure();
  await qe.loadPiano();
  qe.load(tune.events);
  quiz = { tune, engine: qe, answered: false, beats: Array.from({ length: Math.round(tune.length / tune.beatSec) }, (_, i) => ({ t: i * tune.beatSec, beat: i % tune.beats })) };
  $("quizChoices").querySelectorAll("button").forEach((b) => b.classList.remove("right", "wrong"));
  $("quizFeedback").textContent = "Listen for the strong beat, then choose. You can tap along to help.";
  workspace.classList.add("quiz-hidden"); // no peeking at the score
  $("quizPlay").textContent = "Play it again";
  qe.play(0);
}

function answerQuiz(btn) {
  if (!quiz || quiz.answered) return;
  quiz.answered = true;
  workspace.classList.remove("quiz-hidden");
  const right = `${quiz.tune.time[0]}/${quiz.tune.time[1]}`;
  quizScore.asked++;
  if (btn.dataset.time === right) quizScore.right++;
  $("quizChoices").querySelectorAll("button").forEach((b) => {
    if (b.dataset.time === right) b.classList.add("right");
    else if (b === btn) b.classList.add("wrong");
  });
  $("quizFeedback").textContent = `${btn.dataset.time === right ? "Yes!" : `It was ${right}.`} ${meterHint(quiz.tune.time)} Score: ${quizScore.right} of ${quizScore.asked}.`;
  $("quizPlay").textContent = "New tune";
}

// tAt: draw the moment at that performance time instead of the playing one (frames of a video made offline)
/** How many times a hymn has played to its end (AHStudio.state().ends). */
let playEnds = 0;
/** The hymn has played to its end: stop, and count it. Checked on every frame, and also each time the app
 *  asks for state(): with the screen locked no frames are drawn, and the app's queue waited for the screen. */
function endIfDone() {
  if (!perf || !hymn || !engine.playing || engine.loop || engine.now() < perf.total) return false;
  engine.stop();
  setPlaying(false);
  playEnds++; // the app's playlists move on to the next hymn when this counts up
  if (recording) setTimeout(finishRecording, 1200);
  return true;
}
function paint(force, tAt) {
  if (!perf || !hymn) return;
  const t = tAt ?? engine.now();
  if (tAt === undefined) endIfDone();
  const moving = engine.playing || force || Math.abs(t - lastT) > 1e-3;
  if (!moving && !stageWanted()) return;
  lastT = t;
  // once the introduction has played, nothing is lit until the singing starts (the count-in, if any, runs then):
  // a lit note would look like the place to start singing
  const at = locate(perf, t);
  const loc = at?.done ? null : at;
  if (state.words === "current" && state.view !== "words" && !unfolded() && loc && loc.verse !== renderedVerse) {
    if (state.view !== "presenter") { renderAll(); return; }
    // the presenter only needs its score again, with this verse's words
    renderedVerse = loc.verse;
    prepareStage().then(() => paint(true));
  }
  if (currentShift(loc) !== renderedShift) { renderAll(); return; } // the key changed here
  const refrainQ = hymn.marks.find((m) => /refrain|chorus/i.test(m.text))?.q ?? Infinity;
  const q = loc ? loc.q : null;
  const sung = loc && loc.kind === "verse";
  const verseN = !sung ? -1 : state.words === "solfa" ? 0 : q >= refrainQ || state.words === "current" || unfolded() ? 1 : loc.verse;
  const sq = scoreQ(loc); // the position in the score as drawn (written out or stacked)
  const copy = unfolded() && loc ? verseOrdinal(loc) ?? 0 : 0;
  const ci = loc ? chordIndexAt(hymn, q) : -1;

  if (!loc) $("where").textContent = engine.playing ? "Counting in" : "Ready";
  else {
    const part = loc.kind === "intro" ? "Introduction" : loc.kind === "interlude" ? "Interlude" : q >= refrainQ ? "Refrain" : `Verse ${loc.verse}`;
    $("where").textContent = `${part}, bar ${barAt(hymn, q)} of ${hymn.measures}`;
  }
  const lines = currentLines(loc);
  updateNowbar(loc, ci, lines);

  if (stageWanted()) {
    presenter.draw({
      hymn, q: sq, verseN, tracks: visibleTracks(), colors, t, heard, mode: state.presenterShows, watermark: state.watermark,
      format: state.format, badge: state.format === "vertical" ? hymnBadge() : null,
      only: loc?.kind === "intro" && state.introVoice ? [state.introVoice] : null,
      verseLabel: !loc ? `Verse ${state.verses[0]}` : loc.kind === "intro" ? "Introduction" : loc.kind === "interlude" ? "Interlude" : q >= refrainQ ? `Refrain, verse ${loc.verse}` : `Verse ${loc.verse}`,
      chord: state.chords && ci >= 0 ? chordLabel(hymn.chords[ci].name) : null,
      nextChord: state.chords && hymn.chords[ci + 1] ? chordLabel(hymn.chords[ci + 1].name) : null,
      line: lines.now, nextLine: lines.nextText, stanza: lines.stanza, stanzaAt: lines.at, piano: state.piano ? waterfall : null,
      loop: state.loop.on ? { from: state.loop.from + copy * hymn.measures, to: state.loop.to + copy * hymn.measures } : null,
    });
    mirrorProjector();
    if (state.view === "presenter") return;
  }
  if (state.view === "solfa" || state.view === "words") {
    const alt = state.view === "solfa" ? solfa : words;
    if (!loc) {
      alt.clear();
      // nothing sounding (stopped, counting in, or between the introduction and verse 1): show the line
      // where the singing starts, whole, not the half-peeled line the introduction ended on
      if (solfaSweeping()) { const at = comingUp(t); const k = at ? sfLineAt(at.q) : 0; if (k >= 0 && k !== sfSweep.i) solfaSweepTo(k, null); }
    }
    else {
      const el = state.view === "solfa" ? solfa.highlight(q, sung ? (q >= refrainQ ? (hymn.refrains?.[loc.verse - 1] ? 1000 + loc.verse : 0) : loc.verse) : -2) : words.highlight(q, sung ? loc.verse : -2, q >= refrainQ);
      alt.markChord(ci, hymn);
      const target = state.view === "solfa" ? el : el?.closest(".w-line");
      if (solfaSweeping()) {
        const cell = [...solfa.active][0]?.el;
        const li = cell ? solfa.lines.findIndex((l) => l.el.contains(cell)) : -1;
        const brief = li !== sfSweep.i && sfSweep.i >= 0 && engine.playing && loc.kind !== "verse" && briefVisit(t, li, (a) => sfLineAt(a.q));
        if (li >= 0 && !brief) solfaSweepTo(li, cell);
      } else if (engine.playing && target && target !== lastFollowEl) {
        lastFollowEl = target;
        target.scrollIntoView({ block: "center", inline: "center", behavior: reduceMotion ? "auto" : "smooth" });
      }
    }
    if (state.piano) drawPianoPanel(t);
    return;
  }

  if (!loc || sq === null) {
    view.clear();
    // stopped (or counting in): keep the playhead at the start, so it can be dragged
    const start = !engine.playing && !loc ? view.playhead(0) : null;
    if (start) placeRibbon(start);
    else ribbon.hidden = true;
    if (sweeping()) {
      // as the sol-fa: the line where the singing starts, whole
      const at = start ? null : comingUp(t);
      const p0 = start || (at && view.playhead(scoreQ(at))) || view.playhead(0);
      if (p0 && view.systems.indexOf(p0.system) !== sweep.i) sweepTo(p0, false);
    }
  } else {
    view.highlight(sq, verseN);
    const cj = ci + copy * hymn.chords.length;
    view.markChord(cj);
    $("lane").querySelectorAll(".blk").forEach((b, i) => b.classList.toggle("sounding", i === cj));
    const ph = view.playhead(sq);
    if (ph) {
      placeRibbon(ph);
      follow(ph);
    }
  }
  if (state.piano) drawPianoPanel(t);
}

function placeRibbon(ph) {
  ribbon.hidden = false;
  ribbon.style.left = `${ph.x}px`;
  ribbon.style.top = `${ph.top - 8}px`;
  ribbon.style.height = `${ph.height + 16}px`;
}

// Drag the playhead to where playing should continue. While playing, it pauses during the
// drag and carries on from the new place when released.
let ribbonDrag = null;
ribbon.addEventListener("pointerdown", (e) => {
  if (e.button !== 0) return;
  e.preventDefault();
  e.stopPropagation(); // not a loop selection
  ribbon.setPointerCapture(e.pointerId);
  ribbonDrag = { wasPlaying: engine.playing };
  if (engine.playing) { engine.pause(); setPlaying(false); }
  ribbon.classList.add("dragging");
});
ribbon.addEventListener("pointermove", (e) => {
  if (!ribbonDrag) return;
  const r = $("score").getBoundingClientRect();
  engine.pausedAt = timeOfScoreQ(view.qAt(e.clientX - r.left, e.clientY - r.top));
  paint(true);
});
ribbon.addEventListener("pointerup", () => {
  if (!ribbonDrag) return;
  const resume = ribbonDrag.wasPlaying;
  ribbonDrag = null;
  ribbon.classList.remove("dragging");
  if (resume) togglePlay();
  else toast(`Playing will start from ${$("where").textContent.toLowerCase()}.`, 2500);
});

// page view: when not playing, the headers stay beside the line at the top of the window as the page scrolls
window.addEventListener("scroll", () => {
  if (engine.playing || state.view !== "page" || !view.systems?.length) return;
  const toolbar = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--toolbar-h")) || 52;
  const y = window.scrollY + toolbar - (sheet.getBoundingClientRect().top + window.scrollY);
  const sys = view.systems.filter((s) => s.box.y + s.box.h * 0.5 > y)[0] || view.systems.at(-1);
  if (sys.el === lastSystem) return;
  lastSystem = sys.el;
  positionHeaders(sys);
}, { passive: true });

function follow(ph) {
  if (state.view === "tracks") {
    if (engine.playing) viewport.scrollLeft = ph.x - viewport.clientWidth * 0.33;
    return;
  }
  if (sweeping()) {
    const k = view.systems.indexOf(ph.system);
    const t = engine.now();
    const at = locate(perf, t);
    // an introduction or interlude touching a line for a moment does not turn the page
    if (k !== sweep.i && sweep.i >= 0 && engine.playing && at?.kind !== "verse" && briefVisit(t, k, systemOf)) return;
    sweepTo(ph);
    if (engine.playing) keepInSight(viewport, ph.x);
    return;
  }
  if (engine.playing) keepInSight(viewport, ph.x);
  if (ph.system.el !== lastSystem) {
    lastSystem = ph.system.el;
    positionHeaders(ph.system);
    if (engine.playing) {
      const top = viewport.getBoundingClientRect().top + window.scrollY + ph.top;
      window.scrollTo({ top: top - window.innerHeight * 0.2, behavior: reduceMotion ? "auto" : "smooth" });
    }
  }
}

// ---- line by line (?app, the staff view) ----------------------------------------------------------
// One line of the score at a time, as the presenter shows it: once three quarters of the line is
// sung, the next line is uncovered behind the playhead, from barline to barline, so when the eye
// goes back to the left the next line is already there.
const SWEEP_PAD = 14;
const SWEEP_TOP = 2; // above a line: nothing of the line before it (its last words) shows
const APP_ZOOM = 0.5; // the app's staff: the smallest the pinch allows, so the whole page width shows
// In the app the lines are always those of the smallest size; pinched bigger, the page is wider than
// the screen and scrolls sideways (it is not laid out again into shorter lines).
const appWide = (z) => (APP ? Math.max(1, z / APP_ZOOM) : 1);
/** Keep x (content px of a sideways-scrolling box) in sight: from the left third onwards. */
function keepInSight(box, x) {
  if (box.scrollWidth <= box.clientWidth + 4) return;
  if (x < box.scrollLeft + 16 || x > box.scrollLeft + box.clientWidth * 0.8) box.scrollLeft = Math.max(0, x - box.clientWidth * 0.33);
}
const sweep = { el: null, inner: null, i: -1, x: 0, next: undefined, head: 0, foot: 0 };
// Every line is placed by its top staff line, all at the same height (room above it for the line with
// the most above its staff: high notes, stems, a tempo mark), so the staff doesn't jump up or down from
// one line to the next, nor between the line being sung and the next one under it (Brian, 4 Nov 2026).
const staffTop = (s) => s.staves[0]?.top ?? s.box.y;
const sweepShift = (s) => SWEEP_TOP + sweep.head - staffTop(s);
// only that line shows: nothing of the line above or below it
const sweepClip = (s, side = 0) => `inset(${Math.floor(s.box.y - 1)}px ${side}px calc(100% - ${Math.ceil(s.box.y + s.box.h + SWEEP_PAD)}px) ${side}px)`;
const sweeping = () => state.sweep && state.view === "page" && !!view?.systems?.length;

function clearSweep() {
  viewport.classList.remove("sweeping");
  viewport.style.height = "";
  sheet.style.transform = "";
  sheet.style.clipPath = "";
  if (sweep.el) sweep.el.hidden = true;
  sweep.i = -1;
  sweep.next = undefined;
}

function setupSweep() {
  if (!sweeping()) return;
  if (!sweep.el) {
    sweep.el = document.createElement("div");
    sweep.el.className = "sweep-next";
    sweep.el.setAttribute("aria-hidden", "true");
    viewport.append(sweep.el);
  }
  // a copy of the score, unlit, from which the next line is shown
  sweep.el.innerHTML = `<div class="score">${$("score").innerHTML}</div>`;
  sweep.inner = sweep.el.firstChild;
  sweep.el.hidden = true;
  sweep.next = undefined;
  sweep.head = Math.max(...view.systems.map((s) => staffTop(s) - s.box.y));
  sweep.foot = Math.max(...view.systems.map((s) => s.box.y + s.box.h - staffTop(s)));
  const h = SWEEP_TOP + sweep.head + sweep.foot + SWEEP_PAD;
  viewport.classList.add("sweeping");
  viewport.style.height = `${Math.ceil(h)}px`;
  sweep.el.style.left = `${sheet.offsetLeft}px`;
  sweep.el.style.width = `${sheet.offsetWidth}px`;
  sweep.el.style.height = `${Math.ceil(h)}px`;
  sweep.i = -1;
}

// The line that will really be sung after line i: not always the one below it (verse 2 goes back to
// the top, a refrain or a repeat jumps). Found by looking ahead in the performance from now.
const systemOf = (at) => { const p = view.playhead(scoreQ(at)); return p ? view.systems.indexOf(p.system) : -1; };
function upcomingSystem(i) { return lineAfter(engine.now(), i, systemOf); }

function sweepTo(ph, wipe = true) {
  const sys = ph.system;
  const i = view.systems.indexOf(sys);
  if (i !== sweep.i) {
    sweep.i = i;
    sweep.x = 0;
    sweep.next = undefined;
    lastSystem = sys.el;
    sheet.style.transform = `translateY(${sweepShift(sys)}px)`;
    sheet.style.clipPath = sweepClip(sys, -50);
    if (engine.playing) viewport.scrollLeft = 0;
    sweep.el.hidden = true;
  }
  const a = sys.anchors;
  if (!a.length || !wipe || !engine.playing) { sweep.el.hidden = true; return; }
  // peeled in two steps, not continuously: at three quarters of the line, its first half; at nine
  // tenths, up to three quarters; the rest when the singing goes back to the left. Each edge is the
  // barline at or before that point.
  if (ph.x < (sweep.lastX ?? 0) - 30) { sweep.x = 0; sweep.next = undefined; sweep.el.hidden = true; } // went back on this line
  sweep.lastX = ph.x;
  const end = a[a.length - 1].x;
  const at = (ph.x - a[0].x) / Math.max(1, end - a[0].x);
  if (at < 0.75) return;
  if (sweep.next === undefined) {
    // decided once per line, at three quarters: it then never changes its mind
    sweep.next = upcomingSystem(i);
  }
  const next = view.systems[sweep.next];
  if (!next) { sweep.el.hidden = true; return; }
  const upTo = sys.box.x + sys.box.w * (at >= 0.9 ? 0.75 : 0.5);
  const ends = (el) => view.measures.filter((m) => m.system === el).map((m) => m.box.x + m.box.w);
  const mine = ends(sys.el).filter((x) => x <= upTo + 1);
  const edge = mine.length ? Math.max(...mine) : upTo;
  peel(sweep, edge);
  sweep.inner.style.transform = `translateY(${sweepShift(next)}px)`;
  sweep.inner.style.clipPath = sweepClip(next, -50);
}

/** The line being sung lies on top of the next one; behind the singer it is peeled away in steps.
 *  The edge only ever moves right. */
function peel(sw, edge) {
  // the line being sung is gone left of `edge` (a barline of its own); the next line lies whole beneath
  // it and shows right up to the edge, as a map's top layer dragged away shows the one under it: no
  // plain paper between the two (Brian, 4 Nov 2026)
  sw.x = Math.max(sw.x, edge);
  if (sw.x < 2) { sw.el.hidden = true; return; }
  sw.el.hidden = false;
  sw.el.style.setProperty("--edge", `${sw.x}px`);
  sw.el.style.clipPath = `inset(0 calc(100% - ${sw.x}px) 0 0)`;
  sw.el.style.maskImage = "";
  sw.el.style.webkitMaskImage = "";
}

/** The line the music goes to after line `from`, from time t: lineOf(at) gives a position's line. A line
 *  only touched for a moment (an introduction running a few notes over into it) is passed over. */
const BRIEF = 1.5; // seconds
function lineAfter(t, from, lineOf) {
  let cand = -1, since = 0, away = false;
  for (let dt = 0.1; t + dt < perf.total && dt < 60; dt += 0.1) {
    const at = locate(perf, t + dt);
    const k = at && !at.done ? lineOf(at) : -1;
    if (k === -1) away = true;
    // back on this same line after a break (the introduction done, verse 1 starts here): the page
    // starts over, there is no other line to uncover
    if (k === from && away) return -1;
    if (cand >= 0) {
      if (k === cand) { if (dt - since >= BRIEF) return cand; continue; }
      if (k === -1 && dt - since < BRIEF) continue; // silence: decide by what follows
      cand = -1;
      away = true;
    }
    if (k >= 0 && k !== from) { cand = k; since = dt; }
  }
  return cand;
}

/** True when the music is in line k only for a moment from time t (and is not singing there). */
function briefVisit(t, k, lineOf) {
  for (let dt = 0; dt < BRIEF; dt += 0.1) {
    const at = locate(perf, t + dt);
    if (!at || at.done || lineOf(at) !== k) return true;
  }
  return false;
}

/** Where the music next sounds after time t (within ten seconds), or null. */
function comingUp(t) {
  if (!perf) return null;
  for (let dt = 0.1; dt < 10 && t + dt < perf.total; dt += 0.1) {
    const at = locate(perf, t + dt);
    if (at && !at.done) return at;
  }
  return null;
}

// ---- sol-fa line by line (?app) -----------------------------------------------------------------
// As the staff: one line of sol-fa at a time; once most of it is sung, the line that really comes next
// (looked up in the performance) is uncovered behind the singer, bar by bar, from the left.
const sfSweep = { el: null, inner: null, i: -1, x: 0, next: undefined };
const solfaSweeping = () => state.solfaSweep && state.view === "solfa" && !!solfa?.lines?.length;
const SF_PAD = 10;

function setupSolfaSweep() {
  const alt = $("altView");
  alt.classList.remove("sf-sweeping");
  alt.style.height = "";
  sfSweep.i = -1;
  sfSweep.next = undefined;
  sfSweep.el = null;
  if (!solfaSweeping()) return;
  const flow = alt.querySelector(".sf-flow");
  alt.classList.add("sf-sweeping");
  sfSweep.el = document.createElement("div");
  sfSweep.el.className = "sf-next";
  sfSweep.el.setAttribute("aria-hidden", "true");
  sfSweep.el.hidden = true;
  sfSweep.inner = flow.cloneNode(true);
  sfSweep.el.append(sfSweep.inner);
  sfSweep.el.style.left = `${flow.offsetLeft}px`;
  sfSweep.el.style.width = `${flow.offsetWidth}px`;
  alt.append(sfSweep.el);
}

function sfLineAt(q) {
  const bar = solfa.bars?.find((b) => Number(b.dataset.bar) === barAt(hymn, q));
  return bar ? solfa.lines.findIndex((l) => l.el.contains(bar)) : -1;
}

function solfaSweepTo(li, cell) {
  const alt = $("altView");
  const flow = alt.querySelector(".sf-flow");
  const lines = solfa.lines;
  const line = lines[li];
  if (!flow || !line || !sfSweep.el) return;
  const top = (k) => lines[k].el.offsetTop - lines[0].el.offsetTop; // the flow may or may not be the offset parent
  const tall = (k) => (lines[k] ? lines[k].el.offsetHeight : 0);
  const fit = (k) => { alt.style.height = `${Math.ceil(flow.offsetTop + SF_PAD * 2 + Math.max(tall(li), tall(k)))}px`; };
  if (li !== sfSweep.i) {
    sfSweep.i = li;
    sfSweep.x = 0;
    sfSweep.next = undefined;
    sfSweep.el.hidden = true;
    flow.style.transform = `translateY(${SF_PAD - top(li)}px)`;
    alt.scrollLeft = 0;
    fit(li);
  }
  if (!cell || !engine.playing) { sfSweep.el.hidden = true; return; }
  // the column of the note being sung (its words start there too): the peel stops at its left edge
  const beat = cell.closest(".sf-beat") || cell;
  const bar = cell.closest(".sf-bar");
  const x = bar.offsetLeft + beat.offsetLeft;
  if (engine.playing) {
    const r = cell.getBoundingClientRect(), A = alt.getBoundingClientRect();
    if (alt.scrollWidth > alt.clientWidth + 4 && (r.right > A.right - 24 || r.left < A.left)) cell.scrollIntoView({ inline: "center", block: "nearest" });
  }
  const W = line.el.offsetWidth;
  if (x < (sfSweep.lastX ?? 0) - 30) { sfSweep.x = 0; sfSweep.next = undefined; sfSweep.el.hidden = true; } // went back on this line
  sfSweep.lastX = x;
  if (x < W * 0.75) return; // peeled in two steps, as the staff
  if (sfSweep.next === undefined) {
    // decided once per line, at three quarters, and never changed: the line the performance goes to next
    sfSweep.next = lineAfter(engine.now(), li, (a) => sfLineAt(a.q));
    if (sfSweep.next >= 0) fit(sfSweep.next);
  }
  const next = lines[sfSweep.next];
  if (!next) { sfSweep.el.hidden = true; return; }
  sfSweep.el.style.top = `${flow.offsetTop}px`;
  sfSweep.el.style.height = alt.style.height;
  sfSweep.inner.style.transform = `translateY(${SF_PAD - top(sfSweep.next)}px)`;
  const upTo = W * (x >= W * 0.9 ? 0.75 : 0.5);
  const ends = (l) => l.bars.map((b) => b.offsetLeft + b.offsetWidth);
  const mine = ends(line).filter((e) => e <= upTo + 1);
  const edge = mine.length ? Math.max(...mine) : upTo;
  peel(sfSweep, edge);
}

// ---- pinch to zoom (?app) ------------------------------------------------------------------------
// Two fingers make the score (staff), or the sol-fa and words, larger or smaller. While pinching the
// view is only stretched; on letting go it is laid out again at the new size.
function setupPinch() {
  let p = null;
  const dist = (t) => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  const target = () => (isScoreView() ? sheet : state.view === "solfa" || state.view === "words" ? $("altView") : null);
  workspace.addEventListener("touchstart", (e) => {
    if (e.touches.length !== 2) return;
    drag = null; // two fingers: neither a loop nor a tap on a note
    const el = target();
    if (!el) return;
    const r = el.getBoundingClientRect();
    const altKey = state.view === "solfa" ? "solfaZoom" : "altZoom";
    const z = el === sheet ? 1 : state[altKey]; // CSS zoom scales the box, not the transform origin
    const mx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
    const my = (e.touches[0].clientY + e.touches[1].clientY) / 2;
    p = { el, d: dist(e.touches), k: 1, base: el.style.transform || "" };
    el.style.transition = "none";
    el.style.transformOrigin = `${(mx - r.left) / z}px ${(my - r.top) / z}px`;
  }, { passive: true });
  workspace.addEventListener("touchmove", (e) => {
    if (!p || e.touches.length !== 2) return;
    e.preventDefault();
    const now = p.el === sheet ? state.zoom : state[state.view === "solfa" ? "solfaZoom" : "altZoom"];
    p.k = Math.max(0.5 / now, Math.min(2.5 / now, dist(e.touches) / p.d));
    p.el.style.transform = `${p.base} scale(${p.k})`;
  }, { passive: false });
  const end = (e) => {
    if (!p || e.touches.length >= 2) return;
    const { el, k, base } = p;
    p = null;
    el.style.transform = base;
    el.style.transformOrigin = "";
    el.style.transition = "";
    if (Math.abs(k - 1) < 0.04) return;
    if (el === sheet) { state.zoom = Math.max(0.5, Math.min(2.5, state.zoom * k)); save("zoom"); renderAll(); }
    else {
      const key = state.view === "solfa" ? "solfaZoom" : "altZoom";
      state[key] = Math.max(0.5, Math.min(2.5, state[key] * k)); save(key); el.style.zoom = String(state[key]);
      if (state.view === "solfa") renderAll(); // the lines are laid out again for the new size
    }
  };
  workspace.addEventListener("touchend", end);
  workspace.addEventListener("touchcancel", end);
}

// ---- piano roll sheet ----------------------------------------------------------------------------
// Docked above the words bar. Its handle opens and closes it (click, Enter or Space) and resizes it (drag).
function setPianoOpen(open) {
  const p = $("pianoPanel");
  p.classList.toggle("open", open);
  $("pianoHandle").setAttribute("aria-expanded", String(open));
  store.set("pianoOpen", open);
  paint(true);
}

function setupPianoSheet() {
  const p = $("pianoPanel");
  p.classList.toggle("open", store.get("pianoOpen", false)); // starts as just its bar
  const h = $("pianoHandle");
  h.setAttribute("aria-expanded", String(p.classList.contains("open")));
  // a plain button: click opens or closes it; it gives focus back so Space stays play/pause
  h.onclick = () => { setPianoOpen(!p.classList.contains("open")); h.blur(); };
}

// ---- tooltips ------------------------------------------------------------------------------------
// One tooltip for every button with data-tip or title: shown straight away, kept inside the window.
function setupTooltips() {
  const tip = $("tip");
  let cur = null;
  const hide = () => { tip.hidden = true; cur = null; };
  const show = (el) => {
    if (el.title) { el.dataset.tip = el.title; el.removeAttribute("title"); } // no second, slow native tooltip
    const text = el.dataset.tip;
    if (!text) return hide();
    cur = el;
    tip.textContent = text;
    tip.hidden = false;
    const r = el.getBoundingClientRect();
    const tw = tip.offsetWidth, th = tip.offsetHeight;
    let x = r.left + r.width / 2 - tw / 2;
    x = Math.max(6, Math.min(window.innerWidth - tw - 6, x));
    let y = r.bottom + 7;
    if (y + th > window.innerHeight - 6) y = r.top - th - 7; // no room below: show it above
    tip.style.left = `${x}px`;
    tip.style.top = `${y}px`;
  };
  document.addEventListener("pointerover", (e) => {
    if (e.pointerType === "touch") return;
    const el = e.target.closest?.("[data-tip], [title]");
    if (el && el !== cur && !el.closest(".score")) show(el);
    else if (!el) hide();
  });
  document.addEventListener("focusin", (e) => { const el = e.target.closest?.("[data-tip], [title]"); if (el && e.target.matches(":focus-visible")) show(el); });
  document.addEventListener("focusout", hide);
  document.addEventListener("pointerdown", hide);
  window.addEventListener("scroll", hide, true);
}

function drawPianoPanel(t) {
  const c = $("pianoCanvas");
  const w = c.clientWidth;
  const h = c.clientHeight;
  const dpr = window.devicePixelRatio || 1;
  if (!w || !h) return; // closed: nothing to draw
  if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) { c.width = Math.round(w * dpr); c.height = Math.round(h * dpr); }
  const g = c.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  waterfall.draw(g, 0, 0, w, h, t, colors, heard);
}

// words of one pass: the verse, then the refrain, split into sung lines
function passSyllables(verse) { return [...(hymn.verses[verse - 1] || []), ...(hymn.refrains?.[verse - 1] || hymn.refrain || [])]; }

function splitLines(syl) {
  const out = [[]];
  syl.forEach((s, i) => {
    out[out.length - 1].push(i);
    if (s && (s.s === "single" || s.s === "end") && /[,;:.!?]$/.test(s.t)) out.push([]);
  });
  return out.filter((l) => l.length);
}

function lineParts(syl, idxs, current) {
  return idxs.map((i) => {
    const s = syl[i];
    if (!s) return { text: "", sung: false }; // a melisma note
    const join = s.s === "begin" || s.s === "middle" ? "" : " ";
    return { text: s.t + join, sung: i === current };
  });
}

function currentLines(loc) {
  if (loc && loc.kind !== "verse") {
    const label = loc.kind === "intro" ? "Introduction" : "Interlude";
    const next = loc.kind === "intro" ? loc.verse : state.verses[state.verses.indexOf(loc.verse) + 1];
    const syl = passSyllables(next ?? loc.verse);
    const first = splitLines(syl)[0] || [];
    const nextText = lineParts(syl, first, -1).map((p) => p.text).join("");
    const stanza = splitLines(syl).map((l) => lineParts(syl, l, -1)); // the stanza to come, none of it lit yet
    return { now: [{ text: label, sung: false }], next: [], nextText: `Next: ${nextText}`, key: `${loc.pass}:inst`, stanza, at: -1 };
  }
  const verse = loc ? loc.verse : state.verses[0];
  const syl = passSyllables(verse);
  const ls = splitLines(syl);
  let si = -1;
  if (loc) {
    const lv = hymn.voices[hymn.lyricVoice];
    si = lv.findIndex((n) => n.q <= loc.q + 1e-6 && loc.q < n.q + n.d - 1e-6);
    while (si > 0 && !syl[si]) si--; // a melisma keeps its syllable lit
  }
  const li = Math.max(0, ls.findIndex((l) => l.includes(si)));
  const now = ls[li] ? lineParts(syl, ls[li], si) : [];
  const next = ls[li + 1] ? lineParts(syl, ls[li + 1], -1) : [];
  const stanza = ls.map((l, i) => lineParts(syl, l, i === li ? si : -1));
  return { now, next, nextText: next.map((p) => p.text).join(""), key: `${loc?.pass}:${si}:${verse}`, stanza, at: loc ? li : -1 };
}

function updateNowbar(loc, ci, lines) {
  $("chordNow").textContent = state.chords ? chordLabel(hymn.chords[Math.max(0, ci)]?.name || "") : "";
  $("chordNext").textContent = state.chords && hymn.chords[ci + 1] ? `Next: ${chordLabel(hymn.chords[ci + 1].name)}` : "";
  if (lines.key === lastLineKey) return;
  lastLineKey = lines.key;
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;");
  document.documentElement.style.setProperty("--hl", `var(--${hymn.lyricVoice})`);
  $("lineNow").innerHTML = lines.now.map((p) => (p.sung ? `<span class="sung">${esc(p.text.trimEnd())}</span>${p.text.endsWith(" ") ? " " : ""}` : esc(p.text))).join("");
  $("lineNext").textContent = lines.nextText;
}

// ---- studio, recording, export, import ---------------------------------------

function openStudio() {
  const members = [...visibleVoices().map((k) => ({ ch: k, name: VOICES[k].name, color: `var(--${k})`, kind: "singer" })),
    { ch: "acc", name: "Accompaniment", color: "var(--acc)", kind: "piano" }];
  const defaults = Object.fromEntries(CH.map((c) => [c, DEFAULT_MIX[c]]));
  studio.open(members, { level: state.levels, pan: state.pans }, (ch, level, pan) => {
    state.levels[ch] = level;
    state.pans[ch] = pan;
    save("levels", "pans");
    applyMix();
    const r = headersEl.querySelector(`input[type=range][data-ch="${ch}"]`);
    if (r) r.value = level;
  }, defaults);
}

// Record button: a dialog first, so the video's content is chosen, then recording starts
function openRecordDialog() {
  if (recording) { finishRecording(); return; }
  const d = $("recDialog");
  const chips = (box, items, isOn) => {
    $(box).innerHTML = items.map(([v, l]) => `<label><input type="checkbox" value="${v}" ${isOn(v) ? "checked" : ""}>${l}</label>`).join("");
  };
  chips("recVerses", hymn.verses.map((_, i) => [i + 1, String(i + 1)]), (v) => state.verses.includes(Number(v)));
  chips("recVoices", hymnVoices().map((k) => [k, VOICES[k].name]), (k) => !state.mute[k]);
  $("recShows").value = state.presenterShows;
  $("recAccomp").innerHTML = Object.entries(ACCOMP_STYLES).map(([v, l]) => `<option value="${v}">${l}</option>`).join("");
  $("recAccomp").value = state.accomp;
  for (const [id, key] of [["recIntro", "intro"], ["recInterlude", "interlude"]]) {
    $(id).innerHTML = Object.entries(INSTRUMENTAL).map(([v, l]) => `<option value="${v}">${l}</option>`).join("");
    $(id).value = state[key];
  }
  $("recCountIn").value = state.countIn ? state.countAt : "off";
  // one video of the choir, and/or one per voice (each voice alone, its introduction playing its own line)
  chips("recTakes", [["choir", "Choir"], ...hymnVoices().map((k) => [k, VOICES[k].name])], (v) => v === "choir");
  const summary = () => {
    const vs = [...$("recVerses").querySelectorAll("input:checked")].map((x) => x.value);
    const voices = [...$("recVoices").querySelectorAll("input:checked")].map((x) => VOICES[x.value].name);
    const takes = [...$("recTakes").querySelectorAll("input:checked")].length;
    $("recSummary").textContent = `${hymn.number} ${hymn.title}: verse${vs.length === 1 ? "" : "s"} ${vs.join(", ") || "none"}; `
      + `${voices.length ? voices.join(", ") : "no voices"}; at ${state.tempo} a minute; `
      + `${takes === 1 ? "one mp4" : `${takes} mp4s`}.`;
  };
  d.querySelectorAll("input, select").forEach((el) => { el.onchange = summary; });
  summary();
  $("recCancel").onclick = () => d.close();
  $("recStart").onclick = async () => {
    const vs = [...$("recVerses").querySelectorAll("input:checked")].map((x) => Number(x.value));
    if (!vs.length) return toast("Choose at least one verse.");
    const on = new Set([...$("recVoices").querySelectorAll("input:checked")].map((x) => x.value));
    state.verses = vs; store.set(`verses:${hymn.id}`, vs);
    for (const k of hymnVoices()) state.mute[k] = !on.has(k);
    state.presenterShows = $("recShows").value;
    state.accomp = $("recAccomp").value;
    state.intro = $("recIntro").value;
    state.interlude = $("recInterlude").value;
    state.countIn = $("recCountIn").value !== "off";
    if (state.countIn) state.countAt = $("recCountIn").value;
    const takes = [...$("recTakes").querySelectorAll("input:checked")].map((x) => x.value);
    if (!takes.length) return toast("Choose at least one video.");
    save("mute", "presenterShows", "accomp", "intro", "interlude", "countIn", "countAt");
    // keep the rest of the page in step with what was chosen
    $("presenterShows").value = state.presenterShows; $("intro").value = state.intro; $("interlude").value = state.interlude;
    $("countIn").checked = state.countIn; $("countAt").value = state.countAt; buildVerseChips();
    d.close();
    if (state.accomp !== "off" || state.intro !== "none" || state.interlude !== "none") await engine.loadPiano();
    if (anySung()) await prepareStems(); else rebuild();
    buildHeaders();
    applyMix();
    if (canMakeVideo()) await makeTakeVideos(takes);
    else await startRecording(); // an older browser: film the stage live
  };
  d.showModal();
}

// Every video is made ahead of time (see videomaker.js): smooth whatever the browser is doing, and the
// takes after the first reuse the frames after the introduction.
async function makeTakeVideos(takeKeys) {
  if (state.view !== "presenter") { state.view = "presenter"; save("view"); await renderAll(); }
  stopPlayback();
  engine.ensure();
  await engine.loadPiano();
  const loopWas = state.loop.on;
  if (loopWas) setLoop(state.loop.from, state.loop.to, false);
  const choir = hymnVoices().filter((k) => !state.mute[k]);
  making = true;
  state.watermark = true;
  const takes = takeKeys.map((key) => ({
    name: key === "choir" ? "Choir" : VOICES[key].name,
    setup: async () => {
      state.introVoice = key === "choir" ? null : key;
      rebuild(false);
      await prepareStage();
      const voices = key === "choir" ? choir : [key];
      for (const k of hymnVoices()) engine.setMuted(k, !voices.includes(k));
      // the takes differ only up to the first verse (the count-in after an introduction is the same in all)
      const intro = perf.passes[0]?.kind === "intro";
      const firstVerse = perf.passes.find((p) => p.kind === "verse");
      const splitT = !intro ? 0 : firstVerse.t0 - (state.countIn && state.countAt === "verse" ? countQ(hymn) * perf.tm.spq : 0);
      return { total: perf.total + 1, splitT };
    },
    drawAt: (t) => paint(true, t),
    audio: () => engine.renderOffline(perf.events, perf.total + 1.5),
  }));
  const made = [];
  try {
    await makeVideos($("stage"), takes, {
      progress: (text) => toast(text, 0),
      onVideo: async (name, blob, audioCodec) => {
        // Opus sound in an mp4 does not play everywhere: the server makes it AAC when it can (the app has no server)
        if (audioCodec !== "aac" && !APP) {
          try {
            const r = await fetch("api/to-mp4", { method: "POST", body: blob });
            if (r.ok) blob = new Blob([await r.arrayBuffer()], { type: "video/mp4" });
          } catch { /* no server: keep it as it is */ }
        }
        made.push({ file: `${hymn.id}-${name}.mp4`, blob });
      },
    });
    $("toast").hidden = true;
    if (APP) saveInApp(made); // the app keeps them with the phone's videos at once, and offers to share
    else showMadeVideos(made);
  } catch (err) {
    toast(`The video could not be made: ${err.message}`, 8000);
  } finally {
    making = false;
    state.introVoice = null;
    state.watermark = false;
    rebuild(false);
    applyMix();
    if (loopWas) setLoop(state.loop.from, state.loop.to, true);
    paint(true);
  }
}

// In the app: each video goes straight to the phone (Movies/Advent Hymnals); the app copies it out of the page
// and says when it is saved (then offers to share it). Its progress shows here while it copies.
function saveInApp(made) {
  for (const v of made) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(v.blob);
    a.download = v.file;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 10 * 60000);
  }
  toast(made.length === 1 ? "Saving the video to your phone…" : `Saving ${made.length} videos to your phone…`, 0);
}
// the app's copy reports how far it is (StudioSaver)
window.addEventListener("ah-save-progress", (e) => {
  const { done, total, name } = e.detail || {};
  if (!total) return;
  if (done >= total) { $("toast").hidden = true; return; }
  toast(`Saving ${name || "the video"} to your phone… ${Math.round((done / total) * 100)}%`, 0);
});

// Finished videos are kept until the user saves them: nothing says "saved" before a file is really written.
function showMadeVideos(made) {
  const d = $("vidDialog");
  const picker = "showSaveFilePicker" in window;
  $("vidTitle").textContent = made.length === 1 ? "Your video is ready" : `Your ${made.length} videos are ready`;
  $("vidNote").textContent = made.length === 1 ? "It is not saved yet. Choose where to keep it." : "They are not saved yet. Choose where to keep each one.";
  const mb = (b) => `${(b.size / 1e6).toFixed(1)} MB`;
  $("vidList").innerHTML = made.map((v, i) => `<li><span class="vname">${v.file}</span><span class="vsize">${mb(v.blob)}</span>`
    + `<button class="play-text" data-save="${i}">Save…</button></li>`).join("");
  const done = (i, where) => {
    const li = $("vidList").children[i];
    li.querySelector("[data-save]").replaceWith(Object.assign(document.createElement("span"), { className: "saved", textContent: where }));
  };
  const saveOne = async (i) => {
    const v = made[i];
    if (picker) {
      try {
        const fh = await window.showSaveFilePicker({ suggestedName: v.file, types: [{ description: "MP4 video", accept: { "video/mp4": [".mp4"] } }] });
        const w = await fh.createWritable();
        await w.write(v.blob);
        await w.close();
        done(i, `Saved as ${fh.name}`);
      } catch (err) { if (err.name !== "AbortError") toast(`Could not save it: ${err.message}`, 6000); }
      return;
    }
    // no save picker in this browser: it downloads, and the browser decides where (usually Downloads)
    const a = document.createElement("a");
    a.href = URL.createObjectURL(v.blob);
    a.download = v.file;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
    done(i, "Sent to your browser's downloads");
  };
  $("vidList").querySelectorAll("[data-save]").forEach((b) => { b.onclick = () => saveOne(Number(b.dataset.save)); });
  $("vidSaveAll").hidden = made.length < 2 || !("showDirectoryPicker" in window);
  $("vidSaveAll").onclick = async () => {
    try {
      const dir = await window.showDirectoryPicker({ mode: "readwrite" });
      for (const [i, v] of made.entries()) {
        const w = await (await dir.getFileHandle(v.file, { create: true })).createWritable();
        await w.write(v.blob);
        await w.close();
        if ($("vidList").children[i].querySelector("[data-save]")) done(i, `Saved in ${dir.name}`);
      }
    } catch (err) { if (err.name !== "AbortError") toast(`Could not save them: ${err.message}`, 6000); }
  };
  $("vidClose").onclick = () => {
    const unsaved = $("vidList").querySelectorAll("[data-save]").length;
    if (unsaved && !confirm(`${unsaved === 1 ? "A video is" : `${unsaved} videos are`} not saved and will be lost. Close anyway?`)) return;
    d.close();
  };
  d.oncancel = (e) => { e.preventDefault(); $("vidClose").onclick(); }; // Escape asks too
  d.showModal();
}

async function startRecording() {
  if (recording) { finishRecording(); return; }
  if (state.view !== "presenter") { state.view = "presenter"; save("view"); await renderAll(); }
  engine.ensure();
  applyMix();
  await engine.loadPiano();
  stopPlayback();
  const loopWas = state.loop.on;
  if (loopWas) setLoop(state.loop.from, state.loop.to, false);
  state.watermark = true;
  const rec = presenter.record(engine.recordStream(), async (blob) => {
    // a webm recording is turned into a standard mp4 by the server when it can (players, phones, social sites)
    if (!blob.type.includes("avc1") && !blob.type.includes("mp4")) {
      toast("Making the video into an mp4…", 0);
      try {
        const r = await fetch("api/to-mp4", { method: "POST", body: blob });
        if (r.ok) blob = new Blob([await r.arrayBuffer()], { type: "video/mp4" });
      } catch { /* no server: keep the webm */ }
    }
    const ext = blob.type.includes("mp4") ? "mp4" : "webm";
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${hymn.id}-${visibleTracks().map(trackKey).join("-")}.${ext}`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 60000);
    toast(`Video saved as ${a.download}`);
  });
  recording = { rec, loopWas };
  $("recordBtn").classList.add("recording");
  $("recordBtn").setAttribute("aria-label", "Stop recording");
  $("recordBtn").querySelector("span").textContent = "Stop recording and save the video";
  document.querySelector("#moreMenu > summary").classList.add("recording");
  toast("Recording. It stops by itself at the end of the last verse.", 3000);
  await engine.play(0);
  setPlaying(true);
}

function finishRecording() {
  if (!recording) return;
  const r = recording;
  recording = null;
  state.watermark = false;
  r.rec.stop();
  $("recordBtn").classList.remove("recording");
  $("recordBtn").setAttribute("aria-label", "Record a video");
  $("recordBtn").querySelector("span").textContent = "Record the presenter to a video";
  document.querySelector("#moreMenu > summary").classList.remove("recording");
  if (r.loopWas) setLoop(state.loop.from, state.loop.to, true);
}

async function doExport() {
  if (!hymn) return;
  try { await ensureVerovio(); } catch { toast("The score engine could not load. Check the internet connection."); return; }
  const tracks = visibleTracks();
  const name = `${hymn.id}-${tracks.map(trackKey).join("-")}.pdf`;
  toast("Making the PDF…", 0);
  try {
    const opts = withPiano(xmlOptions({ header: true, words: state.words === "current" ? "all" : state.words }));
    const pages = await exportPdf(tk, buildMusicXML(scoreHymn(), opts), hymn, name, $("measureHost"), verovioTranspose(currentShift(null)));
    toast(`Saved ${name} (${pages} ${pages === 1 ? "page" : "pages"})`);
  } catch (err) {
    toast(`The PDF could not be made: ${err.message}`);
  }
  presenter.key = ""; // the toolkit now holds the PDF layout
}

async function doImport(file) {
  toast(`Reading ${file.name}…`, 0);
  let res;
  try {
    res = await fetch(`api/import?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file, headers: { "Content-Type": file.type || "application/pdf" } });
  } catch {
    toast("Import needs the hymn server. Start it with python3 server.py in the hymn-satb folder.");
    return;
  }
  if (res.status === 404 || res.status === 501) { toast("Import needs the hymn server. Start it with python3 server.py in the hymn-satb folder."); return; }
  const job = await res.json().catch(() => ({}));
  if (!res.ok) { toast(job.error || "The import could not start.", 9000); return; }
  for (;;) {
    await new Promise((r) => setTimeout(r, 2000));
    const s = await (await fetch(`api/import/${job.id}`)).json();
    if (s.status === "done") {
      await loadList();
      $("hymnPicker").value = s.hymn;
      location.hash = s.hymn;
      await loadHymn(hymnList.find((x) => x.id === s.hymn));
      toast(`Imported ${s.title}. Check it against the scan before relying on it.`, 8000);
      return;
    }
    if (s.status === "error") { toast(`Import failed: ${s.error}`, 9000); return; }
    toast(s.message || "Transcribing…", 0);
  }
}

/** Turn a recording (audio or video) into a hymn, on the local server. */
async function doImportAudio(file) {
  toast(`Sending ${file.name}…`, 0);
  let res;
  try {
    res = await fetch(`api/import-audio?name=${encodeURIComponent(file.name)}`, { method: "POST", body: file });
  } catch {
    toast("Importing a recording needs the hymn server on this computer (python3 server.py).", 7000);
    return;
  }
  if (res.status === 404 || res.status === 405 || res.status === 501) { toast("Importing a recording needs the hymn server on this computer (python3 server.py).", 7000); return; }
  const job = await res.json().catch(() => ({}));
  if (!res.ok) { toast(job.error || "The recording could not be sent.", 8000); return; }
  for (;;) {
    await new Promise((r) => setTimeout(r, 4000));
    let s;
    try { s = await (await fetch(`api/import-audio/${job.id}`)).json(); } catch { continue; }
    if (s.status === "done") {
      await loadList();
      $("hymnPicker").value = s.hymn;
      location.hash = s.hymn;
      await loadHymn(hymnList.find((x) => x.id === s.hymn));
      toast("Transcribed. Listen and compare with the recording; expect to correct some notes and words.", 9000);
      return;
    }
    if (s.status === "error") { toast(`The recording could not be transcribed: ${s.error}`, 10000); return; }
    toast(s.message || "Transcribing the recording…", 0);
  }
}

// ---- automatic videos (?make=) -------------------------------------------------------------------
// The social pipeline (social/post.py) loads e.g. ?make=choir,alto,rehearsal&format=landscape#SDAH-610 in a
// headless browser. The page makes those videos with no dialog and POSTs each one, with a sidecar JSON (and
// thumbnails, with thumb=1), to server.py, which keeps them in out/videos/<id>/. window.AH_MAKE and a console
// line ("AH-MAKE DONE <id>" or "AH-MAKE ERROR <id> <message>") say how it went. The URL's settings are used for
// this page only and never saved, so the same URL always makes the same videos. The spec is
// social/SPEC-player.md.

const HYMNAL_NAMES = { SDAH: "SDA Hymnal", CS1900: "Christ in Song", CS1908: "Christ in Song", HT1876: "Hymns and Tunes", CH1941: "Church Hymnal 1941", NZK: "Nyimbo za Kristo", WN: "Wende Nyasaye", AHC: "Advent Hymnals Collection" };
const hymnBadge = () => `${HYMNAL_NAMES[hymn.book] || hymn.book} ${hymn.number}`;
const LOGO = "brand/logo.svg"; // the one place the logo comes from
const END_VOICE = "audio/endcard/cta.wav"; // spoken: "Which hymn should we sing next? Tell us in the comments."
const END_CARD = {
  landscape: { secs: 10, voiceAt: 0.8, lines: ["Which hymn should we sing next?", "Tell us in the comments", "Learn your part · player.adventhymnals.org"] },
  vertical: { secs: 4, voiceAt: 0.4, lines: ["Full hymn ▶ on our channel", "Which hymn next? Comment below"] },
};
const SHORT_MAX = 58; // seconds: one file fits YouTube Shorts, Reels and TikTok
const MAKE_TAKES = ["choir", "soprano", "alto", "tenor", "bass", "rehearsal", "short"];
const voiceOfTake = (take) => Object.keys(VOICES).find((k) => VOICES[k].name.toLowerCase() === take);
const takeLabel = (take) => (take === "choir" ? "SATB Choir" : take === "rehearsal" ? "All Parts Rehearsal" : `${VOICES[voiceOfTake(take)]?.name} Part`);
const refrainAt = () => hymn.marks.find((m) => /refrain|chorus/i.test(m.text))?.q ?? null;

function makeFailed(id, message) {
  window.AH_MAKE = { ...(window.AH_MAKE || { files: [] }), state: "error", error: message };
  console.log(`AH-MAKE ERROR ${id} ${message}`);
}

/** A performance like rebuild()'s, for one section of an automatic video. */
const perfFor = (verses, introVoice, extra = {}) => performance(hymn, {
  tempo: state.tempo, verses, accomp: state.accomp, countIn: state.countIn, countAt: state.countAt, introVoice,
  stems: anySung() ? stemInfo : new Map(), intro: state.intro, interlude: state.interlude, shiftAt, metronome: false, ...extra,
});

// A take is a timeline of parts, each { kind: "music" | "card" | "end", t0, dur }. A music part plays a
// performance from its time `from` with some `voices`, and its sound rings `ring` seconds into the next part.
function useMusic(it) {
  perf = it.perf;
  state.verses = it.verses;
  state.introVoice = it.introVoice;
}

function drawTimeline(tl, t) {
  const it = tl.items.findLast((x) => t >= x.t0 - 1e-9) ?? tl.items[0];
  const k = t - it.t0;
  const mark = (dark, cornerOnly = false) => (state.format === "vertical" ? presenter.drawVerticalMark(dark ? "#ffffff" : colors.cloth, cornerOnly)
    : presenter.drawMark({ watermark: true, colors, mode: dark ? "words" : "score" }, cornerOnly));
  if (it.kind === "music") { useMusic(it); paint(true, it.from + k); return; }
  if (it.kind === "card") {
    presenter.drawTitleCard({ hymn, colors, title: it.title, voice: it.voice, badge: hymnBadge() });
    mark(false);
    return;
  }
  if (!tl.last) { // the end card fades in over the last picture of the music
    const m = tl.items.findLast((x) => x.kind === "music");
    useMusic(m);
    paint(true, m.from + m.dur);
    tl.last = Object.assign(document.createElement("canvas"), { width: $("stage").width, height: $("stage").height });
    tl.last.getContext("2d").drawImage($("stage"), 0, 0);
  }
  presenter.drawEndCard({ k, last: tl.last, logo: makeAssets.logo, lines: END_CARD[state.format].lines });
  mark(true, true); // the card is all brand already: no diagonal across the call to action
}

/** The sound of a take: each music part rendered offline and laid in place, then the spoken end card,
 *  matched to the singing's loudness. */
async function timelineAudio(tl) {
  const rate = 48000;
  const out = new AudioBuffer({ numberOfChannels: 2, length: Math.ceil(tl.total * rate), sampleRate: rate });
  for (const it of tl.items.filter((x) => x.kind === "music")) {
    for (const k of hymnVoices()) engine.setMuted(k, !it.voices.includes(k));
    const len = Math.min(it.dur + it.ring, tl.total - it.t0);
    const buf = await engine.renderOffline(it.perf.events, it.from + len + 0.05, rate);
    const fadeIn = it.from > 0 ? 0.08 * rate : 0; // a clip from the middle of a hymn starts softly
    const fadeOut = (it.ring > 0.5 ? 0.6 : 0.25) * rate;
    const n = Math.round(len * rate);
    const at = Math.round(it.t0 * rate);
    const from = Math.round(it.from * rate);
    for (let c = 0; c < 2; c++) {
      const src = buf.getChannelData(Math.min(c, buf.numberOfChannels - 1));
      const dst = out.getChannelData(c);
      for (let i = 0; i < n && at + i < dst.length && from + i < src.length; i++) {
        const gain = Math.min(1, fadeIn ? i / fadeIn : 1, (n - i) / fadeOut);
        dst[at + i] += src[from + i] * gain;
      }
    }
  }
  const end = tl.items.find((x) => x.kind === "end");
  const voice = makeAssets.voice;
  if (end && voice) {
    // as loud as the singing: the RMS of the sounding samples of each
    const rms = (chs, a, b) => {
      let sum = 0;
      let count = 0;
      for (const d of chs) for (let i = a; i < b; i++) if (Math.abs(d[i]) > 0.003) { sum += d[i] * d[i]; count++; }
      return count ? Math.sqrt(sum / count) : 0;
    };
    const outCh = [out.getChannelData(0), out.getChannelData(1)];
    const vCh = [voice.getChannelData(0), voice.getChannelData(voice.numberOfChannels > 1 ? 1 : 0)];
    const music = rms(outCh, 0, Math.round(end.t0 * rate));
    const spoken = rms(vCh, 0, voice.length);
    let peak = 0;
    for (const d of vCh) for (const x of d) peak = Math.max(peak, Math.abs(x));
    const gain = Math.min(music && spoken ? music / spoken : 1, peak ? 0.89 / peak : 1);
    const at = Math.round((end.t0 + END_CARD[state.format].voiceAt) * rate);
    for (let c = 0; c < 2; c++) {
      for (let i = 0; i < voice.length && at + i < out.length; i++) outCh[c][at + i] += vCh[c][i] * gain;
    }
  }
  return out;
}

/** YouTube chapters: the first at 0, each at least 10 s long, at least 3 of them (else none). */
function tidyChapters(list, total) {
  const out = [];
  for (const c of [...list].sort((a, b) => a.t - b.t)) {
    const ch = { ...c };
    while (out.length && ch.t - out.at(-1).t < 10) out.pop(); // the short one before joins the one before it
    if (!out.length) ch.t = 0;
    out.push(ch);
  }
  while (out.length > 1 && total - out.at(-1).t < 10) out.pop();
  return out.length >= 3 ? out.map((c) => ({ t: Math.round(c.t * 10) / 10, label: c.label })) : [];
}

/** One chapter per verse and refrain of a performance that starts at `offset` in the video. */
function chaptersOf(p, offset = 0) {
  const rq = refrainAt();
  const out = [];
  p.passes.forEach((pass, k) => {
    if (pass.kind === "intro") out.push({ t: offset + pass.t0, label: "Introduction" });
    if (pass.kind !== "verse") return;
    out.push({ t: offset + pass.t0, label: `Verse ${pass.verse}` });
    if (rq !== null) out.push({ t: offset + passTime(p, k, rq), label: "Refrain" });
  });
  return out;
}

/** The whole hymn sung by `voices` (the choir, or one voice), then the end card. */
function songTimeline(verses, voices, introVoice, endcard) {
  const p = perfFor(verses, introVoice);
  const items = [{ kind: "music", t0: 0, dur: endcard ? p.total : p.total + 1, from: 0, perf: p, verses, voices, introVoice, ring: endcard ? 1.2 : 0 }];
  let total = items[0].dur;
  if (endcard) { items.push({ kind: "end", t0: total, dur: END_CARD[state.format].secs }); total += END_CARD[state.format].secs; }
  // every take shares the frames after its introduction (see videomaker.js)
  const intro = p.passes[0]?.kind === "intro";
  const firstVerse = p.passes.find((x) => x.kind === "verse");
  const splitT = !intro ? 0 : firstVerse.t0 - (state.countIn && state.countAt === "verse" ? countQ(hymn) * p.tm.spq : 0);
  return { items, total, splitT, chapters: tidyChapters(chaptersOf(p), total), verses };
}

/** Soprano, alto, tenor and bass each alone (partVerses), then the choir (verses), each after a 2 s card. */
function rehearsalTimeline(verses, partVerses, choir, endcard) {
  const sections = [
    ...hymnVoices().map((k) => ({ title: `${VOICES[k].name} part`, chapter: VOICES[k].name, voices: [k], introVoice: k, verses: partVerses, voice: k })),
    { title: "Choir", chapter: "Choir", voices: choir, introVoice: null, verses, voice: null },
  ];
  const items = [];
  const chapters = [];
  let t = 0;
  sections.forEach((s, i) => {
    chapters.push({ t, label: s.chapter });
    items.push({ kind: "card", t0: t, dur: 2, title: s.title, voice: s.voice });
    t += 2;
    const p = perfFor(s.verses, s.introVoice);
    const last = i === sections.length - 1;
    const dur = last && endcard ? p.total : p.total + 1;
    items.push({ kind: "music", t0: t, dur, from: 0, perf: p, verses: s.verses, voices: s.voices, introVoice: s.introVoice, ring: last && endcard ? 1.2 : 0 });
    t += dur;
  });
  if (endcard) { items.push({ kind: "end", t0: t, dur: END_CARD[state.format].secs }); t += END_CARD[state.format].secs; }
  return { items, total: t, splitT: t, chapters: tidyChapters(chapters, t), verses };
}

/** What clip=fit (the default) means for this hymn: the last verse with its refrain when the whole short
 *  stays within 58 s, else the refrain alone, or verse 1 when there is no refrain. */
function resolveClip(clip, endcard) {
  if (clip && clip !== "fit") return clip;
  const last = hymn.verses.length;
  const p = perfFor([last], null, { countIn: false, intro: "none", interlude: "none" });
  const card = endcard ? END_CARD.vertical.secs : 0;
  if (p.total + card + 0.5 <= SHORT_MAX) return `whole:${last}`;
  return refrainAt() !== null ? "refrain" : "verse:1";
}

/** The short: one refrain, verse or stretch (clip=refrain | verse:N | whole:N, a verse with its refrain |
 *  q:FROM-TO), singing from the first moment, then the 4 s end card; at most 58 s, cut at the end of a
 *  phrase when it would be longer. */
function shortTimeline(spec, choir, endcard) {
  const rq = refrainAt();
  let verse = 1;
  let qFrom = 0;
  let qTo = hymn.totalQ;
  let label;
  if (spec === "refrain") {
    if (rq === null) throw new Error("this hymn has no refrain; use clip=verse:N");
    [qFrom, label] = [rq, "Refrain"];
  } else if (/^verse:\d+$/.test(spec)) {
    verse = Number(spec.split(":")[1]);
    if (!hymn.verses[verse - 1]) throw new Error(`there is no verse ${verse}`);
    if (rq !== null) qTo = rq;
    label = `Verse ${verse}`;
  } else if (/^whole:\d+$/.test(spec)) {
    verse = Number(spec.split(":")[1]);
    if (!hymn.verses[verse - 1]) throw new Error(`there is no verse ${verse}`);
    label = rq !== null ? `Verse ${verse} and refrain` : `Verse ${verse}`;
  } else if (/^q:[\d.]+-[\d.]+$/.test(spec)) {
    [qFrom, qTo] = spec.slice(2).split("-").map(Number);
    if (!(qFrom < qTo && qTo <= hymn.totalQ)) throw new Error(`clip ${spec} is not inside the hymn`);
    label = "Excerpt";
  } else throw new Error(`clip ${spec} is not fit, refrain, verse:N or q:FROM-TO`);
  const p = perfFor([verse], null, { countIn: false, intro: "none", interlude: "none" });
  const card = endcard ? END_CARD.vertical.secs : 0;
  const fromS = Math.max(0, passTime(p, 0, qFrom) - 0.1);
  let toS = passTime(p, 0, qTo);
  const room = SHORT_MAX - card - 0.5;
  if (toS - fromS > room) { // too long: end where a phrase does, the latest that fits
    const ends = phraseBounds(hymn).filter((q) => q > qFrom && passTime(p, 0, q) - fromS <= room);
    qTo = ends.at(-1) ?? qFrom;
    toS = qTo > qFrom ? passTime(p, 0, qTo) : fromS + room;
  }
  const ends = qTo >= hymn.totalQ - 1e-6; // the hymn's own last chord may ring; elsewhere the next words must not
  const items = [{ kind: "music", t0: 0, dur: toS - fromS + (card ? 0 : 1), from: fromS, perf: p, verses: [verse], voices: choir, introVoice: null, ring: card ? (ends ? 1.2 : 0.25) : 0 }];
  let total = items[0].dur;
  if (card) { items.push({ kind: "end", t0: total, dur: card }); total += card; }
  return { items, total, splitT: total, chapters: [], verses: [verse], clip: { label, fromS: Math.round(fromS * 1000) / 1000, toS: Math.round(toS * 1000) / 1000 } };
}

const makeAssets = { logo: null, voice: null };

async function loadMakeAssets() {
  // the logo, rasterised large so it stays sharp at any size it is drawn
  try {
    const svg = (await (await fetch(LOGO)).text()).replace("<svg ", '<svg width="800" height="800" ');
    const img = new Image();
    img.src = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
    await img.decode();
    makeAssets.logo = img;
  } catch { /* no logo: the cards are drawn without it */ }
  try {
    const r = await fetch(`${AUDIO}${END_VOICE}`, { cache: "no-cache" });
    if (r.ok) makeAssets.voice = await new OfflineAudioContext(2, 1, 48000).decodeAudioData(await r.arrayBuffer());
  } catch { /* no voice yet: the end card is silent */ }
  for (const f of ["800 54px Alegreya", "700 46px Alegreya", "600 34px Alegreya", "500 52px Alegreya", "400 34px Alegreya",
    "italic 400 30px Alegreya", "600 30px 'Alegreya Sans'", "700 40px 'Alegreya Sans'", "500 36px 'Alegreya Sans'", "800 58px 'Alegreya Sans'"]) {
    await document.fonts.load(f).catch(() => {});
  }
}

/** The hymn's first line as people know it: the first phrases of verse 1, up to four words at least. */
function firstLine() {
  const syl = passSyllables(1);
  let text = "";
  for (const line of splitLines(syl)) {
    text += lineParts(syl, line, -1).map((x) => x.text).join("");
    if (text.trim().split(/\s+/).length >= 4) break;
  }
  return text.trim().replace(/[,;:.!?]+$/, "");
}

function stemsVersion() {
  if (!manifest) return null;
  if (manifest.version) return String(manifest.version);
  let h = 0x811c9dc5; // FNV-1a of the manifest: any new recording changes it
  for (const ch of JSON.stringify(manifest)) { h ^= ch.charCodeAt(0); h = Math.imul(h, 0x01000193) >>> 0; }
  return h.toString(16).padStart(8, "0");
}

async function postFile(name, blob, reencode = false) {
  const r = await fetch(`api/video?id=${encodeURIComponent(hymn.id)}&name=${encodeURIComponent(name)}${reencode ? "&reencode=1" : ""}`, { method: "POST", body: blob });
  if (!r.ok) throw new Error(`server.py did not keep ${name}: ${(await r.json().catch(() => ({}))).error || r.status}`);
  window.AH_MAKE.files.push(name);
}

async function runMake() {
  const id = hymn?.id || decodeURIComponent(location.hash.slice(1));
  window.AH_MAKE = { state: "working", files: [], error: null, progress: "" };
  const p = MAKE;
  const stage = $("stage");
  try {
    if (!hymn) throw new Error("the hymn did not load");
    if (!canMakeVideo()) throw new Error("this browser cannot encode video (WebCodecs)");
    const format = p.get("format") || "landscape";
    if (!["landscape", "vertical"].includes(format)) throw new Error(`format ${format} is not landscape or vertical`);
    const wanted = p.get("make").split(",").map((x) => x.trim()).filter(Boolean);
    const bad = wanted.filter((x) => !MAKE_TAKES.includes(x));
    if (bad.length) throw new Error(`unknown take ${bad.join(", ")}`);
    if (wanted.includes("short") && format !== "vertical") throw new Error("short needs format=vertical");
    const missingVoice = wanted.filter((x) => voiceOfTake(x) && !hymnVoices().includes(voiceOfTake(x)));
    if (missingVoice.length) throw new Error(`this hymn has no ${missingVoice.join(", ")} part`);
    const all = hymn.verses.map((_, i) => i + 1);
    const verseList = (v, name) => {
      if (!v || v === "all") return all;
      const list = v.split(",").map(Number);
      if (!list.length || list.some((n) => !all.includes(n))) throw new Error(`${name}=${v}: the hymn has verses ${all.join(", ")}`);
      return list;
    };
    const verses = verseList(p.get("verses"), "verses");
    const partVerses = verseList(p.get("partVerses") || "1", "partVerses");
    const endcard = p.get("endcard") !== "off";
    const short = wanted.includes("short");
    let clip = null;

    // the settings: the URL's, else the hymn's own, else the defaults of a fresh profile
    const pick = (name, ok, fallback) => {
      const v = p.get(name);
      if (v === null) return fallback;
      if (!ok(v)) throw new Error(`${name}=${v} is not allowed`);
      return v;
    };
    state.format = format;
    state.tempo = Number(pick("tempo", (v) => Number(v) >= 30 && Number(v) <= 240, hymn.tempo));
    state.accomp = pick("accomp", (v) => v in ACCOMP_STYLES, state.accomp);
    state.intro = short ? "none" : pick("intro", (v) => v in INSTRUMENTAL, "none");
    state.interlude = pick("interlude", (v) => v in INSTRUMENTAL, state.interlude);
    const countIn = short ? "off" : pick("countIn", (v) => ["start", "verse", "off"].includes(v), "start");
    state.countIn = countIn !== "off";
    if (state.countIn) state.countAt = countIn;
    state.presenterShows = pick("shows", (v) => ["score", "words", "stanza"].includes(v), format === "vertical" ? "words" : "score");
    state.mute = {};
    state.solo = {};
    state.transpose = 0;
    state.lastVerseUp = 0;
    state.view = "presenter";

    window.AH_MAKE.progress = "Loading the singers";
    await loadMakeAssets();
    engine.ensure();
    await engine.loadPiano();
    if (short) clip = resolveClip(p.get("clip"), endcard);
    const sungVerses = short ? [shortVerse(clip)] : [...new Set([...verses, ...(wanted.includes("rehearsal") ? partVerses : [])])].sort((a, b) => a - b);
    state.verses = sungVerses;
    if (!manifest) throw new Error("this hymn has no sung recording yet");
    await prepareStems();
    const missing = sungVerses.flatMap((v) => hymnVoices().filter((k) => !stemInfo.has(`${k}:${v}:0`)).map((k) => `${k}${v}`));
    if (missing.length) throw new Error(`sung stems missing at ${state.tempo} a minute: ${missing.join(" ")}`);
    if (format === "vertical") { stage.width = 1080; stage.height = 1920; }
    await renderAll();
    await prepareStage();
    applyMix();

    const choir = hymnVoices();
    const plan = [];
    for (const take of wanted) {
      if (take === "choir") plan.push({ take, tl: songTimeline(verses, choir, null, endcard) });
      else if (take === "rehearsal") plan.push({ take, tl: rehearsalTimeline(verses, partVerses, choir, endcard) });
      else if (take === "short") plan.push({ take, tl: shortTimeline(clip, choir, endcard) });
      else { const k = voiceOfTake(take); plan.push({ take, tl: songTimeline(verses, [k], k, endcard) }); }
    }
    // the takes that share frames first, the rest after (each of those is drawn whole)
    plan.sort((a, b) => (a.tl.splitT >= a.tl.total) - (b.tl.splitT >= b.tl.total));
    making = true;
    state.watermark = true;
    let said = 0;
    await makeVideos(stage, plan.map(({ take, tl }) => ({
      name: take,
      setup: async () => { useMusic(tl.items.find((x) => x.kind === "music")); return { total: tl.total, splitT: tl.splitT }; },
      drawAt: (t) => drawTimeline(tl, t),
      audio: () => timelineAudio(tl),
    })), {
      progress: (text) => {
        window.AH_MAKE.progress = text;
        if (Date.now() - said > 15000) { said = Date.now(); console.log(`AH-MAKE PROGRESS ${id} ${text}`); }
      },
      onVideo: async (take, blob, audioCodec, videoCodec) => {
        const { tl } = plan.find((x) => x.take === take);
        const name = `${hymn.id}-${take}-${format}`;
        // VP9 or Opus inside (a browser without H.264/AAC encoders): the server makes it H.264/AAC
        await postFile(`${name}.mp4`, blob, audioCodec !== "aac" || videoCodec !== "avc");
        const end = tl.items.find((x) => x.kind === "end");
        const meta = {
          hymnId: hymn.id, book: hymn.book, number: hymn.number, title: hymn.title, firstLine: firstLine(),
          poet: hymn.poet || "", composer: hymn.composer || "", copyright: hymn.copyright || "",
          take, format, verses: tl.verses, durationS: Math.round(tl.total * 100) / 100, chapters: tl.chapters,
          clip: tl.clip || null, endcard: end ? { startS: Math.round(end.t0 * 100) / 100 } : null,
          player: null, stems: stemsVersion(), // server.py fills in the player's git commit
          tempo: state.tempo, accomp: state.accomp, intro: state.intro, countIn,
          ...(take === "rehearsal" ? { partVerses } : {}),
        };
        await postFile(`${name}.json`, new Blob([JSON.stringify(meta)], { type: "application/json" }));
        console.log(`AH-MAKE FILE ${id} ${name}.mp4`);
      },
    });
    if (p.get("thumb") === "1") {
      for (const take of wanted.filter((x) => x !== "short")) {
        const c = document.createElement("canvas");
        const k = voiceOfTake(take) || null;
        presenter.drawThumb(c, { hymn, colors, badge: hymnBadge(), label: takeLabel(take), voice: k, logo: makeAssets.logo });
        await postFile(`${hymn.id}-${take}-thumb.png`, await new Promise((r) => c.toBlob(r, "image/png")));
      }
    }
    window.AH_MAKE.state = "done";
    window.AH_MAKE.progress = "";
    console.log(`AH-MAKE DONE ${id}`);
  } catch (err) {
    makeFailed(id, err?.message || String(err));
  } finally {
    making = false;
    state.watermark = false;
  }
}

/** The verse a short's clip comes from. */
function shortVerse(clip) {
  return /^(verse|whole):\d+$/.test(clip) ? Number(clip.split(":")[1]) : 1;
}

// ---- controls ------------------------------------------------------------

function bindControls() {
  $("playBtn").onclick = togglePlay;
  $("stopBtn").onclick = stopPlayback;
  document.addEventListener("keydown", (e) => {
    if (e.code !== "Space" || e.target.closest("input, select, textarea, button, summary, dialog")) return;
    e.preventDefault();
    togglePlay();
  });
  $("tempo").oninput = (e) => { $("tempoLabel").textContent = `${e.target.value} a minute`; };
  $("tempo").onchange = (e) => setTempo(Number(e.target.value));

  $("loopBtn").onclick = () => setLoop(state.loop.from, state.loop.to, !state.loop.on);
  $("keyDown").onclick = () => changeKey(-1);
  $("keyUp").onclick = () => changeKey(1);
  $("keyLabel").onclick = resetKey;
  $("lastVerseUp").value = String(state.lastVerseUp);
  $("lastVerseUp").onchange = (e) => { state.lastVerseUp = Number(e.target.value); save("lastVerseUp"); if (anySung()) prepareStems(); else rebuild(); };
  const loopInput = () => setLoop(Number($("loopFrom").value) || 1, Number($("loopTo").value) || 1, state.loop.on);
  $("loopFrom").onchange = loopInput;
  $("loopTo").onchange = loopInput;

  document.querySelectorAll(".views .seg").forEach((b) => {
    b.onclick = () => { if (state.view === b.dataset.view) return; state.view = b.dataset.view; save("view"); renderAll(); };
  });
  const toggle = (id, key, after) => {
    const b = $(id);
    b.setAttribute("aria-pressed", String(state[key]));
    b.onclick = () => { state[key] = !state[key]; b.setAttribute("aria-pressed", String(state[key])); save(key); after(); };
  };
  toggle("chordsBtn", "chords", () => renderAll());
  toggle("pianoBtn", "piano", () => { $("pianoPanel").hidden = !state.piano || state.view === "presenter"; paint(true); });
  setupPianoSheet();
  const stavesMenu = $("stavesMenu");
  stavesMenu.querySelectorAll("[data-layout]").forEach((b) => b.addEventListener("click", () => { stavesMenu.open = false; setStaves(b.dataset.layout); }));
  stavesMenu.querySelector("[data-acc-staff]").addEventListener("click", () => {
    stavesMenu.open = false;
    state.accStaff = !state.accStaff;
    // a piano staff needs something to show: start the accompaniment if it is off
    if (state.accStaff && state.accomp === "off") { state.accomp = "church"; engine.loadPiano(); rebuild(); }
    save("accStaff", "accomp");
    renderAll();
  });
  stavesMenu.querySelectorAll("[data-words-at]").forEach((b) => b.addEventListener("click", () => { stavesMenu.open = false; setWordsAt(b.dataset.wordsAt); }));
  document.addEventListener("click", (e) => { if (stavesMenu.open && !stavesMenu.contains(e.target)) stavesMenu.open = false; });
  const setToolbarH = () => document.documentElement.style.setProperty("--toolbar-h", `${document.querySelector(".toolbar").offsetHeight}px`);
  setToolbarH();
  window.addEventListener("resize", setToolbarH);
  setupTooltips();
  // the More menu closes after a choice, and when clicking elsewhere
  const more = $("moreMenu");
  more.querySelectorAll(".menu-item").forEach((b) => b.addEventListener("click", () => { more.open = false; }));
  document.addEventListener("click", (e) => { if (more.open && !more.contains(e.target)) more.open = false; });
  $("studioBtn").onclick = openStudio;
  $("studioClose").onclick = () => $("studio").close();
  $("studioReset").onclick = () => studio.reset();

  const WORDS_HINT = {
    all: "Every verse under the music, as in the hymnal.",
    current: "Only the verse being sung, in the staff and sol-fa; it changes as you go. The Words view shows every verse.",
    solfa: "Each voice's own note names (doh, re, mi) in the key being sung, for sight-singing.",
    none: "Plain staves. The line being sung still shows in the bar below. The Words view shows every verse.",
  };
  $("wordsHint").textContent = WORDS_HINT[state.words];
  document.querySelectorAll('input[name="wordsMode"]').forEach((r) => {
    r.checked = r.value === state.words;
    r.onchange = () => { state.words = r.value; save("words"); $("wordsHint").textContent = WORDS_HINT[r.value]; renderAll(); if (anySung()) prepareStems(); };
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") $("optionsMenu").open = false; });
  // the options panel opens just under the toolbar, wherever the page is scrolled
  $("optionsMenu").addEventListener("toggle", () => {
    const bottom = document.querySelector(".toolbar").getBoundingClientRect().bottom;
    document.documentElement.style.setProperty("--toolbar-bottom", `${Math.max(0, bottom)}px`);
  });
  $("verseUnfold").checked = unfolded();
  $("verseUnfold").onchange = (e) => { state.verseLayout = e.target.checked ? "unfold" : "stack"; save("verseLayout"); renderAll(); };
  $("presenterShows").value = state.presenterShows;
  $("presenterShows").onchange = (e) => { state.presenterShows = e.target.value; save("presenterShows"); paint(true); };
  $("fullBtn").onclick = async () => {
    if (state.view !== "presenter") { state.view = "presenter"; save("view"); await renderAll(); }
    $("stageWrap").requestFullscreen?.().catch(() => toast("This browser would not go full screen."));
  };
  $("pageBtn").onclick = enterFullPage;
  $("pageExit").onclick = leaveFullPage;
  $("windowBtn").onclick = openProjector;
  document.addEventListener("keydown", (e) => {
    if (e.key !== "Escape") return;
    if (document.body.classList.contains("full-page")) leaveFullPage();
    else if (state.loop.on && !$("optionsMenu").open && !$("studio").open) stopRepeat();
  });
  $("lineByLine").checked = state.sweep && state.solfaSweep;
  $("lineByLine").onchange = (e) => {
    state.sweep = state.solfaSweep = e.target.checked;
    store.set("lineByLine", state.sweep); store.set("solfaLineByLine", state.solfaSweep);
    renderAll();
  };
  $("nowbarToggle").checked = state.nowbar;
  $("nowbarToggle").onchange = (e) => { state.nowbar = e.target.checked; save("nowbar"); $("nowbar").hidden = !state.nowbar || state.view === "presenter"; };
  for (const id of ["intro", "interlude"]) {
    const sel = $(id);
    sel.innerHTML = Object.entries(INSTRUMENTAL).map(([v, l]) => `<option value="${v}">${l}</option>`).join("");
    sel.value = state[id];
    sel.onchange = () => { state[id] = sel.value; save(id); if (sel.value !== "none") engine.loadPiano(); rebuild(); };
  }
  $("renderSingers").onclick = renderSingers;
  $("singEngine").onchange = (e) => {
    const v = e.target.value;
    state.singAsk = v === "ask"; save("singAsk"); // a fixed choice here means: don't ask at Play
    if (v !== "ask") chooseWhoSings(v);
  };
  $("showSync").checked = state.showSync;
  $("showSync").onchange = (e) => { state.showSync = e.target.checked; save("showSync"); renderAll(); if (state.showSync) toast(syncSummary(), 6000); };
  $("addSync").onclick = addSyncopation;
  $("restoreRhythm").onclick = restoreRhythm;
  $("countIn").checked = state.countIn;
  $("countIn").onchange = (e) => { state.countIn = e.target.checked; save("countIn"); rebuild(); };
  $("countAt").value = state.countAt;
  $("countAt").onchange = (e) => { state.countAt = e.target.value; save("countAt"); rebuild(); };
  $("zoomIn").onclick = () => { state.zoom = Math.min(2, state.zoom * 1.15); save("zoom"); renderAll(); };
  $("zoomOut").onclick = () => { state.zoom = Math.max(0.6, state.zoom / 1.15); save("zoom"); renderAll(); };
  document.addEventListener("click", (e) => { const m = $("optionsMenu"); if (m.open && !m.contains(e.target)) m.open = false; });

  $("importBtn").onclick = () => $("importFile").click();
  $("importAudioBtn").onclick = () => $("importAudioFile").click();
  $("importAudioFile").onchange = (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) doImportAudio(f); };
  $("importFile").onchange = (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) doImport(f); };
  $("exportBtn").onclick = doExport;
  $("recordBtn").onclick = openRecordDialog;

  let w = window.innerWidth;
  let timer;
  window.addEventListener("resize", () => {
    clearTimeout(timer);
    timer = setTimeout(() => { if (Math.abs(window.innerWidth - w) > 40) { w = window.innerWidth; renderAll(); } }, 200);
  });
}

function buildVerseChips() {
  const box = $("verses");
  box.innerHTML = hymn.verses.map((_, i) => `<label><input type="checkbox" value="${i + 1}" ${state.verses.includes(i + 1) ? "checked" : ""}> ${i + 1}</label>`).join("");
  box.querySelectorAll("input").forEach((inp) => {
    inp.onchange = () => {
      const chosen = [...box.querySelectorAll("input:checked")].map((x) => Number(x.value));
      if (!chosen.length) { inp.checked = true; return; } // always at least one verse
      state.verses = chosen;
      store.set(`verses:${hymn.id}`, chosen);
      if (anySung()) prepareStems(); else rebuild();
    };
  });
}

boot();


// ─────────────────────────────────────────────── the Android app's handle
// The app draws its own controls (the player sheet, the views, the voices
// panel) and drives this page through these few calls; it reads state() to
// redraw them. Everything goes through the page's own handlers, so the app
// and the page can never disagree about what is playing or muted.
/** The hymn the app opened, while it loads (AHStudio.open loads one at a time). */
let appLoading = null;
window.AHStudio = {
  /** live singing: which passes are sung by Warble now, and how fast it went (for tests and the app) */
  warble() { return JSON.stringify({ engine: singEngine(), ready: [...stemInfo.keys()], voice: useWarble() ? liveW().engine : null, speed: liveW()?.speed ?? null, workers: liveW()?.workers?.length ?? 0 }); },
  /** "words" | "solfa" | "page" | "tracks" | "presenter" */
  view(v) {
    if (v === "page" && state.staffScroll) v = "tracks"; // the staff moving under a still playhead
    if (v === state.view) return;
    const b = document.querySelector(`.views .seg[data-view="${v}"]`);
    if (b) b.click(); else { state.view = v; save("view"); renderAll(); }
  },
  /** Switch to another hymn without reloading the page. False when the Studio doesn't have it.
   *  Whatever was playing stops at once; until the new hymn has loaded, state() says it is not
   *  ready, so the app's play button can't start the old one. A later open() wins over this one. */
  async open(id, v, tune) {
    appWant.id = id;
    // a queue or playlist item sung to a chosen tune ("" the printed one): remembered for the hymn, as the picker does
    if (typeof tune === "string") store.set(`tune:${id}`, tune);
    appWant.missing = false;
    if (engine.playing && id !== hymn?.id) stopPlayback(); // the same hymn in another view plays on
    await bootReady;
    if (appWant.id !== id) return false;
    let entry = hymnList.find((x) => x.id === id);
    if (!entry) { await listFresh; if (appWant.id !== id) return false; entry = hymnList.find((x) => x.id === id); } // new on the site since this copy
    // not in the list saved here: the site's list may be newer than the last check (at most every 6 hours), so ask it now
    if (!entry && (await siteListNow())) { if (appWant.id !== id) return false; entry = hymnList.find((x) => x.id === id); }
    if (!entry) { appWant.missing = true; if (engine.playing) stopPlayback(); return false; }
    if (hymn?.id !== id) {
      appWant.loading = true;
      try {
        // one hymn loads at a time: two loads side by side could finish the wrong way round and leave
        // the hymn asked for first on the screen while the app waits for the one asked for last
        // (but not for good: a load held up, say by a page in the background, lets the next one go after 10 s)
        const since = Date.now();
        while (appLoading && Date.now() - since < 10000) await Promise.race([appLoading, new Promise((r) => setTimeout(r, 1000))]);
        if (appWant.id !== id) return false;
        stopPlayback();
        state.zoom = APP_ZOOM; save("zoom"); // each hymn opens at the smallest size: the whole page on the screen
        state.solfaZoom = APP_ZOOM; save("solfaZoom"); // the sol-fa too
        state.altZoom = 1; save("altZoom"); // the words fit themselves to the screen
        // drawn once, in the view asked for (not first in the last hymn's view, then again)
        if (v) { state.view = v === "page" && state.staffScroll ? "tracks" : v; save("view"); }
        $("hymnPicker").value = id;
        history.replaceState(null, "", `${location.pathname}${location.search}#${id}`);
        appLoading = loadHymn(entry);
        try { await appLoading; } finally { appLoading = null; }
      } finally { if (appWant.id === id) appWant.loading = false; }
      if (appWant.id !== id || hymn?.id !== id) return false;
    } else if (typeof tune === "string" && (hymn.tune?.key || "") !== tune) {
      appWant.loading = true;
      try { await setTune(tune); } finally { if (appWant.id === id) appWant.loading = false; }
      if (appWant.id !== id) return false;
    }
    if (v) this.view(v);
    return true;
  },
  /** The app's view options: words ("all" | "current" | "solfa" | "none": every verse, only the one
   *  being sung, sol-fa names, none), sweep (the staff line by line), staves ("S|A|T|B", "SA|TB", …). */
  set(name, value) {
    if (name === "words" && ["all", "current", "solfa", "none"].includes(value)) {
      const r = document.querySelector(`input[name="wordsMode"][value="${value}"]`);
      if (r) { r.checked = true; r.dispatchEvent(new Event("change", { bubbles: true })); }
    } else if (name === "sweep") {
      state.sweep = !!value; store.set("lineByLine", state.sweep); renderAll();
    } else if (name === "verseLayout" && (value === "unfold" || value === "stack")) {
      // "unfold": the verses written out one after another, each starting where the last ends on its line
      $("verseUnfold").checked = value === "unfold";
      $("verseUnfold").dispatchEvent(new Event("change", { bubbles: true }));
    } else if (name === "staves" && /^[SATB|]+$/.test(value)) {
      setStaves(value);
    } else if (name === "accStaff") {
      const want = !!value;
      if (want === !!state.accStaff) return;
      document.querySelector("#stavesMenu [data-acc-staff]")?.click();
    } else if (name === "wordsAt" && ["top", "bottom", "every"].includes(value)) {
      setWordsAt(value);
    } else if (name === "accomp" && value in ACCOMP_STYLES) {
      state.accomp = value; save("accomp");
      if (value !== "off") engine.loadPiano();
      else if (state.accStaff) { state.accStaff = false; save("accStaff"); }
      rebuild(); renderAll();
    } else if ((name === "intro" || name === "interlude") && value in INSTRUMENTAL) {
      const sel = $(name);
      sel.value = value;
      sel.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (name === "countIn") {
      $("countIn").checked = !!value;
      $("countIn").dispatchEvent(new Event("change", { bubbles: true }));
    } else if (name === "tune") {
      // another tune for this hymn's words ("" = the printed one), from state().tunes
      setTune(String(value || ""));
    } else if (name === "countAt" && (value === "start" || value === "verse")) {
      // the count-in bar: at the very start, or after the introduction (just before verse 1)
      $("countAt").value = value;
      $("countAt").dispatchEvent(new Event("change", { bubbles: true }));
    } else if (name === "fit") {
      if (state.view === "solfa") { state.solfaZoom = APP_ZOOM; save("solfaZoom"); } else { state.zoom = APP_ZOOM; save("zoom"); }
      renderAll();
    } else if (name === "singEngine" && (isRecorded(value) || isLive(value) || value === null || value === "")) {
      appAnswered = true;
      if ((value || null) === state.singEngine) { voicesSing(); syncSungControls(); prepareStems(); } else setSingEngine(value || null);
    } else if (name === "solfaSweep") {
      state.solfaSweep = !!value; store.set("solfaLineByLine", state.solfaSweep); renderAll();
    } else if (name === "zoom" && Number(value) > 0) {
      // the size, as a pinch sets it: the staff's or the sol-fa's, by the view
      const z = Math.max(0.5, Math.min(2.5, Number(value)));
      if (state.view === "solfa") { state.solfaZoom = z; save("solfaZoom"); } else { state.zoom = z; save("zoom"); }
      renderAll();
    } else if (name === "staffScroll") {
      state.staffScroll = !!value; save("staffScroll");
      if (state.view === "page" || state.view === "tracks") this.view(state.staffScroll ? "tracks" : "page");
    } else if (name === "presenterShows" && ["score", "words", "stanza"].includes(value)) {
      const sel = $("presenterShows");
      sel.value = value;
      sel.dispatchEvent(new Event("change", { bubbles: true }));
    } else if (name === "singSolfa") {
      state.singSolfa = !!value; save("singSolfa"); prepareStems();
    } else if (name === "solfaWordsAt" && ["every", "top", "bottom"].includes(value)) {
      state.solfaWordsAt = value; save("solfaWordsAt"); renderAll();
    } else if (name === "instrumental") {
      // instruments only: every voice on the piano instead of singing; off brings the voices back as they were
      const on = !!value;
      if (on === !!state.instrumental) return;
      const chs = ["S", "A", "T", "B"].filter((ch) => hymn?.voices?.[ch]?.length);
      if (on) {
        // only the sounds someone chose: a voice on its default (the singers, or the synth where there are
        // none) goes back to its default, not to whatever its menu showed on this hymn
        state.beforeInstrumental = Object.fromEntries(chs.map((ch) => [ch, state.voiceSounds[ch] ?? null]));
        save("beforeInstrumental");
      }
      state.instrumental = on; save("instrumental");
      if (on) { for (const ch of chs) this.setSound(ch, "piano"); return; }
      for (const ch of chs) {
        const was = state.beforeInstrumental?.[ch];
        if (was && was !== "piano") state.voiceSounds[ch] = was; else delete state.voiceSounds[ch];
      }
      save("voiceSounds"); applyMix(); syncSungControls(); buildHeaders(); prepareStems();
    }
  },
  /** Saved singers, for the app's Settings: starts the count; savedList holds the answer (JSON) when done. */
  saved() { this.savedList = null; singers.list().then((l) => { this.savedList = JSON.stringify(l); }, () => { this.savedList = "[]"; }); },
  savedList: null,
  /** Clear saved singers: the given hymn ids, or all of them when none are given. Then recounts. */
  clearSaved(ids) { this.savedList = null; singers.clear(ids && ids.length ? ids : null).finally(() => this.saved()); },
  /** The hymns the Studio can play. */
  hymns() { return JSON.stringify(hymnList.map((x) => x.id)); },
  /** Out of a repeat (the app's Back gesture): the music plays on from where it is. */
  stopRepeat() { stopRepeat(); },
  /** Sing with me: { do: "piano" | "sing", find: true (any hymn, from the singing) | false (this hymn) }, or null to stop. */
  singWithMe(opts) { if (opts) swmStart(typeof opts === "string" ? JSON.parse(opts) : opts); else swmStop(); },
  toggle() { if (appWant.id && (appWant.id !== hymn?.id || appWant.loading)) return; return togglePlay(); },
  stop() { stopPlayback(); },
  setMute(ch, on) { state.mute[ch] = !!on; save("mute"); applyMix(); buildHeaders(); },
  setSolo(ch, on) { state.solo[ch] = !!on; save("solo"); applyMix(); buildHeaders(); },
  setLevel(ch, x) { state.levels[ch] = Math.max(0, Math.min(1, Number(x))); save("levels"); applyMix(); },
  /** Where a voice is heard, -1 (left ear only) to 1 (right ear only), 0 both: two singers sharing earphones
   *  each hear their own part from the one player, in time. */
  setPan(ch, x) {
    const v = Math.max(-1, Math.min(1, Number(x) || 0));
    state.pans[ch] = v; save("pans");
    engine.setPan(ch, v);
    engine.nativeGains(true);
  },
  setSound(ch, value) {
    const sel = document.querySelector(`select.vsound[data-sound="${ch}"]`);
    if (!sel) return;
    sel.value = value;
    sel.dispatchEvent(new Event("change", { bubbles: true }));
  },
  setTempo(bpm) {
    const t = $("tempo");
    t.value = String(Math.round(bpm));
    t.dispatchEvent(new Event("input", { bubbles: true }));
    t.dispatchEvent(new Event("change", { bubbles: true }));
  },
  key(step) { $(step > 0 ? "keyUp" : "keyDown").click(); },
  /** The tunes a hymn's words can be sung to, for the app's queue and playlists: [{value, label, why}],
   *  the printed tune first (value ""); empty when there is only the printed one (or the list hasn't loaded). */
  tunesOf(id) {
    const c = tuneChoices(id);
    return JSON.stringify(c ? [{ value: "", label: c.name || "As printed", why: "own" }, ...c.alts.map((a) => ({ value: a.tune, label: a.name, why: a.why }))] : []);
  },
  state() {
    endIfDone();
    const voices = ["S", "A", "T", "B"].filter((ch) => hymn?.voices?.[ch]?.length).map((ch) => {
      const sel = document.querySelector(`select.vsound[data-sound="${ch}"]`);
      return {
        ch, name: VOICES[ch]?.name ?? ch, mute: !!state.mute[ch], solo: !!state.solo[ch], level: state.levels[ch] ?? 0.8, pan: state.pans[ch] ?? 0,
        sound: sel?.value ?? "", sounds: sel ? [...sel.options].map((o) => ({ value: o.value, label: o.textContent })) : [],
      };
    });
    // the piano (accompaniment, introduction, interlude): its own loudness, mute and solo
    if (hymn && (state.accomp !== "off" || state.intro !== "none" || state.interlude !== "none")) {
      voices.push({ ch: "acc", name: "Piano", mute: !!state.mute.acc, solo: !!state.solo.acc, level: state.levels.acc ?? 0.55, sound: "", sounds: [] });
    }
    const want = appWant.id ?? hymn?.id ?? null;
    return JSON.stringify({
      ready: !!perf && !appWant.loading && hymn?.id === want, hymn: hymn?.id ?? null, want, missing: appWant.missing,
      title: hymn?.title ?? "", english: hymn?.english ?? "", view: state.view, words: state.words, sweep: !!state.sweep, verseLayout: state.verseLayout,
      singWithMe: swm.on ? { do: swm.do, find: swm.find, joined: swm.joined, status: swm.status, candidates: swm.joined ? [] : swm.candidates || [], tempo: swm.joined ? Math.round(state.tempo * engine.rate) : null,
        lag: swm.joined ? Math.round(follower.lag * 100) / 100 : null, q: swm.joined && perf ? Math.round((locate(perf, engine.now())?.q ?? 0) * 100) / 100 : null, transpose: state.transpose } : null,
      staves: state.tracks.map((t) => t.join("")).join("|"), wordsAt: wordsAt(), accStaff: !!state.accStaff,
      accomp: state.accomp, intro: state.intro, interlude: state.interlude, countIn: !!state.countIn, countAt: state.countAt, zoom: state.zoom,
      // the tune: "" the printed one; tunes: the choices ({value, label, why: "printed" | "fits"}), empty when there are none
      tune: hymn?.tune?.key || "",
      tunes: (() => { const c = hymn && tuneChoices(hymn.id); return c ? [{ value: "", label: c.name || "As printed", why: "own" }, ...c.alts.map((a) => ({ value: a.tune, label: a.name, why: a.why }))] : []; })(),
      solfaSweep: !!state.solfaSweep, solfaWordsAt: state.solfaWordsAt, instrumental: !!state.instrumental, singSolfa: !!state.singSolfa, staffScroll: !!state.staffScroll, presenterShows: state.presenterShows,
      accomps: Object.entries(ACCOMP_STYLES).map(([value, label]) => ({ value, label })),
      intros: Object.entries(INSTRUMENTAL).map(([value, label]) => ({ value, label })),
      playing: !!engine?.playing, tempo: state.tempo, key: $("keyLabel")?.textContent ?? "", voices,
      stemsBytes: stemsCost.bytes, stemsSaved: stemsCost.saved,
      ends: playEnds, repeating: !!state.loop.on, repeatLabel: state.loop.on ? (state.loop.from === state.loop.to ? `bar ${state.loop.from}` : `bars ${state.loop.from}–${state.loop.to}`) : "",
      singEngine: singEngine(), singEngines: (() => { const l = [...recordedChoices().map((r) => ({ value: r.engine, label: r.label })), ...(singingCfg.warble ? singingCfg.voices.map((w) => ({ value: w.engine, label: w.label })) : [])]; return l.length > 1 ? l : []; })(),
      credits: useWarble() ? liveW().credits() : "",
    });
  },
};
